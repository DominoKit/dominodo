package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGPathSegMovetoRel extends SVGPathSeg {
  public double x;
  public double y;
}
