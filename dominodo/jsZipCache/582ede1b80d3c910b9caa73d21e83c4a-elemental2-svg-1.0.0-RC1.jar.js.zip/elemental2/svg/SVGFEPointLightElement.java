package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGFEPointLightElement extends SVGElement {
  public SVGAnimatedNumber x;
  public SVGAnimatedNumber y;
  public SVGAnimatedNumber z;
}
