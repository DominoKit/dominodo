package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGException", namespace = JsPackage.GLOBAL)
class SVGException__Constants {
  static double SVG_INVALID_VALUE_ERR;
  static double SVG_MATRIX_NOT_INVERTABLE;
  static double SVG_WRONG_TYPE_ERR;
}
