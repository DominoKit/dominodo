package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGFEDisplacementMapElement", namespace = JsPackage.GLOBAL)
class SVGFEDisplacementMapElement__Constants {
  static double SVG_CHANNEL_A;
  static double SVG_CHANNEL_B;
  static double SVG_CHANNEL_G;
  static double SVG_CHANNEL_R;
  static double SVG_CHANNEL_UNKNOWN;
}
