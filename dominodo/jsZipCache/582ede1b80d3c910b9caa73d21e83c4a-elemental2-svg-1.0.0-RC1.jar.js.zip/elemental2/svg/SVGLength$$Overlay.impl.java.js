/**
 * @fileoverview transpiled from elemental2.svg.SVGLength$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGLength.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_CM__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_CM__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_CM__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_CM__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_EMS__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_EMS__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_EMS__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_EMS__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_EXS__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_EXS__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_EXS__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_EXS__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_IN__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_IN__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_IN__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_IN__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_MM__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_MM__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_MM__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_MM__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_NUMBER__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_NUMBER__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_NUMBER__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_NUMBER__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_PC__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PC__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_PC__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PC__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_PERCENTAGE__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PERCENTAGE__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_PERCENTAGE__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PERCENTAGE__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_PT__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PT__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_PT__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PT__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_PX__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PX__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_PX__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_PX__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_LENGTHTYPE_UNKNOWN__elemental2_svg_SVGLength_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_UNKNOWN__elemental2_svg_SVGLength_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_LENGTHTYPE_UNKNOWN__elemental2_svg_SVGLength_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_LENGTHTYPE_UNKNOWN__elemental2_svg_SVGLength_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_LENGTHTYPE_CM__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_CM;
    $Overlay.$f_SVG_LENGTHTYPE_EMS__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_EMS;
    $Overlay.$f_SVG_LENGTHTYPE_EXS__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_EXS;
    $Overlay.$f_SVG_LENGTHTYPE_IN__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_IN;
    $Overlay.$f_SVG_LENGTHTYPE_MM__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_MM;
    $Overlay.$f_SVG_LENGTHTYPE_NUMBER__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_NUMBER;
    $Overlay.$f_SVG_LENGTHTYPE_PC__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_PC;
    $Overlay.$f_SVG_LENGTHTYPE_PERCENTAGE__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_PERCENTAGE;
    $Overlay.$f_SVG_LENGTHTYPE_PT__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_PT;
    $Overlay.$f_SVG_LENGTHTYPE_PX__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_PX;
    $Overlay.$f_SVG_LENGTHTYPE_UNKNOWN__elemental2_svg_SVGLength_$Overlay = SVGLength.SVG_LENGTHTYPE_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGLength;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGLength'));


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_CM__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_EMS__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_EXS__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_IN__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_MM__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_NUMBER__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_PC__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_PERCENTAGE__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_PT__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_PX__elemental2_svg_SVGLength_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_LENGTHTYPE_UNKNOWN__elemental2_svg_SVGLength_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGLength$$Overlay.js.map