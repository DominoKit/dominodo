package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsProperty;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public interface SVGLangSpace {
  @JsProperty
  String getXmllang();

  @JsProperty
  String getXmlspace();

  @JsProperty
  void setXmllang(String xmllang);

  @JsProperty
  void setXmlspace(String xmlspace);
}
