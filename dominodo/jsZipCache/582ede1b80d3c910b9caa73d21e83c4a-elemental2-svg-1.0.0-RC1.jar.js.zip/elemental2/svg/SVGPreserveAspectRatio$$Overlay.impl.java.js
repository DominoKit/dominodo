/**
 * @fileoverview transpiled from elemental2.svg.SVGPreserveAspectRatio$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGPreserveAspectRatio.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MEETORSLICE_MEET__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MEETORSLICE_MEET__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MEETORSLICE_MEET__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MEETORSLICE_MEET__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MEETORSLICE_SLICE__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MEETORSLICE_SLICE__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MEETORSLICE_SLICE__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MEETORSLICE_SLICE__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MEETORSLICE_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MEETORSLICE_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MEETORSLICE_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MEETORSLICE_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_NONE__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_NONE__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_NONE__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_NONE__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMAXYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMAXYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMAXYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMAXYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMAXYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMAXYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMIDYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMIDYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMIDYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMIDYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMIDYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMIDYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMINYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMINYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMINYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMINYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_PRESERVEASPECTRATIO_XMINYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_PRESERVEASPECTRATIO_XMINYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_MEETORSLICE_MEET__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_MEETORSLICE_MEET;
    $Overlay.$f_SVG_MEETORSLICE_SLICE__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_MEETORSLICE_SLICE;
    $Overlay.$f_SVG_MEETORSLICE_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_MEETORSLICE_UNKNOWN;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_NONE__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_NONE;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_UNKNOWN;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMAXYMAX;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMAXYMID;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMAXYMIN;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMIDYMAX;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMIDYMID;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMIDYMIN;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMINYMAX;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMINYMID;
    $Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = SVGPreserveAspectRatio.SVG_PRESERVEASPECTRATIO_XMINYMIN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGPreserveAspectRatio;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGPreserveAspectRatio'));


/** @private {number} */
$Overlay.$f_SVG_MEETORSLICE_MEET__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MEETORSLICE_SLICE__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MEETORSLICE_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_NONE__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_UNKNOWN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMAXYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMIDYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMAX__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMID__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_PRESERVEASPECTRATIO_XMINYMIN__elemental2_svg_SVGPreserveAspectRatio_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGPreserveAspectRatio$$Overlay.js.map