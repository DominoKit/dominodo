/**
 * @fileoverview transpiled from elemental2.svg.SVGElementInstance$OninputUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.svg.SVGElementInstance.OninputUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$JavaScriptFunction = goog.require('vmbootstrap.JavaScriptFunction');


// Re-exports the implementation.
var OninputUnionType_$Overlay = goog.require('elemental2.svg.SVGElementInstance.OninputUnionType.$Overlay$impl');
exports = OninputUnionType_$Overlay;
 