package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGAngle", namespace = JsPackage.GLOBAL)
class SVGAngle__Constants {
  static double SVG_ANGLETYPE_DEG;
  static double SVG_ANGLETYPE_GRAD;
  static double SVG_ANGLETYPE_RAD;
  static double SVG_ANGLETYPE_UNKNOWN;
  static double SVG_ANGLETYPE_UNSPECIFIED;
}
