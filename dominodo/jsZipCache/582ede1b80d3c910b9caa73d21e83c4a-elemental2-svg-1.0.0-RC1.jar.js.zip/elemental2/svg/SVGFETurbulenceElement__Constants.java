package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGFETurbulenceElement", namespace = JsPackage.GLOBAL)
class SVGFETurbulenceElement__Constants {
  static double SVG_STITCHTYPE_NOSTITCH;
  static double SVG_STITCHTYPE_STITCH;
  static double SVG_STITCHTYPE_UNKNOWN;
  static double SVG_TURBULENCE_TYPE_FRACTALNOISE;
  static double SVG_TURBULENCE_TYPE_TURBULENCE;
  static double SVG_TURBULENCE_TYPE_UNKNOWN;
}
