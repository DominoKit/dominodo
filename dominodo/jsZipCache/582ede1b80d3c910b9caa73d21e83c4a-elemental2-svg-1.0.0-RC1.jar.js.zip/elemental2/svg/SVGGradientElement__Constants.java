package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGGradientElement", namespace = JsPackage.GLOBAL)
class SVGGradientElement__Constants {
  static double SVG_SPREADMETHOD_PAD;
  static double SVG_SPREADMETHOD_REFLECT;
  static double SVG_SPREADMETHOD_REPEAT;
  static double SVG_SPREADMETHOD_UNKNOWN;
}
