/**
 * @fileoverview transpiled from elemental2.svg.SVGElementInstance$OnmousedownUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGElementInstance.OnmousedownUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $JavaScriptFunction = goog.forwardDeclare('vmbootstrap.JavaScriptFunction$impl');


class OnmousedownUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    OnmousedownUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), OnmousedownUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {EventListener}
   * @public
   */
  static m_asEventListener__elemental2_svg_SVGElementInstance_OnmousedownUnionType($thisArg) {
    OnmousedownUnionType_$Overlay.$clinit();
    return /**@type {EventListener} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {?function(Event):*}
   * @public
   */
  static m_asOnmousedownFn__elemental2_svg_SVGElementInstance_OnmousedownUnionType($thisArg) {
    OnmousedownUnionType_$Overlay.$clinit();
    return /**@type {?function(Event):*} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $JavaScriptFunction));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isOnmousedownFn__elemental2_svg_SVGElementInstance_OnmousedownUnionType($thisArg) {
    OnmousedownUnionType_$Overlay.$clinit();
    return $JavaScriptFunction.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    OnmousedownUnionType_$Overlay.$clinit = (() =>{
    });
    OnmousedownUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.EventListener.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $JavaScriptFunction = goog.module.get('vmbootstrap.JavaScriptFunction$impl');
  }
  
  
};



exports = OnmousedownUnionType_$Overlay; 
//# sourceMappingURL=SVGElementInstance$OnmousedownUnionType$$Overlay.js.map