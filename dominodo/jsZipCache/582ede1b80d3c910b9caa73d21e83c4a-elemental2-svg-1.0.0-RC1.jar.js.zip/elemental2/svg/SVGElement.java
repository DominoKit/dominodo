package elemental2.svg;

import elemental2.dom.Element;
import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGElement extends Element {
  public String id;
  public SVGSVGElement ownerSVGElement;
  public SVGElement viewportElement;
  public String xmlbase;
}
