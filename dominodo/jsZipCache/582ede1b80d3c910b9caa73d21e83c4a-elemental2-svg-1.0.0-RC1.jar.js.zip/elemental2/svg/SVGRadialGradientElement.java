package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGRadialGradientElement extends SVGGradientElement {
  public SVGAnimatedLength cx;
  public SVGAnimatedLength cy;
  public SVGAnimatedLength fx;
  public SVGAnimatedLength fy;
  public SVGAnimatedLength r;
}
