package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGFEMorphologyElement", namespace = JsPackage.GLOBAL)
class SVGFEMorphologyElement__Constants {
  static double SVG_MORPHOLOGY_OPERATOR_DILATE;
  static double SVG_MORPHOLOGY_OPERATOR_ERODE;
  static double SVG_MORPHOLOGY_OPERATOR_UNKNOWN;
}
