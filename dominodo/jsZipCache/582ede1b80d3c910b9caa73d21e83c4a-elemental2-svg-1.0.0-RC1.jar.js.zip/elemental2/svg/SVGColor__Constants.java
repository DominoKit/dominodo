package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGColor", namespace = JsPackage.GLOBAL)
class SVGColor__Constants {
  static double SVG_COLORTYPE_CURRENTCOLOR;
  static double SVG_COLORTYPE_RGBCOLOR;
  static double SVG_COLORTYPE_RGBCOLOR_ICCCOLOR;
  static double SVG_COLORTYPE_UNKNOWN;
}
