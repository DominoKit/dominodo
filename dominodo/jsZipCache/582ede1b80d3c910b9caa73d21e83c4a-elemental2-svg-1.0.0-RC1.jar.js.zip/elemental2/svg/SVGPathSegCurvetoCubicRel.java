package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGPathSegCurvetoCubicRel extends SVGPathSeg {
  public double x;
  public double x1;
  public double x2;
  public double y;
  public double y1;
  public double y2;
}
