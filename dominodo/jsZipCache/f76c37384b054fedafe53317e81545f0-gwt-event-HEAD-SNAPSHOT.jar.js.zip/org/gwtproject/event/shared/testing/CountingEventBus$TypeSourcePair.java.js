/**
 * @fileoverview transpiled from org.gwtproject.event.shared.testing.CountingEventBus$TypeSourcePair.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.testing.CountingEventBus.TypeSourcePair');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Objects = goog.require('java.util.Objects');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Type = goog.require('org.gwtproject.event.shared.Event.Type');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var TypeSourcePair = goog.require('org.gwtproject.event.shared.testing.CountingEventBus.TypeSourcePair$impl');
exports = TypeSourcePair;
 