/**
 * @fileoverview transpiled from org.gwtproject.event.shared.testing.CountingEventBus$KeyedCounter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.testing.CountingEventBus.KeyedCounter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Integer = goog.require('java.lang.Integer');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var KeyedCounter = goog.require('org.gwtproject.event.shared.testing.CountingEventBus.KeyedCounter$impl');
exports = KeyedCounter;
 