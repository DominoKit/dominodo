/**
 * @fileoverview transpiled from org.gwtproject.event.shared.SimpleEventBus.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.SimpleEventBus');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EventBus = goog.require('org.gwtproject.event.shared.EventBus');
const _NullPointerException = goog.require('java.lang.NullPointerException');
const _Throwable = goog.require('java.lang.Throwable');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collections = goog.require('java.util.Collections');
const _HashMap = goog.require('java.util.HashMap');
const _HashSet = goog.require('java.util.HashSet');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Event = goog.require('org.gwtproject.event.shared.Event');
const _Type = goog.require('org.gwtproject.event.shared.Event.Type');
const _HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration');
const _Command = goog.require('org.gwtproject.event.shared.SimpleEventBus.Command');
const _UmbrellaException = goog.require('org.gwtproject.event.shared.UmbrellaException');
const _$Asserts = goog.require('vmbootstrap.Asserts');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var SimpleEventBus = goog.require('org.gwtproject.event.shared.SimpleEventBus$impl');
exports = SimpleEventBus;
 