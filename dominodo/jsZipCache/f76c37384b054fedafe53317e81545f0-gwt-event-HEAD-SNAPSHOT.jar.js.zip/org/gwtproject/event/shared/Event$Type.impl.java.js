/**
 * @fileoverview transpiled from org.gwtproject.event.shared.Event$Type.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.event.shared.Event.Type$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @template C_Type_H
  */
class Type extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_index__org_gwtproject_event_shared_Event_Type_ = 0;
  }
  
  /**
   * @template C_Type_H
   * @return {!Type<C_Type_H>}
   * @public
   */
  static $create__() {
    Type.$clinit();
    let $instance = new Type();
    $instance.$ctor__org_gwtproject_event_shared_Event_Type__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_event_shared_Event_Type__() {
    this.$ctor__java_lang_Object__();
    this.f_index__org_gwtproject_event_shared_Event_Type_ = ++Type.$f_nextHashCode__org_gwtproject_event_shared_Event_Type_;
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return this.f_index__org_gwtproject_event_shared_Event_Type_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  toString() {
    return "Event type";
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_nextHashCode__org_gwtproject_event_shared_Event_Type_() {
    return (Type.$clinit(), Type.$f_nextHashCode__org_gwtproject_event_shared_Event_Type_);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_nextHashCode__org_gwtproject_event_shared_Event_Type_(value) {
    (Type.$clinit(), Type.$f_nextHashCode__org_gwtproject_event_shared_Event_Type_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Type.$clinit = (() =>{
    });
    Type.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Type;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Type);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(Type, $Util.$makeClassName('org.gwtproject.event.shared.Event$Type'));


/** @private {number} */
Type.$f_nextHashCode__org_gwtproject_event_shared_Event_Type_ = 0;




exports = Type; 
//# sourceMappingURL=Event$Type.js.map