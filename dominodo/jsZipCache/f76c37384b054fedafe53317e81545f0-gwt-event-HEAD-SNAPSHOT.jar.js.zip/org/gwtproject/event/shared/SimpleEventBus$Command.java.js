/**
 * @fileoverview transpiled from org.gwtproject.event.shared.SimpleEventBus$Command.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.SimpleEventBus.Command');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.gwtproject.event.shared.SimpleEventBus.Command.$LambdaAdaptor');


// Re-exports the implementation.
var Command = goog.require('org.gwtproject.event.shared.SimpleEventBus.Command$impl');
exports = Command;
 