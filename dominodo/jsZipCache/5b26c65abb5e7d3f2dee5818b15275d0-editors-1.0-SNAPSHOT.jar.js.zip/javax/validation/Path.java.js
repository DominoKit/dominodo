/**
 * @fileoverview transpiled from javax.validation.Path.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.validation.Path');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Iterable = goog.require('java.lang.Iterable');
const _$Util = goog.require('nativebootstrap.Util');
const _Iterator = goog.require('java.util.Iterator');
const _$LambdaAdaptor = goog.require('javax.validation.Path.$LambdaAdaptor');
const _Node = goog.require('javax.validation.Path.Node');


// Re-exports the implementation.
var Path = goog.require('javax.validation.Path$impl');
exports = Path;
 