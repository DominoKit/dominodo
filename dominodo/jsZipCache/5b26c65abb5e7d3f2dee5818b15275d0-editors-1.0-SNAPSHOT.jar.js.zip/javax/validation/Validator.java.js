/**
 * @fileoverview transpiled from javax.validation.Validator.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.validation.Validator');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Set = goog.require('java.util.Set');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _BeanDescriptor = goog.require('javax.validation.metadata.BeanDescriptor');


// Re-exports the implementation.
var Validator = goog.require('javax.validation.Validator$impl');
exports = Validator;
 