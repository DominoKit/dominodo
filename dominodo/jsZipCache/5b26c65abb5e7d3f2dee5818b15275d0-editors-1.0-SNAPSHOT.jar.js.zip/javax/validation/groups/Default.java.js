/**
 * @fileoverview transpiled from javax.validation.groups.Default.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.validation.groups.Default');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var Default = goog.require('javax.validation.groups.Default$impl');
exports = Default;
 