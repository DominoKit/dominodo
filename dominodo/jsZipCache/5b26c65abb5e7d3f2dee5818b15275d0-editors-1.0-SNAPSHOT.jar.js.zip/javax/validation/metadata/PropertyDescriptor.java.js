/**
 * @fileoverview transpiled from javax.validation.metadata.PropertyDescriptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.validation.metadata.PropertyDescriptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _ElementDescriptor = goog.require('javax.validation.metadata.ElementDescriptor');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var PropertyDescriptor = goog.require('javax.validation.metadata.PropertyDescriptor$impl');
exports = PropertyDescriptor;
 