/**
 * @fileoverview transpiled from javax.validation.Path$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.validation.Path.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _Path = goog.require('javax.validation.Path');
const _$Util = goog.require('nativebootstrap.Util');
const _Iterable = goog.require('java.lang.Iterable');
const _Iterator = goog.require('java.util.Iterator');
const _Spliterator = goog.require('java.util.Spliterator');
const _Consumer = goog.require('java.util.function.Consumer');
const _Node = goog.require('javax.validation.Path.Node');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('javax.validation.Path.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 