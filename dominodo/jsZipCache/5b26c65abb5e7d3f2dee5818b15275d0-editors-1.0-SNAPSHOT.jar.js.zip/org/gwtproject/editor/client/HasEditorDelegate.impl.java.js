/**
 * @fileoverview transpiled from org.gwtproject.editor.client.HasEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.HasEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Editor = goog.require('org.gwtproject.editor.client.Editor$impl');

let EditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.EditorDelegate$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.gwtproject.editor.client.HasEditorDelegate.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 * @extends {Editor<C_T>}
 */
class HasEditorDelegate {
  /**
   * @abstract
   * @param {EditorDelegate<C_T>} delegate
   * @return {void}
   * @public
   */
  m_setDelegate__org_gwtproject_editor_client_EditorDelegate(delegate) {
  }
  
  /**
   * @template C_T
   * @param {?function(EditorDelegate<C_T>):void} fn
   * @return {HasEditorDelegate<C_T>}
   * @public
   */
  static $adapt(fn) {
    HasEditorDelegate.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasEditorDelegate.$clinit = (() =>{
    });
    HasEditorDelegate.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Editor.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_HasEditorDelegate = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_HasEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_HasEditorDelegate;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.gwtproject.editor.client.HasEditorDelegate.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasEditorDelegate, $Util.$makeClassName('org.gwtproject.editor.client.HasEditorDelegate'));


HasEditorDelegate.$markImplementor(/** @type {Function} */ (HasEditorDelegate));


exports = HasEditorDelegate; 
//# sourceMappingURL=HasEditorDelegate.js.map