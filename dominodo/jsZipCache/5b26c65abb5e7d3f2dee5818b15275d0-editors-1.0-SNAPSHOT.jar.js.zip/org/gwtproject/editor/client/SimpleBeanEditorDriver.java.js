/**
 * @fileoverview transpiled from org.gwtproject.editor.client.SimpleBeanEditorDriver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.SimpleBeanEditorDriver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EditorDriver = goog.require('org.gwtproject.editor.client.EditorDriver');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');


// Re-exports the implementation.
var SimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.SimpleBeanEditorDriver$impl');
exports = SimpleBeanEditorDriver;
 