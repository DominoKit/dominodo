/**
 * @fileoverview transpiled from org.gwtproject.editor.client.SimpleBeanEditorDriver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.SimpleBeanEditorDriver$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EditorDriver = goog.require('org.gwtproject.editor.client.EditorDriver$impl');

let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');


/**
 * @interface
 * @template C_T, C_E
 * @extends {EditorDriver<C_T>}
 */
class SimpleBeanEditorDriver {
  /**
   * @abstract
   * @param {C_T} object
   * @return {void}
   * @public
   */
  m_edit__java_lang_Object(object) {
  }
  
  /**
   * @abstract
   * @override
   * @return {C_T}
   * @public
   */
  m_flush__() {
  }
  
  /**
   * @abstract
   * @param {C_E} editor
   * @return {void}
   * @public
   */
  m_initialize__org_gwtproject_editor_client_Editor(editor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SimpleBeanEditorDriver.$clinit = (() =>{
    });
    SimpleBeanEditorDriver.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    EditorDriver.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_SimpleBeanEditorDriver = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_SimpleBeanEditorDriver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_SimpleBeanEditorDriver;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(SimpleBeanEditorDriver, $Util.$makeClassName('org.gwtproject.editor.client.SimpleBeanEditorDriver'));


SimpleBeanEditorDriver.$markImplementor(/** @type {Function} */ (SimpleBeanEditorDriver));


exports = SimpleBeanEditorDriver; 
//# sourceMappingURL=SimpleBeanEditorDriver.js.map