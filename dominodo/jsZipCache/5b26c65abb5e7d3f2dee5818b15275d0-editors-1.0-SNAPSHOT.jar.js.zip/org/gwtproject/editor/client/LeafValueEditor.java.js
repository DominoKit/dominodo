/**
 * @fileoverview transpiled from org.gwtproject.editor.client.LeafValueEditor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.LeafValueEditor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');


// Re-exports the implementation.
var LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor$impl');
exports = LeafValueEditor;
 