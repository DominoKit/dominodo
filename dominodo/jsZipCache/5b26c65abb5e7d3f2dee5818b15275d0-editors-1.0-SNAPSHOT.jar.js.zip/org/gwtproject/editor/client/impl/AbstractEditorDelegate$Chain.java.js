/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.AbstractEditorDelegate$Chain.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.AbstractEditorDelegate.Chain');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _EditorChain = goog.require('org.gwtproject.editor.client.CompositeEditor.EditorChain');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _LinkedHashMap = goog.require('java.util.LinkedHashMap');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _RootEditorContext = goog.require('org.gwtproject.editor.client.impl.RootEditorContext');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Chain = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate.Chain$impl');
exports = Chain;
 