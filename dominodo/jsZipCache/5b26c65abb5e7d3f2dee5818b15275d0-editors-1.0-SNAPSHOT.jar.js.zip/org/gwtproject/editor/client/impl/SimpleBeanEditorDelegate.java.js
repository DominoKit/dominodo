/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration');


// Re-exports the implementation.
var SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');
exports = SimpleBeanEditorDelegate;
 