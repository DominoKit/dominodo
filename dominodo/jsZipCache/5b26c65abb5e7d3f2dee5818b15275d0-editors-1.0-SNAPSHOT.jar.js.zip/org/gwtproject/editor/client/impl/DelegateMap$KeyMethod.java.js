/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.DelegateMap$KeyMethod.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.DelegateMap.KeyMethod');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.gwtproject.editor.client.impl.DelegateMap.KeyMethod.$LambdaAdaptor');


// Re-exports the implementation.
var KeyMethod = goog.require('org.gwtproject.editor.client.impl.DelegateMap.KeyMethod$impl');
exports = KeyMethod;
 