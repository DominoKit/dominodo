/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.Refresher.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.Refresher');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorContext = goog.require('org.gwtproject.editor.client.EditorContext');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Refresher = goog.require('org.gwtproject.editor.client.impl.Refresher$impl');
exports = Refresher;
 