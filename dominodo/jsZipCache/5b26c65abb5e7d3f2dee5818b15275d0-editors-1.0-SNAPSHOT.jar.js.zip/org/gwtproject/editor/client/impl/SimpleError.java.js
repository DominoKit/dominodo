/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.SimpleError.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.SimpleError');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _EditorError = goog.require('org.gwtproject.editor.client.EditorError');
const _j_l_String = goog.require('java.lang.String');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _$Asserts = goog.require('vmbootstrap.Asserts');


// Re-exports the implementation.
var SimpleError = goog.require('org.gwtproject.editor.client.impl.SimpleError$impl');
exports = SimpleError;
 