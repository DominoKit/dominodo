/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.Initializer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.Initializer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Refresher = goog.require('org.gwtproject.editor.client.impl.Refresher');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorContext = goog.require('org.gwtproject.editor.client.EditorContext');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Initializer = goog.require('org.gwtproject.editor.client.impl.Initializer$impl');
exports = Initializer;
 