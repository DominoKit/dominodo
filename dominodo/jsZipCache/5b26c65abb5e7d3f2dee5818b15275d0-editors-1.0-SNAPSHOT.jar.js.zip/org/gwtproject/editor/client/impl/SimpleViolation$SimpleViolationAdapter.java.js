/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.SimpleViolation$SimpleViolationAdapter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.SimpleViolation.SimpleViolationAdapter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SimpleViolation = goog.require('org.gwtproject.editor.client.impl.SimpleViolation');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var SimpleViolationAdapter = goog.require('org.gwtproject.editor.client.impl.SimpleViolation.SimpleViolationAdapter$impl');
exports = SimpleViolationAdapter;
 