/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.DirtCollector.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.impl.DirtCollector$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor$impl');

let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorContext = goog.forwardDeclare('org.gwtproject.editor.client.EditorContext$impl');
let LeafValueEditor = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor$impl');
let AbstractEditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.impl.AbstractEditorDelegate$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class DirtCollector extends EditorVisitor {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {boolean} */
    this.f_dirty__org_gwtproject_editor_client_impl_DirtCollector = false;
    /** @public {Map<LeafValueEditor<?>, *>} */
    this.f_leafValues__org_gwtproject_editor_client_impl_DirtCollector_;
  }
  
  /**
   * @return {!DirtCollector}
   * @public
   */
  static $create__() {
    DirtCollector.$clinit();
    let $instance = new DirtCollector();
    $instance.$ctor__org_gwtproject_editor_client_impl_DirtCollector__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_impl_DirtCollector__() {
    this.$ctor__org_gwtproject_editor_client_EditorVisitor__();
    this.$init__org_gwtproject_editor_client_impl_DirtCollector();
  }
  
  /**
   * @override
   * @template M_T
   * @param {EditorContext<M_T>} ctx
   * @return {void}
   * @public
   */
  m_endVisit__org_gwtproject_editor_client_EditorContext(ctx) {
    let editor = ctx.m_asLeafValueEditor__();
    if (!$Equality.$same(editor, null)) {
      this.f_leafValues__org_gwtproject_editor_client_impl_DirtCollector_.put(editor, editor.m_getValue__());
    }
    let delegate = /**@type {AbstractEditorDelegate<*, Editor>} */ ($Casts.$to(ctx.m_getEditorDelegate__(), AbstractEditorDelegate));
    if (!$Equality.$same(delegate, null)) {
      this.f_dirty__org_gwtproject_editor_client_impl_DirtCollector = !!(+this.f_dirty__org_gwtproject_editor_client_impl_DirtCollector | +delegate.m_isDirty__());
    }
  }
  
  /**
   * @return {Map<LeafValueEditor<?>, *>}
   * @public
   */
  m_getLeafValues__() {
    return this.f_leafValues__org_gwtproject_editor_client_impl_DirtCollector_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isDirty__() {
    return this.f_dirty__org_gwtproject_editor_client_impl_DirtCollector;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_gwtproject_editor_client_impl_DirtCollector() {
    this.f_leafValues__org_gwtproject_editor_client_impl_DirtCollector_ = /**@type {!HashMap<LeafValueEditor<?>, *>} */ (HashMap.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DirtCollector.$clinit = (() =>{
    });
    DirtCollector.$loadModules();
    EditorVisitor.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DirtCollector;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DirtCollector);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HashMap = goog.module.get('java.util.HashMap$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    AbstractEditorDelegate = goog.module.get('org.gwtproject.editor.client.impl.AbstractEditorDelegate$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(DirtCollector, $Util.$makeClassName('org.gwtproject.editor.client.impl.DirtCollector'));




exports = DirtCollector; 
//# sourceMappingURL=DirtCollector.js.map