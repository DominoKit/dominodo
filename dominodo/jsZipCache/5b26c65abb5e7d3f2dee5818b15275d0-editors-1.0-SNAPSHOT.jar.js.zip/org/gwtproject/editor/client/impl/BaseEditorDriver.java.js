/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.BaseEditorDriver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.BaseEditorDriver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IllegalStateException = goog.require('java.lang.IllegalStateException');
const _Iterable = goog.require('java.lang.Iterable');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorDriver = goog.require('org.gwtproject.editor.client.EditorDriver');
const _EditorError = goog.require('org.gwtproject.editor.client.EditorError');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _DelegateMap = goog.require('org.gwtproject.editor.client.impl.DelegateMap');
const _KeyMethod = goog.require('org.gwtproject.editor.client.impl.DelegateMap.KeyMethod');
const _DirtCollector = goog.require('org.gwtproject.editor.client.impl.DirtCollector');
const _ErrorCollector = goog.require('org.gwtproject.editor.client.impl.ErrorCollector');
const _Flusher = goog.require('org.gwtproject.editor.client.impl.Flusher');
const _Initializer = goog.require('org.gwtproject.editor.client.impl.Initializer');
const _SimpleViolation = goog.require('org.gwtproject.editor.client.impl.SimpleViolation');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var BaseEditorDriver = goog.require('org.gwtproject.editor.client.impl.BaseEditorDriver$impl');
exports = BaseEditorDriver;
 