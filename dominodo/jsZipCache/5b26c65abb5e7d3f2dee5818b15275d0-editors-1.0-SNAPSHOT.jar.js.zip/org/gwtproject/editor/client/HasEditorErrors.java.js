/**
 * @fileoverview transpiled from org.gwtproject.editor.client.HasEditorErrors.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.HasEditorErrors');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _List = goog.require('java.util.List');
const _EditorError = goog.require('org.gwtproject.editor.client.EditorError');
const _$LambdaAdaptor = goog.require('org.gwtproject.editor.client.HasEditorErrors.$LambdaAdaptor');


// Re-exports the implementation.
var HasEditorErrors = goog.require('org.gwtproject.editor.client.HasEditorErrors$impl');
exports = HasEditorErrors;
 