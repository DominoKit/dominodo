/**
 * @fileoverview transpiled from org.gwtproject.editor.client.CompositeEditor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.CompositeEditor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ValueAwareEditor = goog.require('org.gwtproject.editor.client.ValueAwareEditor');
const _EditorChain = goog.require('org.gwtproject.editor.client.CompositeEditor.EditorChain');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');


// Re-exports the implementation.
var CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor$impl');
exports = CompositeEditor;
 