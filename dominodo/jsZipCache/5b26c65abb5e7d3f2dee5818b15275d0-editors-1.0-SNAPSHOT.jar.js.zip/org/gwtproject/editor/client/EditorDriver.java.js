/**
 * @fileoverview transpiled from org.gwtproject.editor.client.EditorDriver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.EditorDriver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Iterable = goog.require('java.lang.Iterable');
const _List = goog.require('java.util.List');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _EditorError = goog.require('org.gwtproject.editor.client.EditorError');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');


// Re-exports the implementation.
var EditorDriver = goog.require('org.gwtproject.editor.client.EditorDriver$impl');
exports = EditorDriver;
 