/**
 * @fileoverview transpiled from org.gwtproject.editor.client.CompositeEditor$EditorChain.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.CompositeEditor.EditorChain');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');


// Re-exports the implementation.
var EditorChain = goog.require('org.gwtproject.editor.client.CompositeEditor.EditorChain$impl');
exports = EditorChain;
 