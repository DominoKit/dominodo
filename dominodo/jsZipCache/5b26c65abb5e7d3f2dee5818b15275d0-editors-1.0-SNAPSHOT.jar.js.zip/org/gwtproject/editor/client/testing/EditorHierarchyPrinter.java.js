/**
 * @fileoverview transpiled from org.gwtproject.editor.client.testing.EditorHierarchyPrinter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.testing.EditorHierarchyPrinter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _j_l_String = goog.require('java.lang.String');
const _StringBuilder = goog.require('java.lang.StringBuilder');
const _$Equality = goog.require('nativebootstrap.Equality');
const _EditorContext = goog.require('org.gwtproject.editor.client.EditorContext');
const _EditorDriver = goog.require('org.gwtproject.editor.client.EditorDriver');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var EditorHierarchyPrinter = goog.require('org.gwtproject.editor.client.testing.EditorHierarchyPrinter$impl');
exports = EditorHierarchyPrinter;
 