/**
 * @fileoverview transpiled from org.gwtproject.editor.client.testing.MockSimpleBeanEditorDriver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.testing.MockSimpleBeanEditorDriver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.SimpleBeanEditorDriver');
const _Iterable = goog.require('java.lang.Iterable');
const _Collections = goog.require('java.util.Collections');
const _List = goog.require('java.util.List');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorError = goog.require('org.gwtproject.editor.client.EditorError');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');


// Re-exports the implementation.
var MockSimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.testing.MockSimpleBeanEditorDriver$impl');
exports = MockSimpleBeanEditorDriver;
 