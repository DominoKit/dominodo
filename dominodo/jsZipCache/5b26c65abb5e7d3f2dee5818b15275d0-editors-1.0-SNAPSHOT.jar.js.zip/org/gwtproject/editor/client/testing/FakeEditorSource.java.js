/**
 * @fileoverview transpiled from org.gwtproject.editor.client.testing.FakeEditorSource.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.testing.FakeEditorSource');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EditorSource = goog.require('org.gwtproject.editor.client.adapters.EditorSource');
const _Integer = goog.require('java.lang.Integer');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _FakeLeafValueEditor = goog.require('org.gwtproject.editor.client.testing.FakeLeafValueEditor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var FakeEditorSource = goog.require('org.gwtproject.editor.client.testing.FakeEditorSource$impl');
exports = FakeEditorSource;
 