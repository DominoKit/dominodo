/**
 * @fileoverview transpiled from org.gwtproject.editor.client.testing.FakeEditorContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.testing.FakeEditorContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _EditorContext = goog.require('org.gwtproject.editor.client.EditorContext');
const _Class = goog.require('java.lang.Class');
const _CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorDelegate = goog.require('org.gwtproject.editor.client.EditorDelegate');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _HasEditorDelegate = goog.require('org.gwtproject.editor.client.HasEditorDelegate');
const _HasEditorErrors = goog.require('org.gwtproject.editor.client.HasEditorErrors');
const _LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor');
const _ValueAwareEditor = goog.require('org.gwtproject.editor.client.ValueAwareEditor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var FakeEditorContext = goog.require('org.gwtproject.editor.client.testing.FakeEditorContext$impl');
exports = FakeEditorContext;
 