/**
 * @fileoverview transpiled from org.gwtproject.editor.client.LeafValueEditor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.LeafValueEditor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Editor = goog.require('org.gwtproject.editor.client.Editor$impl');


/**
 * @interface
 * @template C_T
 * @extends {Editor<C_T>}
 */
class LeafValueEditor {
  /**
   * @abstract
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(value) {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_getValue__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    LeafValueEditor.$clinit = (() =>{
    });
    LeafValueEditor.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Editor.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_LeafValueEditor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_LeafValueEditor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_LeafValueEditor;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(LeafValueEditor, $Util.$makeClassName('org.gwtproject.editor.client.LeafValueEditor'));


LeafValueEditor.$markImplementor(/** @type {Function} */ (LeafValueEditor));


exports = LeafValueEditor; 
//# sourceMappingURL=LeafValueEditor.js.map