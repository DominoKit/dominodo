/**
 * @fileoverview transpiled from org.gwtproject.editor.client.HasEditorDelegate.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.HasEditorDelegate');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorDelegate = goog.require('org.gwtproject.editor.client.EditorDelegate');
const _$LambdaAdaptor = goog.require('org.gwtproject.editor.client.HasEditorDelegate.$LambdaAdaptor');


// Re-exports the implementation.
var HasEditorDelegate = goog.require('org.gwtproject.editor.client.HasEditorDelegate$impl');
exports = HasEditorDelegate;
 