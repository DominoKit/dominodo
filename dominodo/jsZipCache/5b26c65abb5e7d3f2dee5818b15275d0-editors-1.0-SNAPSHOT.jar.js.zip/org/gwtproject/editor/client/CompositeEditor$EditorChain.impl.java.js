/**
 * @fileoverview transpiled from org.gwtproject.editor.client.CompositeEditor$EditorChain.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.CompositeEditor.EditorChain$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');


/**
 * @interface
 * @template C_EditorChain_C, C_EditorChain_E
 */
class EditorChain {
  /**
   * @abstract
   * @param {C_EditorChain_C} object
   * @param {C_EditorChain_E} subEditor
   * @return {void}
   * @public
   */
  m_attach__java_lang_Object__org_gwtproject_editor_client_Editor(object, subEditor) {
  }
  
  /**
   * @abstract
   * @param {C_EditorChain_E} subEditor
   * @return {void}
   * @public
   */
  m_detach__org_gwtproject_editor_client_Editor(subEditor) {
  }
  
  /**
   * @abstract
   * @param {C_EditorChain_E} subEditor
   * @return {C_EditorChain_C}
   * @public
   */
  m_getValue__org_gwtproject_editor_client_Editor(subEditor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditorChain.$clinit = (() =>{
    });
    EditorChain.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_CompositeEditor_EditorChain = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_CompositeEditor_EditorChain;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_CompositeEditor_EditorChain;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(EditorChain, $Util.$makeClassName('org.gwtproject.editor.client.CompositeEditor$EditorChain'));


EditorChain.$markImplementor(/** @type {Function} */ (EditorChain));


exports = EditorChain; 
//# sourceMappingURL=CompositeEditor$EditorChain.js.map