/**
 * @fileoverview transpiled from org.dominokit.samples.Task.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.Task$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let Project = goog.forwardDeclare('org.dominokit.samples.Project$impl');
let Status = goog.forwardDeclare('org.dominokit.samples.Status$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


class Task extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_title__org_dominokit_samples_Task_;
    /** @public {?string} */
    this.f_description__org_dominokit_samples_Task_;
    /** @public {Priority} */
    this.f_priority__org_dominokit_samples_Task_;
    /** @public {Date} */
    this.f_dueDate__org_dominokit_samples_Task_;
    /** @public {List<?string>} */
    this.f_tags__org_dominokit_samples_Task_;
    /** @public {Status} */
    this.f_status__org_dominokit_samples_Task_;
    /** @public {Project} */
    this.f_project__org_dominokit_samples_Task_;
    /** @public {List<?string>} */
    this.f_attachments__org_dominokit_samples_Task_;
  }
  
  /**
   * @return {!Task}
   * @public
   */
  static $create__() {
    Task.$clinit();
    let $instance = new Task();
    $instance.$ctor__org_dominokit_samples_Task__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_Task__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_samples_Task();
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getTitle__() {
    return this.f_title__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {?string} title
   * @return {void}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_title__org_dominokit_samples_Task_ = title;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getDescription__() {
    return this.f_description__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {?string} description
   * @return {void}
   * @public
   */
  m_setDescription__java_lang_String(description) {
    this.f_description__org_dominokit_samples_Task_ = description;
  }
  
  /**
   * @return {Priority}
   * @public
   */
  m_getPriority__() {
    return this.f_priority__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {Priority} priority
   * @return {void}
   * @public
   */
  m_setPriority__org_dominokit_samples_Priority(priority) {
    this.f_priority__org_dominokit_samples_Task_ = priority;
  }
  
  /**
   * @return {Date}
   * @public
   */
  m_getDueDate__() {
    return this.f_dueDate__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {Date} dueDate
   * @return {void}
   * @public
   */
  m_setDueDate__java_util_Date(dueDate) {
    this.f_dueDate__org_dominokit_samples_Task_ = dueDate;
  }
  
  /**
   * @return {List<?string>}
   * @public
   */
  m_getTags__() {
    return this.f_tags__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {List<?string>} tags
   * @return {void}
   * @public
   */
  m_setTags__java_util_List(tags) {
    this.f_tags__org_dominokit_samples_Task_ = tags;
  }
  
  /**
   * @return {Status}
   * @public
   */
  m_getStatus__() {
    return this.f_status__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {Status} status
   * @return {void}
   * @public
   */
  m_setStatus__org_dominokit_samples_Status(status) {
    this.f_status__org_dominokit_samples_Task_ = status;
  }
  
  /**
   * @return {Project}
   * @public
   */
  m_getProject__() {
    return this.f_project__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {Project} project
   * @return {void}
   * @public
   */
  m_setProject__org_dominokit_samples_Project(project) {
    this.f_project__org_dominokit_samples_Task_ = project;
  }
  
  /**
   * @return {List<?string>}
   * @public
   */
  m_getAttachments__() {
    return this.f_attachments__org_dominokit_samples_Task_;
  }
  
  /**
   * @param {List<?string>} attachments
   * @return {void}
   * @public
   */
  m_setAttachments__java_util_List(attachments) {
    this.f_attachments__org_dominokit_samples_Task_ = attachments;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isActive__() {
    return $Objects.m_equals__java_lang_Object__java_lang_Object(Status.f_ACTIVE__org_dominokit_samples_Status, this.m_getStatus__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_Task() {
    this.f_tags__org_dominokit_samples_Task_ = /**@type {!ArrayList<?string>} */ (ArrayList.$create__());
    this.f_status__org_dominokit_samples_Task_ = Status.f_ACTIVE__org_dominokit_samples_Status;
    this.f_attachments__org_dominokit_samples_Task_ = /**@type {!ArrayList<?string>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Task.$clinit = (() =>{
    });
    Task.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Task;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Task);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Status = goog.module.get('org.dominokit.samples.Status$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(Task, $Util.$makeClassName('org.dominokit.samples.Task'));




exports = Task; 
//# sourceMappingURL=Task.js.map