package org.dominokit.samples;

public enum Priority {

    IMPORTANT, NORMAL;
}
