/**
 * @fileoverview transpiled from org.dominokit.samples.Task.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.Task');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ArrayList = goog.require('java.util.ArrayList');
const _Date = goog.require('java.util.Date');
const _List = goog.require('java.util.List');
const _Priority = goog.require('org.dominokit.samples.Priority');
const _Project = goog.require('org.dominokit.samples.Project');
const _Status = goog.require('org.dominokit.samples.Status');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var Task = goog.require('org.dominokit.samples.Task$impl');
exports = Task;
 