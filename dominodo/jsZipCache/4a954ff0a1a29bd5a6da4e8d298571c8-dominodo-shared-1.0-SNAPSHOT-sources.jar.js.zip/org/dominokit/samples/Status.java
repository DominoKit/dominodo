package org.dominokit.samples;

public enum Status {

    ACTIVE, COMPLETED;
}
