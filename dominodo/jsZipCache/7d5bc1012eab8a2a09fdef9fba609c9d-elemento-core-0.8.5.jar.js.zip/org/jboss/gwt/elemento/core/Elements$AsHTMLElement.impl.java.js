/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements$AsHTMLElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.Elements.AsHTMLElement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const j_u_function_Function = goog.require('java.util.function.Function$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_AsHTMLElement_T
 * @implements {j_u_function_Function<C_AsHTMLElement_T, HTMLElement>}
  */
class AsHTMLElement extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @template C_AsHTMLElement_T
   * @return {!AsHTMLElement<C_AsHTMLElement_T>}
   * @public
   */
  static $create__() {
    AsHTMLElement.$clinit();
    let $instance = new AsHTMLElement();
    $instance.$ctor__org_jboss_gwt_elemento_core_Elements_AsHTMLElement__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_Elements_AsHTMLElement__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {C_AsHTMLElement_T} t
   * @return {HTMLElement}
   * @public
   */
  m_apply__elemental2_dom_Node(t) {
    return /**@type {HTMLElement} */ ($Casts.$to(t, $Overlay));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @template M_V
   * @param {j_u_function_Function<?, ?>} arg0
   * @return {j_u_function_Function<C_AsHTMLElement_T, M_V>}
   * @public
   */
  m_andThen__java_util_function_Function(arg0) {
    return /**@type {j_u_function_Function<C_AsHTMLElement_T, *>} */ (j_u_function_Function.m_andThen__$default__java_util_function_Function__java_util_function_Function(this, arg0));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @template M_V
   * @param {j_u_function_Function<?, ?>} arg0
   * @return {j_u_function_Function<M_V, HTMLElement>}
   * @public
   */
  m_compose__java_util_function_Function(arg0) {
    return /**@type {j_u_function_Function<*, HTMLElement>} */ (j_u_function_Function.m_compose__$default__java_util_function_Function__java_util_function_Function(this, arg0));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {HTMLElement}
   * @public
   */
  m_apply__java_lang_Object(arg0) {
    return this.m_apply__elemental2_dom_Node(/**@type {C_AsHTMLElement_T} */ ($Casts.$to(arg0, Node_$Overlay)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AsHTMLElement.$clinit = (() =>{
    });
    AsHTMLElement.$loadModules();
    j_l_Object.$clinit();
    j_u_function_Function.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AsHTMLElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AsHTMLElement);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    Node_$Overlay = goog.module.get('elemental2.dom.Node.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(AsHTMLElement, $Util.$makeClassName('org.jboss.gwt.elemento.core.Elements$AsHTMLElement'));


j_u_function_Function.$markImplementor(AsHTMLElement);


exports = AsHTMLElement; 
//# sourceMappingURL=Elements$AsHTMLElement.js.map