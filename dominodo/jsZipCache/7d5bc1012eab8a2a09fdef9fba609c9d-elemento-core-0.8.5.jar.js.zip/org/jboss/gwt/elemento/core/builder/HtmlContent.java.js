/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.HtmlContent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.builder.HtmlContent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _TextContent = goog.require('org.jboss.gwt.elemento.core.builder.TextContent');
const _Document_$Overlay = goog.require('elemental2.dom.Document.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Iterable = goog.require('java.lang.Iterable');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');
const _HasElements = goog.require('org.jboss.gwt.elemento.core.HasElements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _TypedBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TypedBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var HtmlContent = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContent$impl');
exports = HtmlContent;
 