/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.HasElements$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.HasElements.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasElements = goog.require('org.jboss.gwt.elemento.core.HasElements');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Iterable = goog.require('java.lang.Iterable');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.jboss.gwt.elemento.core.HasElements.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 