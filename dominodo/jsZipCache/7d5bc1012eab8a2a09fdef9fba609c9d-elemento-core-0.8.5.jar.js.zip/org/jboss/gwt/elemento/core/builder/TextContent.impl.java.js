/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.TextContent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.TextContent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const TypedBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TypedBuilder$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @interface
 * @template C_E, C_B
 * @extends {TypedBuilder<C_E, C_B>}
 */
class TextContent {
  /**
   * @abstract
   * @param {?string} text
   * @return {C_B}
   * @public
   */
  m_textContent__java_lang_String(text) {
  }
  
  /**
   * @template C_E, C_B
   * @param {TextContent<C_E, C_B>} $thisArg
   * @param {?string} text
   * @return {C_B}
   * @public
   */
  static m_textContent__$default__org_jboss_gwt_elemento_core_builder_TextContent__java_lang_String($thisArg, text) {
    TextContent.$clinit();
    /**@type {HTMLElement} */ ($Casts.$to($thisArg.m_get__(), $Overlay)).textContent = text;
    return $thisArg.m_that__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TextContent.$clinit = (() =>{
    });
    TextContent.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    TypedBuilder.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_TextContent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_builder_TextContent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_TextContent;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(TextContent, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.TextContent'));


TextContent.$markImplementor(/** @type {Function} */ (TextContent));


exports = TextContent; 
//# sourceMappingURL=TextContent.js.map