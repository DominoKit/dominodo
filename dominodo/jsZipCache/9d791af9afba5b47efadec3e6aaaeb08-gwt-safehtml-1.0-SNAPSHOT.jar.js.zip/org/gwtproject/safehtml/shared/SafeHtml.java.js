/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtml.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtml');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Serializable = goog.require('java.io.Serializable');
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.gwtproject.safehtml.shared.SafeHtml.$LambdaAdaptor');


// Re-exports the implementation.
var SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml$impl');
exports = SafeHtml;
 