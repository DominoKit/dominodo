/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.annotations.IsSafeHtml.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.annotations.IsSafeHtml');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('org.gwtproject.safehtml.shared.annotations.IsSafeHtml.$LambdaAdaptor');


// Re-exports the implementation.
var IsSafeHtml = goog.require('org.gwtproject.safehtml.shared.annotations.IsSafeHtml$impl');
exports = IsSafeHtml;
 