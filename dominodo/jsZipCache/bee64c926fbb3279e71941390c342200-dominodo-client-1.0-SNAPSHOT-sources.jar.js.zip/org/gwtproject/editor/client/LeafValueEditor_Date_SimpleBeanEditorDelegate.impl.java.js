/**
 * @fileoverview transpiled from org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let LeafValueEditor = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class LeafValueEditor__Date__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {LeafValueEditor} */
    this.f_editor__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate_;
    /** @public {Date} */
    this.f_object__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!LeafValueEditor__Date__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    LeafValueEditor__Date__SimpleBeanEditorDelegate.$clinit();
    let $instance = new LeafValueEditor__Date__SimpleBeanEditorDelegate();
    $instance.$ctor__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {LeafValueEditor}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate_ = /**@type {LeafValueEditor} */ ($Casts.$to(editor, LeafValueEditor));
  }
  
  /**
   * @override
   * @return {Date}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_gwtproject_editor_client_LeafValueEditor_Date_SimpleBeanEditorDelegate_ = /**@type {Date} */ ($Casts.$to(object, Date));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    LeafValueEditor__Date__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    LeafValueEditor__Date__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LeafValueEditor__Date__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LeafValueEditor__Date__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Date = goog.module.get('java.util.Date$impl');
    LeafValueEditor = goog.module.get('org.gwtproject.editor.client.LeafValueEditor$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(LeafValueEditor__Date__SimpleBeanEditorDelegate, $Util.$makeClassName('org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate'));




exports = LeafValueEditor__Date__SimpleBeanEditorDelegate; 
//# sourceMappingURL=LeafValueEditor_Date_SimpleBeanEditorDelegate.js.map