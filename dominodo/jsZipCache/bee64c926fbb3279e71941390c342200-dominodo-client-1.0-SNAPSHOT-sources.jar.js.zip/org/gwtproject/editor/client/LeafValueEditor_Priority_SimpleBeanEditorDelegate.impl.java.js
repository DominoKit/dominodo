/**
 * @fileoverview transpiled from org.gwtproject.editor.client.LeafValueEditor_Priority_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.LeafValueEditor_Priority_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let LeafValueEditor = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class LeafValueEditor__Priority__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {LeafValueEditor} */
    this.f_editor__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate_;
    /** @public {Priority} */
    this.f_object__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!LeafValueEditor__Priority__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    LeafValueEditor__Priority__SimpleBeanEditorDelegate.$clinit();
    let $instance = new LeafValueEditor__Priority__SimpleBeanEditorDelegate();
    $instance.$ctor__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {LeafValueEditor}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate_ = /**@type {LeafValueEditor} */ ($Casts.$to(editor, LeafValueEditor));
  }
  
  /**
   * @override
   * @return {Priority}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_gwtproject_editor_client_LeafValueEditor_Priority_SimpleBeanEditorDelegate_ = /**@type {Priority} */ ($Casts.$to(object, Priority));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    LeafValueEditor__Priority__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    LeafValueEditor__Priority__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LeafValueEditor__Priority__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LeafValueEditor__Priority__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Priority = goog.module.get('org.dominokit.samples.Priority$impl');
    LeafValueEditor = goog.module.get('org.gwtproject.editor.client.LeafValueEditor$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(LeafValueEditor__Priority__SimpleBeanEditorDelegate, $Util.$makeClassName('org.gwtproject.editor.client.LeafValueEditor_Priority_SimpleBeanEditorDelegate'));




exports = LeafValueEditor__Priority__SimpleBeanEditorDelegate; 
//# sourceMappingURL=LeafValueEditor_Priority_SimpleBeanEditorDelegate.js.map