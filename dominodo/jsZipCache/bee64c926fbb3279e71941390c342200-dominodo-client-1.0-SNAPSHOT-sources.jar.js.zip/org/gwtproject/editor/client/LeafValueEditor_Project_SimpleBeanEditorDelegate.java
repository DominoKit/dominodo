package org.gwtproject.editor.client;

import java.lang.Object;
import java.lang.Override;
import javax.annotation.Generated;
import org.dominokit.samples.Project;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class LeafValueEditor_Project_SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  private LeafValueEditor editor;

  private Project object;

  @Override
  protected LeafValueEditor getEditor() {
    return editor;
  }

  @Override
  protected void setEditor(Editor editor) {
    this.editor = (LeafValueEditor) editor;
  }

  @Override
  public Project getObject() {
    return object;
  }

  @Override
  protected void setObject(Object object) {
    this.object = (Project) object;
  }

  @Override
  protected void initializeSubDelegates() {
  }

  @Override
  public void accept(EditorVisitor visitor) {
  }
}
