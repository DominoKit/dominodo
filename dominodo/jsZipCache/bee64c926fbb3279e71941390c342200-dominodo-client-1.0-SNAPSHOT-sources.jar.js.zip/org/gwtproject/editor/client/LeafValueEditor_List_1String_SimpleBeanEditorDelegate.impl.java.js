/**
 * @fileoverview transpiled from org.gwtproject.editor.client.LeafValueEditor_List_1String_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.LeafValueEditor_List_1String_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let LeafValueEditor = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class LeafValueEditor__List__1String__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {LeafValueEditor} */
    this.f_editor__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate_;
    /** @public {List<?string>} */
    this.f_object__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!LeafValueEditor__List__1String__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    LeafValueEditor__List__1String__SimpleBeanEditorDelegate.$clinit();
    let $instance = new LeafValueEditor__List__1String__SimpleBeanEditorDelegate();
    $instance.$ctor__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {LeafValueEditor}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate_ = /**@type {LeafValueEditor} */ ($Casts.$to(editor, LeafValueEditor));
  }
  
  /**
   * @override
   * @return {List<?string>}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_gwtproject_editor_client_LeafValueEditor_List_1String_SimpleBeanEditorDelegate_ = /**@type {List<?string>} */ ($Casts.$to(object, List));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    LeafValueEditor__List__1String__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    LeafValueEditor__List__1String__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LeafValueEditor__List__1String__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LeafValueEditor__List__1String__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    List = goog.module.get('java.util.List$impl');
    LeafValueEditor = goog.module.get('org.gwtproject.editor.client.LeafValueEditor$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(LeafValueEditor__List__1String__SimpleBeanEditorDelegate, $Util.$makeClassName('org.gwtproject.editor.client.LeafValueEditor_List_1String_SimpleBeanEditorDelegate'));




exports = LeafValueEditor__List__1String__SimpleBeanEditorDelegate; 
//# sourceMappingURL=LeafValueEditor_List_1String_SimpleBeanEditorDelegate.js.map