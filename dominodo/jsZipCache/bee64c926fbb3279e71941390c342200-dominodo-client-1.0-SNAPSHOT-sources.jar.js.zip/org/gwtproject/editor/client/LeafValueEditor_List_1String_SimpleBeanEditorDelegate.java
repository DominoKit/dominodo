package org.gwtproject.editor.client;

import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import javax.annotation.Generated;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class LeafValueEditor_List_1String_SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  private LeafValueEditor editor;

  private List<String> object;

  @Override
  protected LeafValueEditor getEditor() {
    return editor;
  }

  @Override
  protected void setEditor(Editor editor) {
    this.editor = (LeafValueEditor) editor;
  }

  @Override
  public List<String> getObject() {
    return object;
  }

  @Override
  protected void setObject(Object object) {
    this.object = (List<String>) object;
  }

  @Override
  protected void initializeSubDelegates() {
  }

  @Override
  public void accept(EditorVisitor visitor) {
  }
}
