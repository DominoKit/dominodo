/**
 * @fileoverview transpiled from org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate');
const _Date = goog.require('java.util.Date');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var LeafValueEditor__Date__SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate$impl');
exports = LeafValueEditor__Date__SimpleBeanEditorDelegate;
 