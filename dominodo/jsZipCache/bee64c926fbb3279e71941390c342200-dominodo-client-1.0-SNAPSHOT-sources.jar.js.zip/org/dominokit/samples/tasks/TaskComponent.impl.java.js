/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TaskComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.TaskComponent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasTask = goog.require('org.dominokit.samples.tasks.HasTask$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let Paragraph = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Paragraph$impl');
let Animation = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation$impl');
let CompleteCallback = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let HeaderAction = goog.forwardDeclare('org.dominokit.domino.ui.cards.HeaderAction$impl');
let DatePicker = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker$impl');
let DateDayClickedHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let Formatter = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.Formatter$impl');
let ConfirmationDialog = goog.forwardDeclare('org.dominokit.domino.ui.dialogs.ConfirmationDialog$impl');
let ConfirmHandler = goog.forwardDeclare('org.dominokit.domino.ui.dialogs.ConfirmationDialog.ConfirmHandler$impl');
let RejectHandler = goog.forwardDeclare('org.dominokit.domino.ui.dialogs.ConfirmationDialog.RejectHandler$impl');
let DropDownMenu = goog.forwardDeclare('org.dominokit.domino.ui.dropdown.DropDownMenu$impl');
let DropDownPosition = goog.forwardDeclare('org.dominokit.domino.ui.dropdown.DropDownPosition$impl');
let DropdownAction = goog.forwardDeclare('org.dominokit.domino.ui.dropdown.DropdownAction$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ModalDialog = goog.forwardDeclare('org.dominokit.domino.ui.modals.ModalDialog$impl');
let Notification = goog.forwardDeclare('org.dominokit.domino.ui.notifications.Notification$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
let ScreenMedia = goog.forwardDeclare('org.dominokit.domino.ui.utils.ScreenMedia$impl');
let HasTaskUiHandlers = goog.forwardDeclare('org.dominokit.samples.HasTaskUiHandlers$impl');
let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let AttachDialogComponent = goog.forwardDeclare('org.dominokit.samples.attachments.AttachDialogComponent$impl');
let CompleteHandler = goog.forwardDeclare('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler$impl');
let AttachmentPanelComponent = goog.forwardDeclare('org.dominokit.samples.attachments.AttachmentPanelComponent$impl');
let FileUploadComponent = goog.forwardDeclare('org.dominokit.samples.attachments.FileUploadComponent$impl');
let TagsPanelComponent = goog.forwardDeclare('org.dominokit.samples.tasks.TagsPanelComponent$impl');
let $LambdaAdaptor$19 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$19$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$20$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$21$impl');
let $LambdaAdaptor$22 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$22$impl');
let $LambdaAdaptor$23 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$23$impl');
let $LambdaAdaptor$24 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$24$impl');
let $LambdaAdaptor$25 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$25$impl');
let $LambdaAdaptor$26 = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$26$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let DateTimeFormatInfo__factory = goog.forwardDeclare('org.gwtproject.i18n.shared.impl.cldr.DateTimeFormatInfo_factory$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, TaskComponent>}
 * @implements {HasTask}
  */
class TaskComponent extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HasTaskUiHandlers} */
    this.f_taskUiHandlers__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {HtmlContentBuilder<HTMLElement>} */
    this.f_dueDateElement__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {DateTimeFormatInfo} */
    this.f_dateTimeFormatInfo__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {Card} */
    this.f_card__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {Task} */
    this.f_task__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {DatePicker} */
    this.f_datePicker__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {Popover} */
    this.f_datePickerPopup__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {ColorScheme} */
    this.f_projectColor__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {AttachmentPanelComponent} */
    this.f_attachmentPanel__org_dominokit_samples_tasks_TaskComponent_;
    /** @public {Icon} */
    this.f_importantIcon__org_dominokit_samples_tasks_TaskComponent_;
  }
  
  /**
   * @param {Task} task
   * @param {HasTaskUiHandlers} taskUiHandlers
   * @return {TaskComponent}
   * @public
   */
  static m_create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers) {
    TaskComponent.$clinit();
    return TaskComponent.$create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers);
  }
  
  /**
   * @param {Task} task
   * @param {HasTaskUiHandlers} taskUiHandlers
   * @return {!TaskComponent}
   * @public
   */
  static $create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers) {
    TaskComponent.$clinit();
    let $instance = new TaskComponent();
    $instance.$ctor__org_dominokit_samples_tasks_TaskComponent__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers);
    return $instance;
  }
  
  /**
   * @param {Task} task
   * @param {HasTaskUiHandlers} taskUiHandlers
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_TaskComponent__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_samples_tasks_TaskComponent();
    this.f_task__org_dominokit_samples_tasks_TaskComponent_ = task;
    this.f_taskUiHandlers__org_dominokit_samples_tasks_TaskComponent_ = taskUiHandlers;
    this.f_projectColor__org_dominokit_samples_tasks_TaskComponent_ = ColorScheme.m_valueOf__java_lang_String(task.m_getProject__().m_getColor__());
    this.f_dueDateElement__org_dominokit_samples_tasks_TaskComponent_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_small__().m_textContent__java_lang_String(this.m_formatDate__java_util_Date_$p_org_dominokit_samples_tasks_TaskComponent(task.m_getDueDate__())), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_pull_right__org_dominokit_domino_ui_style_Styles, "due-date"], j_l_String))), HtmlContentBuilder));
    this.f_datePicker__org_dominokit_samples_tasks_TaskComponent_ = DatePicker.m_create__().m_hideHeaderPanel__().m_setDateTimeFormatInfo__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.f_dateTimeFormatInfo__org_dominokit_samples_tasks_TaskComponent_).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(this.f_projectColor__org_dominokit_samples_tasks_TaskComponent_).m_hideCloseButton__().m_hideClearButton__().m_addDateDayClickHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler(DateDayClickedHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo1) =>{
      this.f_datePickerPopup__org_dominokit_samples_tasks_TaskComponent_.m_close__();
    }))).m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date$1$, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      this.f_dueDateElement__org_dominokit_samples_tasks_TaskComponent_.m_textContent__java_lang_String(this.m_formatDate__java_util_Date_$p_org_dominokit_samples_tasks_TaskComponent(date$1$));
      task.m_setDueDate__java_util_Date(date$1$);
    })));
    let projectName = Badge.m_create__java_lang_String(task.m_getProject__().m_getName__()).m_setBackground__org_dominokit_domino_ui_style_Color(this.f_projectColor__org_dominokit_samples_tasks_TaskComponent_.m_color__());
    this.f_importantIcon__org_dominokit_samples_tasks_TaskComponent_ = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_priority_high__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color), Icon)).m_setTooltip__java_lang_String("This task is important"), Icon)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Icon> */ style1) =>{
      style1.m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles);
    }))), Icon)).m_collapse__(), Icon));
    this.f_attachmentPanel__org_dominokit_samples_tasks_TaskComponent_ = AttachmentPanelComponent.m_create__org_dominokit_samples_Task(task);
    this.f_card__org_dominokit_samples_tasks_TaskComponent_ = /**@type {Card} */ ($Casts.$to(Card.m_create__java_lang_String(task.m_getTitle__()).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_setProperty__java_lang_String__java_lang_String("border-left", "5px solid " + j_l_String.m_valueOf__java_lang_Object(this.f_projectColor__org_dominokit_samples_tasks_TaskComponent_.m_color__().m_getHex__()));
    }))), Card)).m_appendDescriptionChild__org_jboss_gwt_elemento_core_IsElement(projectName).m_appendDescriptionChild__org_jboss_gwt_elemento_core_IsElement(this.f_dueDateElement__org_dominokit_samples_tasks_TaskComponent_).m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(/**@type {HeaderAction} */ ($Casts.$to(/**@type {HeaderAction} */ ($Casts.$to(HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_more_vert__()).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_MEDIUM_AND_UP__org_dominokit_domino_ui_utils_ScreenMedia), HeaderAction)).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** HeaderAction */ element) =>{
      let menu = this.m_createDropDownMenu__org_dominokit_domino_ui_cards_HeaderAction_$p_org_dominokit_samples_tasks_TaskComponent(element);
      element.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$19(((/** Event */ evt) =>{
        evt.stopPropagation();
        menu.m_open__();
      })));
    }))), HeaderAction))).m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(/**@type {HeaderAction} */ ($Casts.$to(/**@type {HeaderAction} */ ($Casts.$to(HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(/**@type {BaseIcon<BaseIcon>} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_priority_high__().m_setTooltip__java_lang_String("Toggle priority"), BaseIcon))).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_SMALL_AND_DOWN__org_dominokit_domino_ui_utils_ScreenMedia), HeaderAction)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$20(((/** Event */ evt$1$) =>{
      this.m_updatePriority___$p_org_dominokit_samples_tasks_TaskComponent();
    }))), HeaderAction))).m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(/**@type {HeaderAction} */ ($Casts.$to(/**@type {HeaderAction} */ ($Casts.$to(HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(/**@type {BaseIcon<BaseIcon>} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_delete__().m_setTooltip__java_lang_String("Delete task"), BaseIcon))).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_SMALL_AND_DOWN__org_dominokit_domino_ui_utils_ScreenMedia), HeaderAction)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$21(((/** Event */ evt$2$) =>{
      this.m_showConfirmationDialog___$p_org_dominokit_samples_tasks_TaskComponent();
    }))), HeaderAction))).m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(/**@type {HeaderAction} */ ($Casts.$to(/**@type {HeaderAction} */ ($Casts.$to(HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(/**@type {BaseIcon<BaseIcon>} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_edit__().m_setTooltip__java_lang_String("Edit task"), BaseIcon))).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_SMALL_AND_DOWN__org_dominokit_domino_ui_utils_ScreenMedia), HeaderAction)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$22(((/** Event */ evt$3$) =>{
      taskUiHandlers.m_onEditTask__org_dominokit_samples_Task(task);
    }))), HeaderAction))).m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(/**@type {HeaderAction} */ ($Casts.$to(/**@type {HeaderAction} */ ($Casts.$to(HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(/**@type {BaseIcon<BaseIcon>} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_attachment__().m_setTooltip__java_lang_String("Attach files"), BaseIcon))).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_SMALL_AND_DOWN__org_dominokit_domino_ui_utils_ScreenMedia), HeaderAction)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$23(((/** Event */ evt$4$) =>{
      AttachDialogComponent.m_create__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler(FileUploadComponent.m_create__org_dominokit_samples_tasks_HasTask(this), CompleteHandler.$adapt((() =>{
        this.m_update___$p_org_dominokit_samples_tasks_TaskComponent();
      }))).m_open__();
    }))), HeaderAction))).m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(/**@type {HeaderAction} */ ($Casts.$to(HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(/**@type {BaseIcon<BaseIcon>} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__().m_setTooltip__java_lang_String("Pick Due date"), Icon)).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_SMALL_AND_DOWN__org_dominokit_domino_ui_utils_ScreenMedia), Icon)).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Icon */ dateIcon) =>{
      this.f_datePickerPopup__org_dominokit_samples_tasks_TaskComponent_ = /**@type {Popover} */ ($Casts.$to(Popover.m_createPicker__org_jboss_gwt_elemento_core_IsElement__org_jboss_gwt_elemento_core_IsElement(dateIcon, this.f_datePicker__org_dominokit_samples_tasks_TaskComponent_).m_position__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP_DOWN__org_dominokit_domino_ui_popover_PopupPosition).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Popover> */ style$1$) =>{
        style$1$.m_setMaxWidth__java_lang_String("300px");
      }))), Popover));
    }))), BaseIcon))).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$24(((/** Event */ evt$5$) =>{
      this.f_datePickerPopup__org_dominokit_samples_tasks_TaskComponent_.m_show__();
    }))), HeaderAction))).m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(this.m_getStatusAction__org_dominokit_samples_Task_$p_org_dominokit_samples_tasks_TaskComponent(task)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_importantIcon__org_dominokit_samples_tasks_TaskComponent_).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String(task.m_getDescription__())).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TagsPanelComponent.m_create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_attachmentPanel__org_dominokit_samples_tasks_TaskComponent_);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    this.m_update___$p_org_dominokit_samples_tasks_TaskComponent();
  }
  
  /**
   * @param {HeaderAction} element
   * @return {DropDownMenu}
   * @public
   */
  m_createDropDownMenu__org_dominokit_domino_ui_cards_HeaderAction_$p_org_dominokit_samples_tasks_TaskComponent(element) {
    return DropDownMenu.m_create__org_jboss_gwt_elemento_core_IsElement(element).m_setPosition__org_dominokit_domino_ui_dropdown_DropDownPosition(DropDownPosition.f_BOTTOM_LEFT__org_dominokit_domino_ui_dropdown_DropDownPosition).m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String("Toggle priority").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value) =>{
      this.m_updatePriority___$p_org_dominokit_samples_tasks_TaskComponent();
    })))).m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String("Delete").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$1$) =>{
      this.m_showConfirmationDialog___$p_org_dominokit_samples_tasks_TaskComponent();
    })))).m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String("Edit").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$2$) =>{
      this.f_taskUiHandlers__org_dominokit_samples_tasks_TaskComponent_.m_onEditTask__org_dominokit_samples_Task(this.f_task__org_dominokit_samples_tasks_TaskComponent_);
    })))).m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String("Attach").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$3$) =>{
      AttachDialogComponent.m_create__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler(FileUploadComponent.m_create__org_dominokit_samples_tasks_HasTask(this), CompleteHandler.$adapt((() =>{
        this.m_update___$p_org_dominokit_samples_tasks_TaskComponent();
      }))).m_open__();
    })))).m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String("Pick due date").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$4$) =>{
      let modal = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(this.f_datePicker__org_dominokit_samples_tasks_TaskComponent_.m_createModal__java_lang_String("Duew date").m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_datePicker__org_dominokit_samples_tasks_TaskComponent_), ModalDialog)).m_open__(), ModalDialog));
      this.f_datePicker__org_dominokit_samples_tasks_TaskComponent_.m_addDateDayClickHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler(DateDayClickedHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo1) =>{
        modal.m_close__();
      })));
    })))).m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(DropdownAction.m_create__java_lang_String(this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_isActive__() ? "Resolve" : "Unresolve").m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value$5$) =>{
      if (this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_isActive__()) {
        this.m_resolve___$p_org_dominokit_samples_tasks_TaskComponent();
      } else {
        this.m_unresolve___$p_org_dominokit_samples_tasks_TaskComponent();
      }
    }))));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_unresolve___$p_org_dominokit_samples_tasks_TaskComponent() {
    this.f_taskUiHandlers__org_dominokit_samples_tasks_TaskComponent_.m_onUnResolve__org_dominokit_samples_Task(this.f_task__org_dominokit_samples_tasks_TaskComponent_);
    Notification.m_createWarning__java_lang_String("Oops! now You have more work to do. " + j_l_String.m_valueOf__java_lang_Object(this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_getTitle__())).m_show__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_resolve___$p_org_dominokit_samples_tasks_TaskComponent() {
    this.f_taskUiHandlers__org_dominokit_samples_tasks_TaskComponent_.m_onResolved__org_dominokit_samples_Task(this.f_task__org_dominokit_samples_tasks_TaskComponent_);
    Notification.m_createSuccess__java_lang_String("Congrats! Task [" + j_l_String.m_valueOf__java_lang_Object(this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_getTitle__()) + "] have been resolved now.").m_show__();
  }
  
  /**
   * @param {Task} task
   * @return {HeaderAction}
   * @public
   */
  m_getStatusAction__org_dominokit_samples_Task_$p_org_dominokit_samples_tasks_TaskComponent(task) {
    if (task.m_isActive__()) {
      return HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_done_all__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color), Icon)).m_setTooltip__java_lang_String("Resolve"), Icon)).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_SMALL_AND_DOWN__org_dominokit_domino_ui_utils_ScreenMedia), Icon)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$25(((/** Event */ evt) =>{
        this.m_resolve___$p_org_dominokit_samples_tasks_TaskComponent();
      }))));
    } else {
      return HeaderAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_replay__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_ORANGE__org_dominokit_domino_ui_style_Color), Icon)).m_setTooltip__java_lang_String("Unresolve"), Icon)).m_hideOn__org_dominokit_domino_ui_utils_ScreenMedia(ScreenMedia.f_SMALL_AND_DOWN__org_dominokit_domino_ui_utils_ScreenMedia), Icon)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$26(((/** Event */ evt$1$) =>{
        this.m_unresolve___$p_org_dominokit_samples_tasks_TaskComponent();
      }))));
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updatePriority___$p_org_dominokit_samples_tasks_TaskComponent() {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(Priority.f_IMPORTANT__org_dominokit_samples_Priority, this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_getPriority__())) {
      this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_setPriority__org_dominokit_samples_Priority(Priority.f_NORMAL__org_dominokit_samples_Priority);
    } else {
      this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_setPriority__org_dominokit_samples_Priority(Priority.f_IMPORTANT__org_dominokit_samples_Priority);
    }
    this.m_update___$p_org_dominokit_samples_tasks_TaskComponent();
    this.f_taskUiHandlers__org_dominokit_samples_tasks_TaskComponent_.m_onTaskPriorityChange__org_dominokit_samples_Task(this.f_task__org_dominokit_samples_tasks_TaskComponent_);
  }
  
  /**
   * @return {ConfirmationDialog}
   * @public
   */
  m_showConfirmationDialog___$p_org_dominokit_samples_tasks_TaskComponent() {
    return /**@type {ConfirmationDialog} */ ($Casts.$to(/**@type {ConfirmationDialog} */ ($Casts.$to(/**@type {ConfirmationDialog} */ ($Casts.$to(ConfirmationDialog.m_create__java_lang_String("Confirm delete").m_appendChild__org_jboss_gwt_elemento_core_IsElement(Paragraph.m_create__java_lang_String("Are you sure you want to delete this task?")), ConfirmationDialog)).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** ConfirmationDialog */ element) =>{
      element.m_getFooterElement__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, DominoElement<HTMLDivElement>> */ style) =>{
        style.m_setBackgroundColor__java_lang_String("#f3f3f3");
      })));
    }))), ConfirmationDialog)).m_onConfirm__org_dominokit_domino_ui_dialogs_ConfirmationDialog_ConfirmHandler(ConfirmHandler.$adapt(((/** ConfirmationDialog */ dialog) =>{
      dialog.m_close__();
      Animation.m_create__org_dominokit_domino_ui_utils_BaseDominoElement(this).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition).m_duration__int(500).m_callback__org_dominokit_domino_ui_animations_Animation_CompleteCallback(CompleteCallback.$adapt(((/** HTMLElement */ element1) =>{
        this.f_taskUiHandlers__org_dominokit_samples_tasks_TaskComponent_.m_onTaskDelete__org_dominokit_samples_Task(this.f_task__org_dominokit_samples_tasks_TaskComponent_);
      }))).m_animate__();
    }))).m_onReject__org_dominokit_domino_ui_dialogs_ConfirmationDialog_RejectHandler(RejectHandler.$adapt(((/** ConfirmationDialog */ arg0) =>{
      arg0.m_close__();
    }))).m_open__(), ConfirmationDialog));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_update___$p_org_dominokit_samples_tasks_TaskComponent() {
    this.f_importantIcon__org_dominokit_samples_tasks_TaskComponent_.m_toggleDisplay__boolean($Objects.m_equals__java_lang_Object__java_lang_Object(Priority.f_IMPORTANT__org_dominokit_samples_Priority, this.f_task__org_dominokit_samples_tasks_TaskComponent_.m_getPriority__()));
    this.f_attachmentPanel__org_dominokit_samples_tasks_TaskComponent_.m_update__();
  }
  
  /**
   * @param {Date} date
   * @return {?string}
   * @public
   */
  m_formatDate__java_util_Date_$p_org_dominokit_samples_tasks_TaskComponent(date) {
    return Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.f_dateTimeFormatInfo__org_dominokit_samples_tasks_TaskComponent_.m_dateFormatFull__(), this.f_dateTimeFormatInfo__org_dominokit_samples_tasks_TaskComponent_).m_format__java_util_Date(date);
  }
  
  /**
   * @override
   * @return {Task}
   * @public
   */
  m_getTask__() {
    return this.f_task__org_dominokit_samples_tasks_TaskComponent_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_card__org_dominokit_samples_tasks_TaskComponent_.m_asElement__(), $Overlay));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_tasks_TaskComponent() {
    this.f_dateTimeFormatInfo__org_dominokit_samples_tasks_TaskComponent_ = DateTimeFormatInfo__factory.m_create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TaskComponent.$clinit = (() =>{
    });
    TaskComponent.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TaskComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TaskComponent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Paragraph = goog.module.get('org.dominokit.domino.ui.Typography.Paragraph$impl');
    Animation = goog.module.get('org.dominokit.domino.ui.animations.Animation$impl');
    CompleteCallback = goog.module.get('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    HeaderAction = goog.module.get('org.dominokit.domino.ui.cards.HeaderAction$impl');
    DatePicker = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker$impl');
    DateDayClickedHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    Formatter = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.Formatter$impl');
    ConfirmationDialog = goog.module.get('org.dominokit.domino.ui.dialogs.ConfirmationDialog$impl');
    ConfirmHandler = goog.module.get('org.dominokit.domino.ui.dialogs.ConfirmationDialog.ConfirmHandler$impl');
    RejectHandler = goog.module.get('org.dominokit.domino.ui.dialogs.ConfirmationDialog.RejectHandler$impl');
    DropDownMenu = goog.module.get('org.dominokit.domino.ui.dropdown.DropDownMenu$impl');
    DropDownPosition = goog.module.get('org.dominokit.domino.ui.dropdown.DropDownPosition$impl');
    DropdownAction = goog.module.get('org.dominokit.domino.ui.dropdown.DropdownAction$impl');
    BaseIcon = goog.module.get('org.dominokit.domino.ui.icons.BaseIcon$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ModalDialog = goog.module.get('org.dominokit.domino.ui.modals.ModalDialog$impl');
    Notification = goog.module.get('org.dominokit.domino.ui.notifications.Notification$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
    ScreenMedia = goog.module.get('org.dominokit.domino.ui.utils.ScreenMedia$impl');
    Priority = goog.module.get('org.dominokit.samples.Priority$impl');
    AttachDialogComponent = goog.module.get('org.dominokit.samples.attachments.AttachDialogComponent$impl');
    CompleteHandler = goog.module.get('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler$impl');
    AttachmentPanelComponent = goog.module.get('org.dominokit.samples.attachments.AttachmentPanelComponent$impl');
    FileUploadComponent = goog.module.get('org.dominokit.samples.attachments.FileUploadComponent$impl');
    TagsPanelComponent = goog.module.get('org.dominokit.samples.tasks.TagsPanelComponent$impl');
    $LambdaAdaptor$19 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$19$impl');
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$20$impl');
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$21$impl');
    $LambdaAdaptor$22 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$22$impl');
    $LambdaAdaptor$23 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$23$impl');
    $LambdaAdaptor$24 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$24$impl');
    $LambdaAdaptor$25 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$25$impl');
    $LambdaAdaptor$26 = goog.module.get('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$26$impl');
    DateTimeFormatInfo__factory = goog.module.get('org.gwtproject.i18n.shared.impl.cldr.DateTimeFormatInfo_factory$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(TaskComponent, $Util.$makeClassName('org.dominokit.samples.tasks.TaskComponent'));


HasTask.$markImplementor(TaskComponent);


exports = TaskComponent; 
//# sourceMappingURL=TaskComponent.js.map