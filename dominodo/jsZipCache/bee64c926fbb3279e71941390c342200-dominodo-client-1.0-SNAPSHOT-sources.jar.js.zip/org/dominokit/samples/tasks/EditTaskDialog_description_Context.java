package org.dominokit.samples.tasks;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import javax.annotation.Generated;
import org.dominokit.samples.Task;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.impl.AbstractEditorContext;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class EditTaskDialog_description_Context extends AbstractEditorContext<String> {
  private final Task parent;

  public EditTaskDialog_description_Context(Task parent, Editor<String> editor, String path) {
    super(editor, path);
    this.parent = parent;
  }

  @Override
  public boolean canSetInModel() {
    return parent != null && true && true;
  }

  @Override
  public String checkAssignment(Object value) {
    return (String) value;
  }

  @Override
  public Class getEditedType() {
    return java.lang.String.class;
  }

  @Override
  public String getFromModel() {
    return (parent != null && true) ? parent.getDescription() : null;
  }

  @Override
  public void setInModel(String data) {
    parent.setDescription(data);;
  }
}
