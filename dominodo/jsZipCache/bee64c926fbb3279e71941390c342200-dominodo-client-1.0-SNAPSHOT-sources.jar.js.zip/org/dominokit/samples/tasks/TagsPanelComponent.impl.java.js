/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TagsPanelComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.TagsPanelComponent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Chip = goog.forwardDeclare('org.dominokit.domino.ui.chips.Chip$impl');
let FlexItem = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
let FlexLayout = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let RemoveHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler$impl');
let HasTaskUiHandlers = goog.forwardDeclare('org.dominokit.samples.HasTaskUiHandlers$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.samples.tasks.TagsPanelComponent.$LambdaAdaptor$18$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, TagsPanelComponent>}
  */
class TagsPanelComponent extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {FlexItem} */
    this.f_tagsContainer__org_dominokit_samples_tasks_TagsPanelComponent_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_samples_tasks_TagsPanelComponent_;
    /** @public {Task} */
    this.f_task__org_dominokit_samples_tasks_TagsPanelComponent_;
    /** @public {HasTaskUiHandlers} */
    this.f_taskUiHandlers__org_dominokit_samples_tasks_TagsPanelComponent_;
  }
  
  /**
   * @param {Task} task
   * @param {HasTaskUiHandlers} taskUiHandlers
   * @return {TagsPanelComponent}
   * @public
   */
  static m_create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers) {
    TagsPanelComponent.$clinit();
    return TagsPanelComponent.$create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers);
  }
  
  /**
   * @param {Task} task
   * @param {HasTaskUiHandlers} taskUiHandlers
   * @return {!TagsPanelComponent}
   * @public
   */
  static $create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers) {
    TagsPanelComponent.$clinit();
    let $instance = new TagsPanelComponent();
    $instance.$ctor__org_dominokit_samples_tasks_TagsPanelComponent__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers);
    return $instance;
  }
  
  /**
   * @param {Task} task
   * @param {HasTaskUiHandlers} taskUiHandlers
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_TagsPanelComponent__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, taskUiHandlers) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_samples_tasks_TagsPanelComponent();
    this.f_task__org_dominokit_samples_tasks_TagsPanelComponent_ = task;
    this.f_taskUiHandlers__org_dominokit_samples_tasks_TagsPanelComponent_ = taskUiHandlers;
    this.f_element__org_dominokit_samples_tasks_TagsPanelComponent_.appendChild(FlexLayout.m_create__().m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.f_tagsContainer__org_dominokit_samples_tasks_TagsPanelComponent_).m_asElement__());
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    this.m_update__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_update__() {
    let projectColor = ColorScheme.m_valueOf__java_lang_String(this.f_task__org_dominokit_samples_tasks_TagsPanelComponent_.m_getProject__().m_getColor__());
    this.f_task__org_dominokit_samples_tasks_TagsPanelComponent_.m_getTags__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ?string */ tag) =>{
      this.f_tagsContainer__org_dominokit_samples_tasks_TagsPanelComponent_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Chip} */ ($Casts.$to(/**@type {Chip} */ ($Casts.$to(Chip.m_create__java_lang_String(tag).m_setTooltip__java_lang_String("Click to search"), Chip)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$18(((/** Event */ evt) =>{
        this.f_taskUiHandlers__org_dominokit_samples_tasks_TagsPanelComponent_.m_onTagSelected__java_lang_String(tag);
      }))), Chip)).m_addRemoveHandler__org_dominokit_domino_ui_utils_HasRemoveHandler_RemoveHandler(RemoveHandler.$adapt((() =>{
        this.f_task__org_dominokit_samples_tasks_TagsPanelComponent_.m_getTags__().remove(tag);
      }))).m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(projectColor));
    })));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_samples_tasks_TagsPanelComponent_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_tasks_TagsPanelComponent() {
    this.f_tagsContainer__org_dominokit_samples_tasks_TagsPanelComponent_ = FlexItem.m_create__();
    this.f_element__org_dominokit_samples_tasks_TagsPanelComponent_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TagsPanelComponent.$clinit = (() =>{
    });
    TagsPanelComponent.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TagsPanelComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TagsPanelComponent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Chip = goog.module.get('org.dominokit.domino.ui.chips.Chip$impl');
    FlexItem = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
    FlexLayout = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    RemoveHandler = goog.module.get('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.samples.tasks.TagsPanelComponent.$LambdaAdaptor$18$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TagsPanelComponent, $Util.$makeClassName('org.dominokit.samples.tasks.TagsPanelComponent'));




exports = TagsPanelComponent; 
//# sourceMappingURL=TagsPanelComponent.js.map