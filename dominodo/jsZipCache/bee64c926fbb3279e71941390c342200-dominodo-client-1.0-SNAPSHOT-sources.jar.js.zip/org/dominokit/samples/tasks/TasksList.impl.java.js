/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TasksList.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.TasksList$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Animation = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation$impl');
let StartHandler = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.StartHandler$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let EmptyState = goog.forwardDeclare('org.dominokit.domino.ui.layout.EmptyState$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let HasTaskUiHandlers = goog.forwardDeclare('org.dominokit.samples.HasTaskUiHandlers$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let TaskComponent = goog.forwardDeclare('org.dominokit.samples.tasks.TaskComponent$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, TasksList>}
  */
class TasksList extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_DURATION__org_dominokit_samples_tasks_TasksList_ = 0;
    /** @public {Column} */
    this.f_column__org_dominokit_samples_tasks_TasksList_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_samples_tasks_TasksList_;
    /** @public {number} */
    this.f_delay__org_dominokit_samples_tasks_TasksList_ = 0;
    /** @public {?string} */
    this.f_title__org_dominokit_samples_tasks_TasksList_;
    /** @public {List<Task>} */
    this.f_tasks__org_dominokit_samples_tasks_TasksList_;
    /** @public {HasTaskUiHandlers} */
    this.f_hasTaskUiHandlers__org_dominokit_samples_tasks_TasksList_;
  }
  
  /**
   * @param {?string} title
   * @param {List<Task>} tasks
   * @param {HasTaskUiHandlers} hasTaskUiHandlers
   * @return {!TasksList}
   * @public
   */
  static $create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers(title, tasks, hasTaskUiHandlers) {
    TasksList.$clinit();
    let $instance = new TasksList();
    $instance.$ctor__org_dominokit_samples_tasks_TasksList__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers(title, tasks, hasTaskUiHandlers);
    return $instance;
  }
  
  /**
   * @param {?string} title
   * @param {List<Task>} tasks
   * @param {HasTaskUiHandlers} hasTaskUiHandlers
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_TasksList__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers(title, tasks, hasTaskUiHandlers) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_samples_tasks_TasksList();
    this.f_title__org_dominokit_samples_tasks_TasksList_ = title;
    this.f_tasks__org_dominokit_samples_tasks_TasksList_ = tasks;
    this.f_hasTaskUiHandlers__org_dominokit_samples_tasks_TasksList_ = hasTaskUiHandlers;
    this.f_element__org_dominokit_samples_tasks_TasksList_.appendChild(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(this.f_column__org_dominokit_samples_tasks_TasksList_), Row__12)).m_asElement__());
  }
  
  /**
   * @param {?string} title
   * @param {List<Task>} tasks
   * @param {HasTaskUiHandlers} hasTaskUiHandlers
   * @return {TasksList}
   * @public
   */
  static m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers(title, tasks, hasTaskUiHandlers) {
    TasksList.$clinit();
    return TasksList.$create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers(title, tasks, hasTaskUiHandlers);
  }
  
  /**
   * @param {boolean} animate
   * @return {TasksList}
   * @public
   */
  m_update__boolean(animate) {
    this.f_column__org_dominokit_samples_tasks_TasksList_.m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Column */ element) =>{
      element.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String(this.f_title__org_dominokit_samples_tasks_TasksList_));
      if (this.f_tasks__org_dominokit_samples_tasks_TasksList_.isEmpty()) {
        element.m_appendChild__org_jboss_gwt_elemento_core_IsElement(EmptyState.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event_available__()).m_setIconColor__org_dominokit_domino_ui_style_Color(Color.f_GREY_LIGHTEN_1__org_dominokit_domino_ui_style_Color).m_setTitle__java_lang_String("No tasks found").m_setDescription__java_lang_String("If you are a developer then something wrong, you must have something to do.!").m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, EmptyState> */ style) =>{
          style.m_setMarginTop__java_lang_String("10%");
        }))));
      } else {
        this.f_tasks__org_dominokit_samples_tasks_TasksList_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Task */ task) =>{
          let taskComponent = TaskComponent.m_create__org_dominokit_samples_Task__org_dominokit_samples_HasTaskUiHandlers(task, this.f_hasTaskUiHandlers__org_dominokit_samples_tasks_TasksList_);
          if (animate) {
            taskComponent.m_collapse__();
            element.m_appendChild__org_jboss_gwt_elemento_core_IsElement(taskComponent);
            Animation.m_create__org_dominokit_domino_ui_utils_BaseDominoElement(taskComponent).m_delay__int(this.f_delay__org_dominokit_samples_tasks_TasksList_).m_beforeStart__org_dominokit_domino_ui_animations_Animation_StartHandler(StartHandler.$adapt(((/** HTMLElement */ component) =>{
              taskComponent.m_expand__();
            }))).m_duration__int(this.f_DURATION__org_dominokit_samples_tasks_TasksList_).m_transition__org_dominokit_domino_ui_animations_Transition(Transition.f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition).m_animate__();
            this.f_delay__org_dominokit_samples_tasks_TasksList_ = this.f_delay__org_dominokit_samples_tasks_TasksList_ + this.f_DURATION__org_dominokit_samples_tasks_TasksList_;
            this.f_DURATION__org_dominokit_samples_tasks_TasksList_ = 200;
          } else {
            element.m_appendChild__org_jboss_gwt_elemento_core_IsElement(taskComponent);
          }
        })));
      }
    })));
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_samples_tasks_TasksList_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_tasks_TasksList() {
    this.f_DURATION__org_dominokit_samples_tasks_TasksList_ = 400;
    this.f_column__org_dominokit_samples_tasks_TasksList_ = Column.m_span8__().m_offset2__();
    this.f_element__org_dominokit_samples_tasks_TasksList_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_delay__org_dominokit_samples_tasks_TasksList_ = 100;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TasksList.$clinit = (() =>{
    });
    TasksList.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TasksList;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TasksList);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Animation = goog.module.get('org.dominokit.domino.ui.animations.Animation$impl');
    StartHandler = goog.module.get('org.dominokit.domino.ui.animations.Animation.StartHandler$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    EmptyState = goog.module.get('org.dominokit.domino.ui.layout.EmptyState$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    TaskComponent = goog.module.get('org.dominokit.samples.tasks.TaskComponent$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TasksList, $Util.$makeClassName('org.dominokit.samples.tasks.TasksList'));




exports = TasksList; 
//# sourceMappingURL=TasksList.js.map