/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TagsPanelComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.TagsPanelComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Consumer = goog.require('java.util.function.Consumer');
const _Chip = goog.require('org.dominokit.domino.ui.chips.Chip');
const _FlexItem = goog.require('org.dominokit.domino.ui.grid.flex.FlexItem');
const _FlexLayout = goog.require('org.dominokit.domino.ui.grid.flex.FlexLayout');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _RemoveHandler = goog.require('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler');
const _HasTaskUiHandlers = goog.require('org.dominokit.samples.HasTaskUiHandlers');
const _Task = goog.require('org.dominokit.samples.Task');
const _$LambdaAdaptor$18 = goog.require('org.dominokit.samples.tasks.TagsPanelComponent.$LambdaAdaptor$18');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TagsPanelComponent = goog.require('org.dominokit.samples.tasks.TagsPanelComponent$impl');
exports = TagsPanelComponent;
 