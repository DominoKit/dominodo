package org.dominokit.samples.tasks;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import javax.annotation.Generated;
import org.dominokit.samples.Priority;
import org.dominokit.samples.Task;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.impl.AbstractEditorContext;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class EditTaskDialog_priority_Context extends AbstractEditorContext<Priority> {
  private final Task parent;

  public EditTaskDialog_priority_Context(Task parent, Editor<Priority> editor, String path) {
    super(editor, path);
    this.parent = parent;
  }

  @Override
  public boolean canSetInModel() {
    return parent != null && true && true;
  }

  @Override
  public Priority checkAssignment(Object value) {
    return (Priority) value;
  }

  @Override
  public Class getEditedType() {
    return org.dominokit.samples.Priority.class;
  }

  @Override
  public Priority getFromModel() {
    return (parent != null && true) ? parent.getPriority() : null;
  }

  @Override
  public void setInModel(Priority data) {
    parent.setPriority(data);;
  }
}
