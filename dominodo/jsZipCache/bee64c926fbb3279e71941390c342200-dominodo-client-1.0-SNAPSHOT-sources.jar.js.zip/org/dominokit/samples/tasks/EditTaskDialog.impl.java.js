/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasTask = goog.require('org.dominokit.samples.tasks.HasTask$impl');
const Editor = goog.require('org.gwtproject.editor.client.Editor$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let DateDayClickedHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
let FieldsGrouping = goog.forwardDeclare('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let TextArea = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextArea$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ModalDialog = goog.forwardDeclare('org.dominokit.domino.ui.modals.ModalDialog$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let TagsInput = goog.forwardDeclare('org.dominokit.domino.ui.tag.TagsInput$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let Constants = goog.forwardDeclare('org.dominokit.samples.Constants$impl');
let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let Project = goog.forwardDeclare('org.dominokit.samples.Project$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let FileUploadComponent = goog.forwardDeclare('org.dominokit.samples.attachments.FileUploadComponent$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog.$LambdaAdaptor$17$impl');
let Driver = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog.Driver$impl');
let EditTaskDialog__Driver__Impl = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl$impl');
let TasksRepository = goog.forwardDeclare('org.dominokit.samples.tasks.TasksRepository$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {Editor<Task>}
 * @implements {HasTask}
  */
class EditTaskDialog extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Driver} */
    this.f_driver__org_dominokit_samples_tasks_EditTaskDialog_;
    /** @public {Task} */
    this.f_task__org_dominokit_samples_tasks_EditTaskDialog_;
    /** @public {ModalDialog} */
    this.f_modalDialog__org_dominokit_samples_tasks_EditTaskDialog_;
    /** @public {TextBox} */
    this.f_title__org_dominokit_samples_tasks_EditTaskDialog;
    /** @public {TextArea} */
    this.f_description__org_dominokit_samples_tasks_EditTaskDialog;
    /** @public {DateBox} */
    this.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog;
    /** @public {Select<Priority>} */
    this.f_priority__org_dominokit_samples_tasks_EditTaskDialog;
    /** @public {Select<Project>} */
    this.f_project__org_dominokit_samples_tasks_EditTaskDialog;
    /** @public {TagsInput<?string>} */
    this.f_tags__org_dominokit_samples_tasks_EditTaskDialog;
    /** @public {Consumer<Task>} */
    this.f_onCreateHandler__org_dominokit_samples_tasks_EditTaskDialog_;
    /** @public {FieldsGrouping} */
    this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_;
  }
  
  /**
   * @param {?string} dialogTitle
   * @return {!EditTaskDialog}
   * @public
   */
  static $create__java_lang_String(dialogTitle) {
    EditTaskDialog.$clinit();
    let $instance = new EditTaskDialog();
    $instance.$ctor__org_dominokit_samples_tasks_EditTaskDialog__java_lang_String(dialogTitle);
    return $instance;
  }
  
  /**
   * @param {?string} dialogTitle
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_EditTaskDialog__java_lang_String(dialogTitle) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_samples_tasks_EditTaskDialog();
    this.f_driver__org_dominokit_samples_tasks_EditTaskDialog_ = EditTaskDialog__Driver__Impl.$create__();
    this.f_title__org_dominokit_samples_tasks_EditTaskDialog = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__java_lang_String("Title").m_setRequired__boolean(true), TextBox)).m_setAutoValidation__boolean(true), TextBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_), TextBox)).m_setPlaceholder__java_lang_String("Task headline"), TextBox)).m_floating__(), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_label__()), TextBox));
    this.f_description__org_dominokit_samples_tasks_EditTaskDialog = /**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(/**@type {TextArea} */ ($Casts.$to(TextArea.m_create__java_lang_String("description").m_setRequired__boolean(true), TextArea)).m_setAutoValidation__boolean(true), TextArea)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_), TextArea)).m_setPlaceholder__java_lang_String("Describe the task"), TextArea)).m_floating__(), TextArea)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_description__()), TextArea)).m_autoSize__().m_setRows__int(2);
    this.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog = /**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(DateBox.m_create__java_lang_String__java_util_Date("Due date", Date.$create__()).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** DateBox */ element) =>{
      element.m_getDatePicker__().m_addDateDayClickHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler(DateDayClickedHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
        this.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog.m_close__();
      })));
    }))), DateBox)).m_setRequired__boolean(true), DateBox)).m_setAutoValidation__boolean(true), DateBox)).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_), DateBox)).m_setHelperText__java_lang_String("Should not be in the past."), DateBox)).m_setPlaceholder__java_lang_String("Pick a Due date").m_floating__(), DateBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()), DateBox));
    this.f_priority__org_dominokit_samples_tasks_EditTaskDialog = /**@type {Select<Priority>} */ ($Casts.$to(/**@type {Select<Priority>} */ ($Casts.$to(/**@type {Select<Priority>} */ (Select.m_create__java_lang_String("Priority")).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Priority>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(Priority.f_IMPORTANT__org_dominokit_samples_Priority, "Important"))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Priority>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(Priority.f_NORMAL__org_dominokit_samples_Priority, "Normal"))).m_selectAt__int(1).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_), Select)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_low_priority__());
    this.f_project__org_dominokit_samples_tasks_EditTaskDialog = /**@type {Select<Project>} */ ($Casts.$to(/**@type {Select<Project>} */ ($Casts.$to(/**@type {Select<Project>} */ (Select.m_create__java_lang_String("Project")).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Project>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(/**@type {Project} */ ($Casts.$to(TasksRepository.f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.get(Constants.f_DOMINO_UI__org_dominokit_samples_Constants), Project)), Constants.f_DOMINO_UI__org_dominokit_samples_Constants))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Project>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(/**@type {Project} */ ($Casts.$to(TasksRepository.f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.get(Constants.f_GWT__org_dominokit_samples_Constants), Project)), Constants.f_GWT__org_dominokit_samples_Constants))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Project>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(/**@type {Project} */ ($Casts.$to(TasksRepository.f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.get(Constants.f_NALU_MVP__org_dominokit_samples_Constants), Project)), Constants.f_NALU_MVP__org_dominokit_samples_Constants))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<Project>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(/**@type {Project} */ ($Casts.$to(TasksRepository.f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.get(Constants.f_MOVIES__org_dominokit_samples_Constants), Project)), Constants.f_MOVIES__org_dominokit_samples_Constants))).m_setRequired__boolean(true), Select)).m_setAutoValidation__boolean(true).m_groupBy__org_dominokit_domino_ui_forms_FieldsGrouping(this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_), Select)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_collections_bookmark__()).m_selectAt__int(0);
    this.f_tags__org_dominokit_samples_tasks_EditTaskDialog = /**@type {TagsInput<?string>} */ ($Casts.$to(/**@type {TagsInput<?string>} */ ($Casts.$to(TagsInput.m_create__java_lang_String("Tags").m_floating__(), TagsInput)).m_setPlaceholder__java_lang_String("Things related to this task").m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_bookmark__()), TagsInput));
    this.f_modalDialog__org_dominokit_samples_tasks_EditTaskDialog_ = /**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(/**@type {ModalDialog} */ ($Casts.$to(ModalDialog.m_create__java_lang_String(dialogTitle).m_setAutoClose__boolean(false), ModalDialog)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, ModalDialog> */ style) =>{
      style.m_add__java_lang_String("task-modal");
    }))), ModalDialog)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column) =>{
      column.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_title__org_dominokit_samples_tasks_EditTaskDialog);
    })))), ModalDialog)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$1$) =>{
      column$1$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_description__org_dominokit_samples_tasks_EditTaskDialog);
    })))), ModalDialog)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$2$) =>{
      column$2$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog);
    })))), ModalDialog)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$3$) =>{
      column$3$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_priority__org_dominokit_samples_tasks_EditTaskDialog);
    })))), ModalDialog)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$4$) =>{
      column$4$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_project__org_dominokit_samples_tasks_EditTaskDialog);
    })))), ModalDialog)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$5$) =>{
      column$5$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_tags__org_dominokit_samples_tasks_EditTaskDialog);
    })))), ModalDialog)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Row.m_create__().m_fullSpan__java_util_function_Consumer(Consumer.$adapt(((/** Column */ column$6$) =>{
      /**@type {Column} */ ($Casts.$to(column$6$.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("ATTACHMENTS"), IsElement))), Column)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(FileUploadComponent.m_create__org_dominokit_samples_tasks_HasTask(this));
    })))), ModalDialog)).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_clear__()).m_linkify__(), Button)).m_setContent__java_lang_String("CANCEL"), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style$1$) =>{
      style$1$.m_setMinWidth__java_lang_String("100px");
    }))), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$16(((/** Event */ evt) =>{
      this.f_modalDialog__org_dominokit_samples_tasks_EditTaskDialog_.m_close__();
    })))), ModalDialog)).m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_createPrimary__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_save__()).m_setContent__java_lang_String("SAVE"), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style$2$) =>{
      style$2$.m_setMinWidth__java_lang_String("100px");
    }))), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$17(((/** Event */ evt$1$) =>{
      this.m_onSave___$p_org_dominokit_samples_tasks_EditTaskDialog();
    })))), ModalDialog));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onSave___$p_org_dominokit_samples_tasks_EditTaskDialog() {
    if (this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_.m_validate__().m_isValid__()) {
      if (Objects.m_nonNull__java_lang_Object(this.f_onCreateHandler__org_dominokit_samples_tasks_EditTaskDialog_)) {
        this.f_onCreateHandler__org_dominokit_samples_tasks_EditTaskDialog_.m_accept__java_lang_Object(/**@type {Task} */ ($Casts.$to(this.f_driver__org_dominokit_samples_tasks_EditTaskDialog_.m_flush__(), Task)));
        this.f_modalDialog__org_dominokit_samples_tasks_EditTaskDialog_.m_close__();
      }
    }
  }
  
  /**
   * @param {?string} dialogTitle
   * @param {Task} task
   * @return {EditTaskDialog}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_samples_Task(dialogTitle, task) {
    EditTaskDialog.$clinit();
    let editTaskDialog = EditTaskDialog.$create__java_lang_String(dialogTitle);
    editTaskDialog.m_edit__org_dominokit_samples_Task_$pp_org_dominokit_samples_tasks(task);
    return editTaskDialog;
  }
  
  /**
   * @param {?string} dialogTitle
   * @return {EditTaskDialog}
   * @public
   */
  static m_create__java_lang_String(dialogTitle) {
    EditTaskDialog.$clinit();
    let editTaskDialog = EditTaskDialog.$create__java_lang_String(dialogTitle);
    editTaskDialog.m_edit__org_dominokit_samples_Task_$pp_org_dominokit_samples_tasks(Task.$create__());
    editTaskDialog.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_.m_clearInvalid__();
    return editTaskDialog;
  }
  
  /**
   * @return {ModalDialog}
   * @public
   */
  m_getModalDialog__() {
    return this.f_modalDialog__org_dominokit_samples_tasks_EditTaskDialog_;
  }
  
  /**
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_edit__org_dominokit_samples_Task_$pp_org_dominokit_samples_tasks(task) {
    this.f_driver__org_dominokit_samples_tasks_EditTaskDialog_.m_initialize__org_gwtproject_editor_client_Editor(this);
    this.f_driver__org_dominokit_samples_tasks_EditTaskDialog_.m_edit__java_lang_Object(task);
    this.f_task__org_dominokit_samples_tasks_EditTaskDialog_ = task;
  }
  
  /**
   * @override
   * @return {Task}
   * @public
   */
  m_getTask__() {
    return this.f_task__org_dominokit_samples_tasks_EditTaskDialog_;
  }
  
  /**
   * @param {Consumer<Task>} onCreateHandler
   * @return {EditTaskDialog}
   * @public
   */
  m_onSave__java_util_function_Consumer(onCreateHandler) {
    this.f_onCreateHandler__org_dominokit_samples_tasks_EditTaskDialog_ = onCreateHandler;
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_tasks_EditTaskDialog() {
    this.f_onCreateHandler__org_dominokit_samples_tasks_EditTaskDialog_ = Consumer.$adapt(((/** Task */ task) =>{
    }));
    this.f_fieldsGrouping__org_dominokit_samples_tasks_EditTaskDialog_ = FieldsGrouping.m_create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditTaskDialog.$clinit = (() =>{
    });
    EditTaskDialog.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EditTaskDialog;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EditTaskDialog);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Date = goog.module.get('java.util.Date$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    DateDayClickedHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
    FieldsGrouping = goog.module.get('org.dominokit.domino.ui.forms.FieldsGrouping$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    TextArea = goog.module.get('org.dominokit.domino.ui.forms.TextArea$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ModalDialog = goog.module.get('org.dominokit.domino.ui.modals.ModalDialog$impl');
    TagsInput = goog.module.get('org.dominokit.domino.ui.tag.TagsInput$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    Constants = goog.module.get('org.dominokit.samples.Constants$impl');
    Priority = goog.module.get('org.dominokit.samples.Priority$impl');
    Project = goog.module.get('org.dominokit.samples.Project$impl');
    Task = goog.module.get('org.dominokit.samples.Task$impl');
    FileUploadComponent = goog.module.get('org.dominokit.samples.attachments.FileUploadComponent$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog.$LambdaAdaptor$17$impl');
    EditTaskDialog__Driver__Impl = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl$impl');
    TasksRepository = goog.module.get('org.dominokit.samples.tasks.TasksRepository$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(EditTaskDialog, $Util.$makeClassName('org.dominokit.samples.tasks.EditTaskDialog'));


Editor.$markImplementor(EditTaskDialog);
HasTask.$markImplementor(EditTaskDialog);


exports = EditTaskDialog; 
//# sourceMappingURL=EditTaskDialog.js.map