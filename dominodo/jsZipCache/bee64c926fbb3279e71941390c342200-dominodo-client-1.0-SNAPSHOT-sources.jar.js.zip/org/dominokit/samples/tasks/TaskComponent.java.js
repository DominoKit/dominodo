/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TaskComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.TaskComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasTask = goog.require('org.dominokit.samples.tasks.HasTask');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Date = goog.require('java.util.Date');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Animation = goog.require('org.dominokit.domino.ui.animations.Animation');
const _CompleteCallback = goog.require('org.dominokit.domino.ui.animations.Animation.CompleteCallback');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _Badge = goog.require('org.dominokit.domino.ui.badges.Badge');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _HeaderAction = goog.require('org.dominokit.domino.ui.cards.HeaderAction');
const _DatePicker = goog.require('org.dominokit.domino.ui.datepicker.DatePicker');
const _DateDayClickedHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler');
const _DateSelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler');
const _Formatter = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.Formatter');
const _ConfirmationDialog = goog.require('org.dominokit.domino.ui.dialogs.ConfirmationDialog');
const _ConfirmHandler = goog.require('org.dominokit.domino.ui.dialogs.ConfirmationDialog.ConfirmHandler');
const _RejectHandler = goog.require('org.dominokit.domino.ui.dialogs.ConfirmationDialog.RejectHandler');
const _DropDownMenu = goog.require('org.dominokit.domino.ui.dropdown.DropDownMenu');
const _DropDownPosition = goog.require('org.dominokit.domino.ui.dropdown.DropDownPosition');
const _DropdownAction = goog.require('org.dominokit.domino.ui.dropdown.DropdownAction');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ModalDialog = goog.require('org.dominokit.domino.ui.modals.ModalDialog');
const _Notification = goog.require('org.dominokit.domino.ui.notifications.Notification');
const _Popover = goog.require('org.dominokit.domino.ui.popover.Popover');
const _PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler');
const _ScreenMedia = goog.require('org.dominokit.domino.ui.utils.ScreenMedia');
const _HasTaskUiHandlers = goog.require('org.dominokit.samples.HasTaskUiHandlers');
const _Priority = goog.require('org.dominokit.samples.Priority');
const _Task = goog.require('org.dominokit.samples.Task');
const _AttachDialogComponent = goog.require('org.dominokit.samples.attachments.AttachDialogComponent');
const _CompleteHandler = goog.require('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler');
const _AttachmentPanelComponent = goog.require('org.dominokit.samples.attachments.AttachmentPanelComponent');
const _FileUploadComponent = goog.require('org.dominokit.samples.attachments.FileUploadComponent');
const _TagsPanelComponent = goog.require('org.dominokit.samples.tasks.TagsPanelComponent');
const _$LambdaAdaptor$19 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$19');
const _$LambdaAdaptor$20 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$20');
const _$LambdaAdaptor$21 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$21');
const _$LambdaAdaptor$22 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$22');
const _$LambdaAdaptor$23 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$23');
const _$LambdaAdaptor$24 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$24');
const _$LambdaAdaptor$25 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$25');
const _$LambdaAdaptor$26 = goog.require('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$26');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _DateTimeFormatInfo__factory = goog.require('org.gwtproject.i18n.shared.impl.cldr.DateTimeFormatInfo_factory');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var TaskComponent = goog.require('org.dominokit.samples.tasks.TaskComponent$impl');
exports = TaskComponent;
 