/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TasksRepository.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.TasksRepository');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _Arrays = goog.require('java.util.Arrays');
const _j_u_Date = goog.require('java.util.Date');
const _HashMap = goog.require('java.util.HashMap');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _Predicate = goog.require('java.util.function.Predicate');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Constants = goog.require('org.dominokit.samples.Constants');
const _Priority = goog.require('org.dominokit.samples.Priority');
const _Project = goog.require('org.dominokit.samples.Project');
const _Status = goog.require('org.dominokit.samples.Status');
const _Task = goog.require('org.dominokit.samples.Task');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$LongUtils = goog.require('vmbootstrap.LongUtils');
const _$Objects = goog.require('vmbootstrap.Objects');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var TasksRepository = goog.require('org.dominokit.samples.tasks.TasksRepository$impl');
exports = TasksRepository;
 