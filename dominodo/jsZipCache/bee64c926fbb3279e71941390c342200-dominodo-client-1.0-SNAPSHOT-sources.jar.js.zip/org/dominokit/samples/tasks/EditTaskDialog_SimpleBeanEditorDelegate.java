package org.dominokit.samples.tasks;

import java.lang.Object;
import java.lang.Override;
import javax.annotation.Generated;
import org.dominokit.domino.ui.datepicker.DateBox_SimpleBeanEditorDelegate;
import org.dominokit.domino.ui.forms.Select_Project_SimpleBeanEditorDelegate;
import org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate;
import org.dominokit.samples.Task;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.EditorVisitor;
import org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate;
import org.gwtproject.editor.client.LeafValueEditor_List_1String_SimpleBeanEditorDelegate;
import org.gwtproject.editor.client.LeafValueEditor_Project_SimpleBeanEditorDelegate;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class EditTaskDialog_SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  private EditTaskDialog editor;

  private Task object;

  private SimpleBeanEditorDelegate dueDateDelegate;

  private SimpleBeanEditorDelegate dueDateDelegate0;

  private SimpleBeanEditorDelegate projectDelegate;

  private SimpleBeanEditorDelegate projectDelegate0;

  private SimpleBeanEditorDelegate tagsDelegate;

  private SimpleBeanEditorDelegate tagsDelegate0;

  @Override
  protected EditTaskDialog getEditor() {
    return editor;
  }

  @Override
  protected void setEditor(Editor editor) {
    this.editor = (EditTaskDialog) editor;
  }

  @Override
  public Task getObject() {
    return object;
  }

  @Override
  protected void setObject(Object object) {
    this.object = (Task) object;
  }

  @Override
  protected void initializeSubDelegates() {
    if (editor.dueDate.asEditor() != null) {
      dueDateDelegate = new LeafValueEditor_Date_SimpleBeanEditorDelegate();
      addSubDelegate(dueDateDelegate, appendPath("dueDate"), editor.dueDate.asEditor());
    }
    if (editor.dueDate != null) {
      dueDateDelegate0 = new DateBox_SimpleBeanEditorDelegate();
      addSubDelegate(dueDateDelegate0, appendPath("dueDate"), editor.dueDate);
    }
    if (editor.project.asEditor() != null) {
      projectDelegate = new LeafValueEditor_Project_SimpleBeanEditorDelegate();
      addSubDelegate(projectDelegate, appendPath("project"), editor.project.asEditor());
    }
    if (editor.project != null) {
      projectDelegate0 = new Select_Project_SimpleBeanEditorDelegate();
      addSubDelegate(projectDelegate0, appendPath("project"), editor.project);
    }
    if (editor.tags.asEditor() != null) {
      tagsDelegate = new LeafValueEditor_List_1String_SimpleBeanEditorDelegate();
      addSubDelegate(tagsDelegate, appendPath("tags"), editor.tags.asEditor());
    }
    if (editor.tags != null) {
      tagsDelegate0 = new TagsInput_String_SimpleBeanEditorDelegate();
      addSubDelegate(tagsDelegate0, appendPath("tags"), editor.tags);
    }
  }

  @Override
  public void accept(EditorVisitor visitor) {
     {
      EditTaskDialog_title_Context ctx = new EditTaskDialog_title_Context(getObject(), editor.title.asEditor(), appendPath("title"));
      ctx.traverse(visitor, null);
    }
     {
      EditTaskDialog_title_Context ctx = new EditTaskDialog_title_Context(getObject(), editor.title, appendPath("title"));
      ctx.traverse(visitor, null);
    }
     {
      EditTaskDialog_description_Context ctx = new EditTaskDialog_description_Context(getObject(), editor.description.asEditor(), appendPath("description"));
      ctx.traverse(visitor, null);
    }
     {
      EditTaskDialog_description_Context ctx = new EditTaskDialog_description_Context(getObject(), editor.description, appendPath("description"));
      ctx.traverse(visitor, null);
    }
    if (dueDateDelegate != null) {
      EditTaskDialog_dueDate_Context ctx = new EditTaskDialog_dueDate_Context(getObject(), editor.dueDate.asEditor(), appendPath("dueDate"));
      ctx.setEditorDelegate(dueDateDelegate);
      ctx.traverse(visitor, dueDateDelegate);
    }
    if (dueDateDelegate0 != null) {
      EditTaskDialog_dueDate_Context ctx = new EditTaskDialog_dueDate_Context(getObject(), editor.dueDate, appendPath("dueDate"));
      ctx.setEditorDelegate(dueDateDelegate0);
      ctx.traverse(visitor, dueDateDelegate0);
    }
     {
      EditTaskDialog_priority_Context ctx = new EditTaskDialog_priority_Context(getObject(), editor.priority.asEditor(), appendPath("priority"));
      ctx.traverse(visitor, null);
    }
     {
      EditTaskDialog_priority_Context ctx = new EditTaskDialog_priority_Context(getObject(), editor.priority, appendPath("priority"));
      ctx.traverse(visitor, null);
    }
    if (projectDelegate != null) {
      EditTaskDialog_project_Context ctx = new EditTaskDialog_project_Context(getObject(), editor.project.asEditor(), appendPath("project"));
      ctx.setEditorDelegate(projectDelegate);
      ctx.traverse(visitor, projectDelegate);
    }
    if (projectDelegate0 != null) {
      EditTaskDialog_project_Context ctx = new EditTaskDialog_project_Context(getObject(), editor.project, appendPath("project"));
      ctx.setEditorDelegate(projectDelegate0);
      ctx.traverse(visitor, projectDelegate0);
    }
    if (tagsDelegate != null) {
      EditTaskDialog_tags_Context ctx = new EditTaskDialog_tags_Context(getObject(), editor.tags.asEditor(), appendPath("tags"));
      ctx.setEditorDelegate(tagsDelegate);
      ctx.traverse(visitor, tagsDelegate);
    }
    if (tagsDelegate0 != null) {
      EditTaskDialog_tags_Context ctx = new EditTaskDialog_tags_Context(getObject(), editor.tags, appendPath("tags"));
      ctx.setEditorDelegate(tagsDelegate0);
      ctx.traverse(visitor, tagsDelegate0);
    }
  }
}
