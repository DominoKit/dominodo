/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate');
const _$Equality = goog.require('nativebootstrap.Equality');
const _DateBox__SimpleBeanEditorDelegate = goog.require('org.dominokit.domino.ui.datepicker.DateBox_SimpleBeanEditorDelegate');
const _Select__Project__SimpleBeanEditorDelegate = goog.require('org.dominokit.domino.ui.forms.Select_Project_SimpleBeanEditorDelegate');
const _TagsInput__String__SimpleBeanEditorDelegate = goog.require('org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate');
const _Task = goog.require('org.dominokit.samples.Task');
const _EditTaskDialog = goog.require('org.dominokit.samples.tasks.EditTaskDialog');
const _EditTaskDialog__description__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_description_Context');
const _EditTaskDialog__dueDate__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_dueDate_Context');
const _EditTaskDialog__priority__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_priority_Context');
const _EditTaskDialog__project__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_project_Context');
const _EditTaskDialog__tags__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_tags_Context');
const _EditTaskDialog__title__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_title_Context');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _LeafValueEditor__Date__SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate');
const _LeafValueEditor__List__1String__SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.LeafValueEditor_List_1String_SimpleBeanEditorDelegate');
const _LeafValueEditor__Project__SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.LeafValueEditor_Project_SimpleBeanEditorDelegate');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EditTaskDialog__SimpleBeanEditorDelegate = goog.require('org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate$impl');
exports = EditTaskDialog__SimpleBeanEditorDelegate;
 