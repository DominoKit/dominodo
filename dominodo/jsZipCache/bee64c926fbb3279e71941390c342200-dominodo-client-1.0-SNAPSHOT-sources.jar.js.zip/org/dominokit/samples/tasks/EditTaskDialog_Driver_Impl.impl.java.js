/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Driver = goog.require('org.dominokit.samples.tasks.EditTaskDialog.Driver$impl');
const AbstractSimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let EditTaskDialog = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog$impl');
let EditTaskDialog__SimpleBeanEditorDelegate = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let RootEditorContext = goog.forwardDeclare('org.gwtproject.editor.client.impl.RootEditorContext$impl');
let SimpleBeanEditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {AbstractSimpleBeanEditorDriver<Task, EditTaskDialog>}
 * @implements {Driver}
  */
class EditTaskDialog__Driver__Impl extends AbstractSimpleBeanEditorDriver {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!EditTaskDialog__Driver__Impl}
   * @public
   */
  static $create__() {
    EditTaskDialog__Driver__Impl.$clinit();
    let $instance = new EditTaskDialog__Driver__Impl();
    $instance.$ctor__org_dominokit_samples_tasks_EditTaskDialog_Driver_Impl__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_EditTaskDialog_Driver_Impl__() {
    this.$ctor__org_gwtproject_editor_client_impl_AbstractSimpleBeanEditorDriver__();
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
    let ctx = /**@type {!RootEditorContext<Task>} */ (RootEditorContext.$create__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_Class__java_lang_Object(this.m_getDelegate__(), /**@type {Class<Task>} */ ($Casts.$to($Casts.$to(Class.$get(Task), Class), Class)), /**@type {Task} */ ($Casts.$to(this.m_getObject__(), Task))));
    ctx.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, this.m_getDelegate__());
  }
  
  /**
   * @override
   * @return {SimpleBeanEditorDelegate<Task, EditTaskDialog>}
   * @public
   */
  m_createDelegate__() {
    return EditTaskDialog__SimpleBeanEditorDelegate.$create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditTaskDialog__Driver__Impl.$clinit = (() =>{
    });
    EditTaskDialog__Driver__Impl.$loadModules();
    AbstractSimpleBeanEditorDriver.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EditTaskDialog__Driver__Impl;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EditTaskDialog__Driver__Impl);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Class = goog.module.get('java.lang.Class$impl');
    Task = goog.module.get('org.dominokit.samples.Task$impl');
    EditTaskDialog__SimpleBeanEditorDelegate = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate$impl');
    RootEditorContext = goog.module.get('org.gwtproject.editor.client.impl.RootEditorContext$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(EditTaskDialog__Driver__Impl, $Util.$makeClassName('org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl'));


Driver.$markImplementor(EditTaskDialog__Driver__Impl);


exports = EditTaskDialog__Driver__Impl; 
//# sourceMappingURL=EditTaskDialog_Driver_Impl.js.map