package org.dominokit.samples.tasks;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import javax.annotation.Generated;
import org.dominokit.samples.Project;
import org.dominokit.samples.Task;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.impl.AbstractEditorContext;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class EditTaskDialog_project_Context extends AbstractEditorContext<Project> {
  private final Task parent;

  public EditTaskDialog_project_Context(Task parent, Editor<Project> editor, String path) {
    super(editor, path);
    this.parent = parent;
  }

  @Override
  public boolean canSetInModel() {
    return parent != null && true && true;
  }

  @Override
  public Project checkAssignment(Object value) {
    return (Project) value;
  }

  @Override
  public Class getEditedType() {
    return org.dominokit.samples.Project.class;
  }

  @Override
  public Project getFromModel() {
    return (parent != null && true) ? parent.getProject() : null;
  }

  @Override
  public void setInModel(Project data) {
    parent.setProject(data);;
  }
}
