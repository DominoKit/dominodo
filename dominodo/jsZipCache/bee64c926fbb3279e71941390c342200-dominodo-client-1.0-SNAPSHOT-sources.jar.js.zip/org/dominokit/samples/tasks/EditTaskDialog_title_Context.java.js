/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_title_Context.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_title_Context');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractEditorContext = goog.require('org.gwtproject.editor.client.impl.AbstractEditorContext');
const _Class = goog.require('java.lang.Class');
const _j_l_String = goog.require('java.lang.String');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Task = goog.require('org.dominokit.samples.Task');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EditTaskDialog__title__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_title_Context$impl');
exports = EditTaskDialog__title__Context;
 