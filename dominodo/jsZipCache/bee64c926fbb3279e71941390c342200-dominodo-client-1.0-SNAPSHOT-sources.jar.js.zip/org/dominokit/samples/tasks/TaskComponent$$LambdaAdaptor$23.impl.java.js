/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TaskComponent$$LambdaAdaptor$23.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.TaskComponent.$LambdaAdaptor$23$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$23 extends j_l_Object {
  /**
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$23.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_samples_tasks_TaskComponent_$LambdaAdaptor$23;
    this.$ctor__org_dominokit_samples_tasks_TaskComponent_$LambdaAdaptor$23__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_TaskComponent_$LambdaAdaptor$23__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_samples_tasks_TaskComponent_$LambdaAdaptor$23 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_samples_tasks_TaskComponent_$LambdaAdaptor$23;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$23.$clinit = (() =>{
    });
    $LambdaAdaptor$23.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$23;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$23);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$23, $Util.$makeClassName('org.dominokit.samples.tasks.TaskComponent$$LambdaAdaptor$23'));




exports = $LambdaAdaptor$23; 
//# sourceMappingURL=TaskComponent$$LambdaAdaptor$23.js.map