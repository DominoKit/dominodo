package org.dominokit.samples.tasks;

import org.dominokit.samples.Task;

public interface HasTask {
    Task getTask();
}
