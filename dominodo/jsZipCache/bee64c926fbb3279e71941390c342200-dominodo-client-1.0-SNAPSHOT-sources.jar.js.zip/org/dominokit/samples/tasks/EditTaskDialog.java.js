/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasTask = goog.require('org.dominokit.samples.tasks.HasTask');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Date = goog.require('java.util.Date');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _DateBox = goog.require('org.dominokit.domino.ui.datepicker.DateBox');
const _DateDayClickedHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler');
const _FieldsGrouping = goog.require('org.dominokit.domino.ui.forms.FieldsGrouping');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _TextArea = goog.require('org.dominokit.domino.ui.forms.TextArea');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ModalDialog = goog.require('org.dominokit.domino.ui.modals.ModalDialog');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _TagsInput = goog.require('org.dominokit.domino.ui.tag.TagsInput');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _Constants = goog.require('org.dominokit.samples.Constants');
const _Priority = goog.require('org.dominokit.samples.Priority');
const _Project = goog.require('org.dominokit.samples.Project');
const _Task = goog.require('org.dominokit.samples.Task');
const _FileUploadComponent = goog.require('org.dominokit.samples.attachments.FileUploadComponent');
const _$LambdaAdaptor$16 = goog.require('org.dominokit.samples.tasks.EditTaskDialog.$LambdaAdaptor$16');
const _$LambdaAdaptor$17 = goog.require('org.dominokit.samples.tasks.EditTaskDialog.$LambdaAdaptor$17');
const _Driver = goog.require('org.dominokit.samples.tasks.EditTaskDialog.Driver');
const _EditTaskDialog__Driver__Impl = goog.require('org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl');
const _TasksRepository = goog.require('org.dominokit.samples.tasks.TasksRepository');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EditTaskDialog = goog.require('org.dominokit.samples.tasks.EditTaskDialog$impl');
exports = EditTaskDialog;
 