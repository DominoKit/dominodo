/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog$Driver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog.Driver$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.SimpleBeanEditorDriver$impl');

let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let EditTaskDialog = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog$impl');


/**
 * @interface
 * @extends {SimpleBeanEditorDriver<Task, EditTaskDialog>}
 */
class Driver {
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Driver.$clinit = (() =>{
    });
    Driver.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    SimpleBeanEditorDriver.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_samples_tasks_EditTaskDialog_Driver = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_samples_tasks_EditTaskDialog_Driver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_samples_tasks_EditTaskDialog_Driver;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(Driver, $Util.$makeClassName('org.dominokit.samples.tasks.EditTaskDialog$Driver'));


Driver.$markImplementor(/** @type {Function} */ (Driver));


exports = Driver; 
//# sourceMappingURL=EditTaskDialog$Driver.js.map