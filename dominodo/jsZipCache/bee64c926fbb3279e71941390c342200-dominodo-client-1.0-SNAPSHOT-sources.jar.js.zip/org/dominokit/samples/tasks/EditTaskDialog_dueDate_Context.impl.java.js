/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_dueDate_Context.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_dueDate_Context$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractEditorContext = goog.require('org.gwtproject.editor.client.impl.AbstractEditorContext$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {AbstractEditorContext<Date>}
  */
class EditTaskDialog__dueDate__Context extends AbstractEditorContext {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Task} */
    this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context_;
  }
  
  /**
   * @param {Task} parent
   * @param {Editor<Date>} editor
   * @param {?string} path
   * @return {!EditTaskDialog__dueDate__Context}
   * @public
   */
  static $create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(parent, editor, path) {
    EditTaskDialog__dueDate__Context.$clinit();
    let $instance = new EditTaskDialog__dueDate__Context();
    $instance.$ctor__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(parent, editor, path);
    return $instance;
  }
  
  /**
   * @param {Task} parent
   * @param {Editor<Date>} editor
   * @param {?string} path
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(parent, editor, path) {
    this.$ctor__org_gwtproject_editor_client_impl_AbstractEditorContext__org_gwtproject_editor_client_Editor__java_lang_String(editor, path);
    this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context_ = parent;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_canSetInModel__() {
    return !$Equality.$same(this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context_, null) && true && true;
  }
  
  /**
   * @override
   * @param {*} value
   * @return {Date}
   * @public
   */
  m_checkAssignment__java_lang_Object(value) {
    return /**@type {Date} */ ($Casts.$to(value, Date));
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getEditedType__() {
    return Class.$get(Date);
  }
  
  /**
   * @override
   * @return {Date}
   * @public
   */
  m_getFromModel__() {
    return (!$Equality.$same(this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context_, null) && true) ? this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context_.m_getDueDate__() : null;
  }
  
  /**
   * @param {Date} data
   * @return {void}
   * @public
   */
  m_setInModel__java_util_Date(data) {
    this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_dueDate_Context_.m_setDueDate__java_util_Date(data);
    
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setInModel__java_lang_Object(arg0) {
    this.m_setInModel__java_util_Date(/**@type {Date} */ ($Casts.$to(arg0, Date)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditTaskDialog__dueDate__Context.$clinit = (() =>{
    });
    EditTaskDialog__dueDate__Context.$loadModules();
    AbstractEditorContext.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EditTaskDialog__dueDate__Context;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EditTaskDialog__dueDate__Context);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Class = goog.module.get('java.lang.Class$impl');
    Date = goog.module.get('java.util.Date$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(EditTaskDialog__dueDate__Context, $Util.$makeClassName('org.dominokit.samples.tasks.EditTaskDialog_dueDate_Context'));




exports = EditTaskDialog__dueDate__Context; 
//# sourceMappingURL=EditTaskDialog_dueDate_Context.js.map