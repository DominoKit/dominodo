/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.HasTask$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.HasTask.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasTask = goog.require('org.dominokit.samples.tasks.HasTask$impl');

let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');


/**
 * @implements {HasTask}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function():Task} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Task} */
    this.f_$$fn__org_dominokit_samples_tasks_HasTask_$LambdaAdaptor;
    this.$ctor__org_dominokit_samples_tasks_HasTask_$LambdaAdaptor__org_dominokit_samples_tasks_HasTask_$JsFunction(fn);
  }
  
  /**
   * @param {?function():Task} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_HasTask_$LambdaAdaptor__org_dominokit_samples_tasks_HasTask_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_samples_tasks_HasTask_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Task}
   * @public
   */
  m_getTask__() {
    let /** ?function():Task */ $function;
    return ($function = this.f_$$fn__org_dominokit_samples_tasks_HasTask_$LambdaAdaptor, $function());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.samples.tasks.HasTask$$LambdaAdaptor'));


HasTask.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=HasTask$$LambdaAdaptor.js.map