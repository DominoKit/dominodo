package org.dominokit.samples.tasks;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import javax.annotation.Generated;
import org.dominokit.samples.Task;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.impl.AbstractEditorContext;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class EditTaskDialog_tags_Context extends AbstractEditorContext<List<String>> {
  private final Task parent;

  public EditTaskDialog_tags_Context(Task parent, Editor<List<String>> editor, String path) {
    super(editor, path);
    this.parent = parent;
  }

  @Override
  public boolean canSetInModel() {
    return parent != null && true && true;
  }

  @Override
  public List<String> checkAssignment(Object value) {
    return (List<String>) value;
  }

  @Override
  public Class getEditedType() {
    return java.util.List.class;
  }

  @Override
  public List<String> getFromModel() {
    return (parent != null && true) ? parent.getTags() : null;
  }

  @Override
  public void setInModel(List<String> data) {
    parent.setTags(data);;
  }
}
