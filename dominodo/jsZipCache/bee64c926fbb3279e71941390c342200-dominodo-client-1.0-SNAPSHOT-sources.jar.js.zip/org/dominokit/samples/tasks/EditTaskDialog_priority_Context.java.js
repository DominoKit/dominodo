/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_priority_Context.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_priority_Context');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractEditorContext = goog.require('org.gwtproject.editor.client.impl.AbstractEditorContext');
const _Class = goog.require('java.lang.Class');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Priority = goog.require('org.dominokit.samples.Priority');
const _Task = goog.require('org.dominokit.samples.Task');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EditTaskDialog__priority__Context = goog.require('org.dominokit.samples.tasks.EditTaskDialog_priority_Context$impl');
exports = EditTaskDialog__priority__Context;
 