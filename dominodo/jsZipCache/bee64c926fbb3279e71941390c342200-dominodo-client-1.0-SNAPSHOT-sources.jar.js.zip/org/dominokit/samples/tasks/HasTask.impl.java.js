/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.HasTask.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.HasTask$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.samples.tasks.HasTask.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasTask {
  /**
   * @abstract
   * @return {Task}
   * @public
   */
  m_getTask__() {
  }
  
  /**
   * @param {?function():Task} fn
   * @return {HasTask}
   * @public
   */
  static $adapt(fn) {
    HasTask.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasTask.$clinit = (() =>{
    });
    HasTask.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_samples_tasks_HasTask = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_samples_tasks_HasTask;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_samples_tasks_HasTask;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.samples.tasks.HasTask.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasTask, $Util.$makeClassName('org.dominokit.samples.tasks.HasTask'));


HasTask.$markImplementor(/** @type {Function} */ (HasTask));


exports = HasTask; 
//# sourceMappingURL=HasTask.js.map