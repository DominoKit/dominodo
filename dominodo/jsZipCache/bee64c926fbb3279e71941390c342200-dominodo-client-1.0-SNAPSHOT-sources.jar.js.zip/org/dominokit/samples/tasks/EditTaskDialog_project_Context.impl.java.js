/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_project_Context.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_project_Context$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractEditorContext = goog.require('org.gwtproject.editor.client.impl.AbstractEditorContext$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Project = goog.forwardDeclare('org.dominokit.samples.Project$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {AbstractEditorContext<Project>}
  */
class EditTaskDialog__project__Context extends AbstractEditorContext {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Task} */
    this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_project_Context_;
  }
  
  /**
   * @param {Task} parent
   * @param {Editor<Project>} editor
   * @param {?string} path
   * @return {!EditTaskDialog__project__Context}
   * @public
   */
  static $create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(parent, editor, path) {
    EditTaskDialog__project__Context.$clinit();
    let $instance = new EditTaskDialog__project__Context();
    $instance.$ctor__org_dominokit_samples_tasks_EditTaskDialog_project_Context__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(parent, editor, path);
    return $instance;
  }
  
  /**
   * @param {Task} parent
   * @param {Editor<Project>} editor
   * @param {?string} path
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_EditTaskDialog_project_Context__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(parent, editor, path) {
    this.$ctor__org_gwtproject_editor_client_impl_AbstractEditorContext__org_gwtproject_editor_client_Editor__java_lang_String(editor, path);
    this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_project_Context_ = parent;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_canSetInModel__() {
    return !$Equality.$same(this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_project_Context_, null) && true && true;
  }
  
  /**
   * @override
   * @param {*} value
   * @return {Project}
   * @public
   */
  m_checkAssignment__java_lang_Object(value) {
    return /**@type {Project} */ ($Casts.$to(value, Project));
  }
  
  /**
   * @override
   * @return {Class}
   * @public
   */
  m_getEditedType__() {
    return Class.$get(Project);
  }
  
  /**
   * @override
   * @return {Project}
   * @public
   */
  m_getFromModel__() {
    return (!$Equality.$same(this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_project_Context_, null) && true) ? this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_project_Context_.m_getProject__() : null;
  }
  
  /**
   * @param {Project} data
   * @return {void}
   * @public
   */
  m_setInModel__org_dominokit_samples_Project(data) {
    this.f_parent__org_dominokit_samples_tasks_EditTaskDialog_project_Context_.m_setProject__org_dominokit_samples_Project(data);
    
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setInModel__java_lang_Object(arg0) {
    this.m_setInModel__org_dominokit_samples_Project(/**@type {Project} */ ($Casts.$to(arg0, Project)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditTaskDialog__project__Context.$clinit = (() =>{
    });
    EditTaskDialog__project__Context.$loadModules();
    AbstractEditorContext.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EditTaskDialog__project__Context;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EditTaskDialog__project__Context);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Class = goog.module.get('java.lang.Class$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    Project = goog.module.get('org.dominokit.samples.Project$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(EditTaskDialog__project__Context, $Util.$makeClassName('org.dominokit.samples.tasks.EditTaskDialog_project_Context'));




exports = EditTaskDialog__project__Context; 
//# sourceMappingURL=EditTaskDialog_project_Context.js.map