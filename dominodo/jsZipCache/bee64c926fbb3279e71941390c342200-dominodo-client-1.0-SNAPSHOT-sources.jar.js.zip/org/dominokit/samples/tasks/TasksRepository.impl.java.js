/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TasksRepository.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.TasksRepository$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let j_u_Date = goog.forwardDeclare('java.util.Date$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Constants = goog.forwardDeclare('org.dominokit.samples.Constants$impl');
let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let Project = goog.forwardDeclare('org.dominokit.samples.Project$impl');
let Status = goog.forwardDeclare('org.dominokit.samples.Status$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $LongUtils = goog.forwardDeclare('vmbootstrap.LongUtils$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


class TasksRepository extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<Task>} */
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_;
    /** @public {number} @const */
    this.f__1_day__org_dominokit_samples_tasks_TasksRepository_ = 86400000;
  }
  
  /**
   * @return {!TasksRepository}
   * @public
   */
  static $create__() {
    TasksRepository.$clinit();
    let $instance = new TasksRepository();
    $instance.$ctor__org_dominokit_samples_tasks_TasksRepository__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_TasksRepository__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_samples_tasks_TasksRepository();
    this.m_addInitialData___$p_org_dominokit_samples_tasks_TasksRepository();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addInitialData___$p_org_dominokit_samples_tasks_TasksRepository() {
    let dominoUi = Project.$create__();
    dominoUi.m_setName__java_lang_String(Constants.f_DOMINO_UI__org_dominokit_samples_Constants);
    dominoUi.m_setColor__java_lang_String(Color.f_INDIGO__org_dominokit_domino_ui_style_Color.m_getName__());
    dominoUi.m_setIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_widgets__().m_getName__());
    TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.put(dominoUi.m_getName__(), dominoUi);
    let nalue = Project.$create__();
    nalue.m_setName__java_lang_String(Constants.f_NALU_MVP__org_dominokit_samples_Constants);
    nalue.m_setColor__java_lang_String(Color.f_BLUE__org_dominokit_domino_ui_style_Color.m_getName__());
    nalue.m_setIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_call_split__().m_getName__());
    TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.put(nalue.m_getName__(), nalue);
    let gwt = Project.$create__();
    gwt.m_setName__java_lang_String(Constants.f_GWT__org_dominokit_samples_Constants);
    gwt.m_setColor__java_lang_String(Color.f_PINK__org_dominokit_domino_ui_style_Color.m_getName__());
    gwt.m_setIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_polymer__().m_getName__());
    TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.put(gwt.m_getName__(), gwt);
    let movies = Project.$create__();
    movies.m_setName__java_lang_String(Constants.f_MOVIES__org_dominokit_samples_Constants);
    movies.m_setColor__java_lang_String(Color.f_BROWN__org_dominokit_domino_ui_style_Color.m_getName__());
    movies.m_setIcon__java_lang_String(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_camera_roll__().m_getName__());
    TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository.put(movies.m_getName__(), movies);
    let task1 = Task.$create__();
    task1.m_setDueDate__java_util_Date(j_u_Date.$create__());
    task1.m_setPriority__org_dominokit_samples_Priority(Priority.f_NORMAL__org_dominokit_samples_Priority);
    task1.m_setDescription__java_lang_String("TextBox setRightAddon, removeRightAddon and setRightAddon again throws Exception");
    task1.m_setTitle__java_lang_String("Text box icons");
    task1.m_setProject__org_dominokit_samples_Project(dominoUi);
    task1.m_setStatus__org_dominokit_samples_Status(Status.f_ACTIVE__org_dominokit_samples_Status);
    task1.m_getTags__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Bug", "Milestone 1.0"], j_l_String)))));
    task1.m_getAttachments__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["File 1", "File 2"], j_l_String)))));
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.add(task1);
    let task2 = Task.$create__();
    task2.m_setDueDate__java_util_Date(j_u_Date.$create__long($LongUtils.$plus(j_u_Date.$create__().m_getTime__(), $Primitives.$widenIntToLong((2 * this.f__1_day__org_dominokit_samples_tasks_TasksRepository_)))));
    task2.m_setPriority__org_dominokit_samples_Priority(Priority.f_NORMAL__org_dominokit_samples_Priority);
    task2.m_setDescription__java_lang_String("Router: create the possibility to work with permissions in case of routing");
    task2.m_setTitle__java_lang_String("Router/Permissions");
    task2.m_setProject__org_dominokit_samples_Project(nalue);
    task2.m_setStatus__org_dominokit_samples_Status(Status.f_ACTIVE__org_dominokit_samples_Status);
    task2.m_getTags__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Enhancements", "Router", "Milestone 1.0"], j_l_String)))));
    task2.m_getAttachments__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["File 1", "File 2", "File 3"], j_l_String)))));
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.add(task2);
    let task3 = Task.$create__();
    task3.m_setDueDate__java_util_Date(j_u_Date.$create__long($LongUtils.$plus(j_u_Date.$create__().m_getTime__(), $Primitives.$widenIntToLong(this.f__1_day__org_dominokit_samples_tasks_TasksRepository_))));
    task3.m_setPriority__org_dominokit_samples_Priority(Priority.f_IMPORTANT__org_dominokit_samples_Priority);
    task3.m_setDescription__java_lang_String("Support for Microsoft IE 11 Browser)");
    task3.m_setTitle__java_lang_String("IE 11");
    task3.m_setProject__org_dominokit_samples_Project(dominoUi);
    task3.m_setStatus__org_dominokit_samples_Status(Status.f_ACTIVE__org_dominokit_samples_Status);
    task3.m_getTags__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Bug", "Browser", "Milestone 1.0"], j_l_String)))));
    task3.m_getAttachments__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["File 1", "File 2"], j_l_String)))));
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.add(task3);
    let task4 = Task.$create__();
    task4.m_setDueDate__java_util_Date(j_u_Date.$create__());
    task4.m_setPriority__org_dominokit_samples_Priority(Priority.f_NORMAL__org_dominokit_samples_Priority);
    task4.m_setDescription__java_lang_String("Tag field enhancement (open the select list on focus, navigate the list with arrows)");
    task4.m_setTitle__java_lang_String("Inter active tag field");
    task4.m_setProject__org_dominokit_samples_Project(dominoUi);
    task4.m_setStatus__org_dominokit_samples_Status(Status.f_ACTIVE__org_dominokit_samples_Status);
    task4.m_getTags__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Enhancements", "Milestone 1.0"], j_l_String)))));
    task4.m_getAttachments__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["File 1", "File 2", "File 3"], j_l_String)))));
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.add(task4);
    let task5 = Task.$create__();
    task5.m_setDueDate__java_util_Date(j_u_Date.$create__long($LongUtils.$plus(j_u_Date.$create__().m_getTime__(), $Primitives.$widenIntToLong((3 * this.f__1_day__org_dominokit_samples_tasks_TasksRepository_)))));
    task5.m_setPriority__org_dominokit_samples_Priority(Priority.f_IMPORTANT__org_dominokit_samples_Priority);
    task5.m_setDescription__java_lang_String("FormPanel setEncoding charset is not working");
    task5.m_setTitle__java_lang_String("Forms question");
    task5.m_setProject__org_dominokit_samples_Project(gwt);
    task5.m_setStatus__org_dominokit_samples_Status(Status.f_ACTIVE__org_dominokit_samples_Status);
    task5.m_getTags__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Question", "Invalid", "Milestone 3.0"], j_l_String)))));
    task5.m_getAttachments__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["File 1", "File 2", "File 3", "File 4"], j_l_String)))));
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.add(task5);
    let task6 = Task.$create__();
    task6.m_setDueDate__java_util_Date(j_u_Date.$create__long($LongUtils.$plus(j_u_Date.$create__().m_getTime__(), $Primitives.$widenIntToLong((3 * this.f__1_day__org_dominokit_samples_tasks_TasksRepository_)))));
    task6.m_setPriority__org_dominokit_samples_Priority(Priority.f_IMPORTANT__org_dominokit_samples_Priority);
    task6.m_setDescription__java_lang_String("Spirited away was recommended to me by a friend");
    task6.m_setTitle__java_lang_String("Watch spirited away");
    task6.m_setProject__org_dominokit_samples_Project(movies);
    task6.m_setStatus__org_dominokit_samples_Status(Status.f_ACTIVE__org_dominokit_samples_Status);
    task6.m_getTags__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["Anime", "Ghibli"], j_l_String)))));
    task6.m_getAttachments__().addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(/**@type {!Array<?string>} */ ($Arrays.$init(["File 1"], j_l_String)))));
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.add(task6);
  }
  
  /**
   * @return {List<Task>}
   * @public
   */
  m_listAll__() {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ arg0) =>{
      return arg0.m_isActive__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @param {?string} projectName
   * @return {List<Task>}
   * @public
   */
  m_listByProjectName__java_lang_String(projectName) {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ task) =>{
      return j_l_String.m_equals__java_lang_String__java_lang_Object(task.m_getProject__().m_getName__(), projectName) && task.m_isActive__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @param {Priority} priority
   * @return {List<Task>}
   * @public
   */
  m_listByPriority__org_dominokit_samples_Priority(priority) {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ task) =>{
      return $Objects.m_equals__java_lang_Object__java_lang_Object(task.m_getPriority__(), priority) && task.m_isActive__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {List<Task>}
   * @public
   */
  m_listTodayTasks__() {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ task) =>{
      let todayDate = new Date();
      let taskDate = new Date($Primitives.$widenLongToDouble(task.m_getDueDate__().m_getTime__()));
      return todayDate.getYear() == taskDate.getYear() && todayDate.getMonth() == taskDate.getMonth() && todayDate.getDate() == taskDate.getDate() && task.m_isActive__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {List<Task>}
   * @public
   */
  m_listNextWeekTasks__() {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ task) =>{
      let todayDate = new Date();
      let taskDate = new Date($Primitives.$widenLongToDouble(task.m_getDueDate__().m_getTime__()));
      let diff = taskDate.getTime() - todayDate.getTime();
      return diff > 0 && diff <= 604800000 && task.m_isActive__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {List<Task>}
   * @public
   */
  m_listResolved__() {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ task) =>{
      return !task.m_isActive__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_addTask__org_dominokit_samples_Task(task) {
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.add(task);
  }
  
  /**
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_removeTask__org_dominokit_samples_Task(task) {
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.remove(task);
  }
  
  /**
   * @param {?string} tag
   * @return {List<Task>}
   * @public
   */
  m_findByTag__java_lang_String(tag) {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ task) =>{
      return task.m_isActive__() && task.m_getTags__().m_stream__().m_anyMatch__java_util_function_Predicate(Predicate.$adapt(((/** ?string */ s) =>{
        return j_l_String.m_contains__java_lang_String__java_lang_CharSequence(j_l_String.m_toLowerCase__java_lang_String(s), j_l_String.m_toLowerCase__java_lang_String(tag));
      })));
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @param {?string} searchText
   * @return {List<Task>}
   * @public
   */
  m_findTasks__java_lang_String(searchText) {
    return /**@type {List<Task>} */ ($Casts.$to(this.f_tasks__org_dominokit_samples_tasks_TasksRepository_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Task */ task) =>{
      return task.m_isActive__() && (j_l_String.m_contains__java_lang_String__java_lang_CharSequence(task.m_getTitle__(), j_l_String.m_toLowerCase__java_lang_String(searchText)) || j_l_String.m_contains__java_lang_String__java_lang_CharSequence(j_l_String.m_toLowerCase__java_lang_String(task.m_getDescription__()), j_l_String.m_toLowerCase__java_lang_String(searchText)) || j_l_String.m_contains__java_lang_String__java_lang_CharSequence(j_l_String.m_toLowerCase__java_lang_String(task.m_getProject__().m_getName__()), j_l_String.m_toLowerCase__java_lang_String(searchText)) || task.m_getTags__().m_stream__().m_anyMatch__java_util_function_Predicate(Predicate.$adapt(((/** ?string */ tag) =>{
        return j_l_String.m_contains__java_lang_String__java_lang_CharSequence(j_l_String.m_toLowerCase__java_lang_String(tag), j_l_String.m_toLowerCase__java_lang_String(searchText));
      }))));
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Task, ?, List<Task>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_tasks_TasksRepository() {
    this.f_tasks__org_dominokit_samples_tasks_TasksRepository_ = /**@type {!ArrayList<Task>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {Map<?string, Project>}
   * @public
   */
  static get f_PROJECTS__org_dominokit_samples_tasks_TasksRepository() {
    return (TasksRepository.$clinit(), TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository);
  }
  
  /**
   * @param {Map<?string, Project>} value
   * @return {void}
   * @public
   */
  static set f_PROJECTS__org_dominokit_samples_tasks_TasksRepository(value) {
    (TasksRepository.$clinit(), TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TasksRepository.$clinit = (() =>{
    });
    TasksRepository.$loadModules();
    j_l_Object.$clinit();
    TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository = /**@type {!HashMap<?string, Project>} */ (HashMap.$create__());
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TasksRepository;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TasksRepository);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Arrays = goog.module.get('java.util.Arrays$impl');
    j_u_Date = goog.module.get('java.util.Date$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    List = goog.module.get('java.util.List$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Constants = goog.module.get('org.dominokit.samples.Constants$impl');
    Priority = goog.module.get('org.dominokit.samples.Priority$impl');
    Project = goog.module.get('org.dominokit.samples.Project$impl');
    Status = goog.module.get('org.dominokit.samples.Status$impl');
    Task = goog.module.get('org.dominokit.samples.Task$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $LongUtils = goog.module.get('vmbootstrap.LongUtils$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
  }
  
  
};

$Util.$setClassMetadata(TasksRepository, $Util.$makeClassName('org.dominokit.samples.tasks.TasksRepository'));


/** @private {Map<?string, Project>} */
TasksRepository.$f_PROJECTS__org_dominokit_samples_tasks_TasksRepository;




exports = TasksRepository; 
//# sourceMappingURL=TasksRepository.js.map