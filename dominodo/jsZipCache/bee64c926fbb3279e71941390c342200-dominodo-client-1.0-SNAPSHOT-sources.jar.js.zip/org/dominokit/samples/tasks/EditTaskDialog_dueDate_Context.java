package org.dominokit.samples.tasks;

import java.lang.Class;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Date;
import javax.annotation.Generated;
import org.dominokit.samples.Task;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.impl.AbstractEditorContext;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class EditTaskDialog_dueDate_Context extends AbstractEditorContext<Date> {
  private final Task parent;

  public EditTaskDialog_dueDate_Context(Task parent, Editor<Date> editor, String path) {
    super(editor, path);
    this.parent = parent;
  }

  @Override
  public boolean canSetInModel() {
    return parent != null && true && true;
  }

  @Override
  public Date checkAssignment(Object value) {
    return (Date) value;
  }

  @Override
  public Class getEditedType() {
    return java.util.Date.class;
  }

  @Override
  public Date getFromModel() {
    return (parent != null && true) ? parent.getDueDate() : null;
  }

  @Override
  public void setInModel(Date data) {
    parent.setDueDate(data);;
  }
}
