package org.dominokit.samples.tasks;

import java.lang.Override;
import javax.annotation.Generated;
import org.dominokit.samples.Task;
import org.gwtproject.editor.client.EditorVisitor;
import org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver;
import org.gwtproject.editor.client.impl.RootEditorContext;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class EditTaskDialog_Driver_Impl extends AbstractSimpleBeanEditorDriver<Task, EditTaskDialog> implements EditTaskDialog.Driver {
  @Override
  public void accept(EditorVisitor visitor) {
    RootEditorContext<Task> ctx = new RootEditorContext<Task>(getDelegate(), (Class<Task>)(Class)org.dominokit.samples.Task.class, getObject());
    ctx.traverse(visitor, getDelegate());
  }

  @Override
  protected SimpleBeanEditorDelegate<Task, EditTaskDialog> createDelegate() {
    return new EditTaskDialog_SimpleBeanEditorDelegate();
  }
}
