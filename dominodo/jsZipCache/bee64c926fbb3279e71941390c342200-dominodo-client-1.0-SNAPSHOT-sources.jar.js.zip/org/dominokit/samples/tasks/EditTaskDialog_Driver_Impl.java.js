/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Driver = goog.require('org.dominokit.samples.tasks.EditTaskDialog.Driver');
const _AbstractSimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver');
const _Class = goog.require('java.lang.Class');
const _Task = goog.require('org.dominokit.samples.Task');
const _EditTaskDialog = goog.require('org.dominokit.samples.tasks.EditTaskDialog');
const _EditTaskDialog__SimpleBeanEditorDelegate = goog.require('org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _RootEditorContext = goog.require('org.gwtproject.editor.client.impl.RootEditorContext');
const _SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EditTaskDialog__Driver__Impl = goog.require('org.dominokit.samples.tasks.EditTaskDialog_Driver_Impl$impl');
exports = EditTaskDialog__Driver__Impl;
 