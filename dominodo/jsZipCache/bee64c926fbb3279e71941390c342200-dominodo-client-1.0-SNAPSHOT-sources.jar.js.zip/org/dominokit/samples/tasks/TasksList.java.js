/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.TasksList.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.TasksList');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _Animation = goog.require('org.dominokit.domino.ui.animations.Animation');
const _StartHandler = goog.require('org.dominokit.domino.ui.animations.Animation.StartHandler');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Row__12 = goog.require('org.dominokit.domino.ui.grid.Row_12');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _EmptyState = goog.require('org.dominokit.domino.ui.layout.EmptyState');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _HasTaskUiHandlers = goog.require('org.dominokit.samples.HasTaskUiHandlers');
const _Task = goog.require('org.dominokit.samples.Task');
const _TaskComponent = goog.require('org.dominokit.samples.tasks.TaskComponent');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TasksList = goog.require('org.dominokit.samples.tasks.TasksList$impl');
exports = TasksList;
 