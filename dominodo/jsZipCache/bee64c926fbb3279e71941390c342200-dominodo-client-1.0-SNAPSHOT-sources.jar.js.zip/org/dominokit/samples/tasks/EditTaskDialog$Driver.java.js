/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog$Driver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog.Driver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.SimpleBeanEditorDriver');
const _Task = goog.require('org.dominokit.samples.Task');
const _EditTaskDialog = goog.require('org.dominokit.samples.tasks.EditTaskDialog');


// Re-exports the implementation.
var Driver = goog.require('org.dominokit.samples.tasks.EditTaskDialog.Driver$impl');
exports = Driver;
 