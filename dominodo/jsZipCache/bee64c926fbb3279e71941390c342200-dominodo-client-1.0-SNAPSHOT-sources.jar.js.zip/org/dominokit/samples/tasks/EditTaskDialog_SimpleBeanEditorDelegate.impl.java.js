/**
 * @fileoverview transpiled from org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let DateBox__SimpleBeanEditorDelegate = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox_SimpleBeanEditorDelegate$impl');
let Select__Project__SimpleBeanEditorDelegate = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select_Project_SimpleBeanEditorDelegate$impl');
let TagsInput__String__SimpleBeanEditorDelegate = goog.forwardDeclare('org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let EditTaskDialog = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog$impl');
let EditTaskDialog__description__Context = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_description_Context$impl');
let EditTaskDialog__dueDate__Context = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_dueDate_Context$impl');
let EditTaskDialog__priority__Context = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_priority_Context$impl');
let EditTaskDialog__project__Context = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_project_Context$impl');
let EditTaskDialog__tags__Context = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_tags_Context$impl');
let EditTaskDialog__title__Context = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog_title_Context$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let LeafValueEditor__Date__SimpleBeanEditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate$impl');
let LeafValueEditor__List__1String__SimpleBeanEditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor_List_1String_SimpleBeanEditorDelegate$impl');
let LeafValueEditor__Project__SimpleBeanEditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor_Project_SimpleBeanEditorDelegate$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class EditTaskDialog__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {EditTaskDialog} */
    this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
    /** @public {Task} */
    this.f_object__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
    /** @public {SimpleBeanEditorDelegate} */
    this.f_dueDateDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
    /** @public {SimpleBeanEditorDelegate} */
    this.f_dueDateDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
    /** @public {SimpleBeanEditorDelegate} */
    this.f_projectDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
    /** @public {SimpleBeanEditorDelegate} */
    this.f_projectDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
    /** @public {SimpleBeanEditorDelegate} */
    this.f_tagsDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
    /** @public {SimpleBeanEditorDelegate} */
    this.f_tagsDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!EditTaskDialog__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    EditTaskDialog__SimpleBeanEditorDelegate.$clinit();
    let $instance = new EditTaskDialog__SimpleBeanEditorDelegate();
    $instance.$ctor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {EditTaskDialog}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = /**@type {EditTaskDialog} */ ($Casts.$to(editor, EditTaskDialog));
  }
  
  /**
   * @override
   * @return {Task}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = /**@type {Task} */ ($Casts.$to(object, Task));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
    if (!$Equality.$same(this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), null)) {
      this.f_dueDateDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = LeafValueEditor__Date__SimpleBeanEditorDelegate.$create__();
      this.m_addSubDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_String__org_gwtproject_editor_client_Editor(this.f_dueDateDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, this.m_appendPath__java_lang_String("dueDate"), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__());
    }
    if (!$Equality.$same(this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog, null)) {
      this.f_dueDateDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = DateBox__SimpleBeanEditorDelegate.$create__();
      this.m_addSubDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_String__org_gwtproject_editor_client_Editor(this.f_dueDateDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, this.m_appendPath__java_lang_String("dueDate"), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog);
    }
    if (!$Equality.$same(this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_project__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), null)) {
      this.f_projectDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = LeafValueEditor__Project__SimpleBeanEditorDelegate.$create__();
      this.m_addSubDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_String__org_gwtproject_editor_client_Editor(this.f_projectDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, this.m_appendPath__java_lang_String("project"), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_project__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__());
    }
    if (!$Equality.$same(this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_project__org_dominokit_samples_tasks_EditTaskDialog, null)) {
      this.f_projectDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = Select__Project__SimpleBeanEditorDelegate.$create__();
      this.m_addSubDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_String__org_gwtproject_editor_client_Editor(this.f_projectDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, this.m_appendPath__java_lang_String("project"), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_project__org_dominokit_samples_tasks_EditTaskDialog);
    }
    if (!$Equality.$same(this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_tags__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), null)) {
      this.f_tagsDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = LeafValueEditor__List__1String__SimpleBeanEditorDelegate.$create__();
      this.m_addSubDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_String__org_gwtproject_editor_client_Editor(this.f_tagsDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, this.m_appendPath__java_lang_String("tags"), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_tags__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__());
    }
    if (!$Equality.$same(this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_tags__org_dominokit_samples_tasks_EditTaskDialog, null)) {
      this.f_tagsDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_ = TagsInput__String__SimpleBeanEditorDelegate.$create__();
      this.m_addSubDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_String__org_gwtproject_editor_client_Editor(this.f_tagsDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, this.m_appendPath__java_lang_String("tags"), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_tags__org_dominokit_samples_tasks_EditTaskDialog);
    }
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
    {
      let ctx = EditTaskDialog__title__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_title__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), this.m_appendPath__java_lang_String("title"));
      ctx.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, null);
    }
    {
      let ctx$1$ = EditTaskDialog__title__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_title__org_dominokit_samples_tasks_EditTaskDialog, this.m_appendPath__java_lang_String("title"));
      ctx$1$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, null);
    }
    {
      let ctx$2$ = EditTaskDialog__description__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_description__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), this.m_appendPath__java_lang_String("description"));
      ctx$2$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, null);
    }
    {
      let ctx$3$ = EditTaskDialog__description__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_description__org_dominokit_samples_tasks_EditTaskDialog, this.m_appendPath__java_lang_String("description"));
      ctx$3$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, null);
    }
    if (!$Equality.$same(this.f_dueDateDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, null)) {
      let ctx$4$ = EditTaskDialog__dueDate__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), this.m_appendPath__java_lang_String("dueDate"));
      ctx$4$.m_setEditorDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate(this.f_dueDateDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
      ctx$4$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, this.f_dueDateDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
    }
    if (!$Equality.$same(this.f_dueDateDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, null)) {
      let ctx$5$ = EditTaskDialog__dueDate__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_dueDate__org_dominokit_samples_tasks_EditTaskDialog, this.m_appendPath__java_lang_String("dueDate"));
      ctx$5$.m_setEditorDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate(this.f_dueDateDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
      ctx$5$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, this.f_dueDateDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
    }
    {
      let ctx$6$ = EditTaskDialog__priority__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_priority__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), this.m_appendPath__java_lang_String("priority"));
      ctx$6$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, null);
    }
    {
      let ctx$7$ = EditTaskDialog__priority__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_priority__org_dominokit_samples_tasks_EditTaskDialog, this.m_appendPath__java_lang_String("priority"));
      ctx$7$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, null);
    }
    if (!$Equality.$same(this.f_projectDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, null)) {
      let ctx$8$ = EditTaskDialog__project__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_project__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), this.m_appendPath__java_lang_String("project"));
      ctx$8$.m_setEditorDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate(this.f_projectDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
      ctx$8$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, this.f_projectDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
    }
    if (!$Equality.$same(this.f_projectDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, null)) {
      let ctx$9$ = EditTaskDialog__project__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_project__org_dominokit_samples_tasks_EditTaskDialog, this.m_appendPath__java_lang_String("project"));
      ctx$9$.m_setEditorDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate(this.f_projectDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
      ctx$9$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, this.f_projectDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
    }
    if (!$Equality.$same(this.f_tagsDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, null)) {
      let ctx$10$ = EditTaskDialog__tags__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_tags__org_dominokit_samples_tasks_EditTaskDialog.m_asEditor__(), this.m_appendPath__java_lang_String("tags"));
      ctx$10$.m_setEditorDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate(this.f_tagsDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
      ctx$10$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, this.f_tagsDelegate__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
    }
    if (!$Equality.$same(this.f_tagsDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_, null)) {
      let ctx$11$ = EditTaskDialog__tags__Context.$create__org_dominokit_samples_Task__org_gwtproject_editor_client_Editor__java_lang_String(this.m_getObject__(), this.f_editor__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_.f_tags__org_dominokit_samples_tasks_EditTaskDialog, this.m_appendPath__java_lang_String("tags"));
      ctx$11$.m_setEditorDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate(this.f_tagsDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
      ctx$11$.m_traverse__org_gwtproject_editor_client_EditorVisitor__org_gwtproject_editor_client_impl_AbstractEditorDelegate(visitor, this.f_tagsDelegate0__org_dominokit_samples_tasks_EditTaskDialog_SimpleBeanEditorDelegate_);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditTaskDialog__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    EditTaskDialog__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EditTaskDialog__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EditTaskDialog__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    DateBox__SimpleBeanEditorDelegate = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox_SimpleBeanEditorDelegate$impl');
    Select__Project__SimpleBeanEditorDelegate = goog.module.get('org.dominokit.domino.ui.forms.Select_Project_SimpleBeanEditorDelegate$impl');
    TagsInput__String__SimpleBeanEditorDelegate = goog.module.get('org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate$impl');
    Task = goog.module.get('org.dominokit.samples.Task$impl');
    EditTaskDialog = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog$impl');
    EditTaskDialog__description__Context = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_description_Context$impl');
    EditTaskDialog__dueDate__Context = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_dueDate_Context$impl');
    EditTaskDialog__priority__Context = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_priority_Context$impl');
    EditTaskDialog__project__Context = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_project_Context$impl');
    EditTaskDialog__tags__Context = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_tags_Context$impl');
    EditTaskDialog__title__Context = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog_title_Context$impl');
    LeafValueEditor__Date__SimpleBeanEditorDelegate = goog.module.get('org.gwtproject.editor.client.LeafValueEditor_Date_SimpleBeanEditorDelegate$impl');
    LeafValueEditor__List__1String__SimpleBeanEditorDelegate = goog.module.get('org.gwtproject.editor.client.LeafValueEditor_List_1String_SimpleBeanEditorDelegate$impl');
    LeafValueEditor__Project__SimpleBeanEditorDelegate = goog.module.get('org.gwtproject.editor.client.LeafValueEditor_Project_SimpleBeanEditorDelegate$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(EditTaskDialog__SimpleBeanEditorDelegate, $Util.$makeClassName('org.dominokit.samples.tasks.EditTaskDialog_SimpleBeanEditorDelegate'));




exports = EditTaskDialog__SimpleBeanEditorDelegate; 
//# sourceMappingURL=EditTaskDialog_SimpleBeanEditorDelegate.js.map