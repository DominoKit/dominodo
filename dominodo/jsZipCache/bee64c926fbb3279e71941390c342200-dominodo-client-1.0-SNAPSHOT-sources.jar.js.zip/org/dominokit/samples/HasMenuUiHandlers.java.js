/**
 * @fileoverview transpiled from org.dominokit.samples.HasMenuUiHandlers.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.HasMenuUiHandlers');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Priority = goog.require('org.dominokit.samples.Priority');


// Re-exports the implementation.
var HasMenuUiHandlers = goog.require('org.dominokit.samples.HasMenuUiHandlers$impl');
exports = HasMenuUiHandlers;
 