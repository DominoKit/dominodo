/**
 * @fileoverview transpiled from org.dominokit.samples.settings.SettingsComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.settings.SettingsComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _MouseEvent_$Overlay = goog.require('elemental2.dom.MouseEvent.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Card = goog.require('org.dominokit.domino.ui.cards.Card');
const _SwitchButton = goog.require('org.dominokit.domino.ui.forms.SwitchButton');
const _FlexItem = goog.require('org.dominokit.domino.ui.grid.flex.FlexItem');
const _FlexLayout = goog.require('org.dominokit.domino.ui.grid.flex.FlexLayout');
const _FlexWrap = goog.require('org.dominokit.domino.ui.grid.flex.FlexWrap');
const _BlockHeader = goog.require('org.dominokit.domino.ui.header.BlockHeader');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Theme = goog.require('org.dominokit.domino.ui.themes.Theme');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SettingsComponent = goog.require('org.dominokit.samples.settings.SettingsComponent$impl');
exports = SettingsComponent;
 