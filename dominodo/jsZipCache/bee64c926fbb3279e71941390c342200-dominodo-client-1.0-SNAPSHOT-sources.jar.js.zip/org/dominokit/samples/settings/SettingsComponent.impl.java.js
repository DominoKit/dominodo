/**
 * @fileoverview transpiled from org.dominokit.samples.settings.SettingsComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.settings.SettingsComponent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let MouseEvent_$Overlay = goog.forwardDeclare('elemental2.dom.MouseEvent.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card$impl');
let SwitchButton = goog.forwardDeclare('org.dominokit.domino.ui.forms.SwitchButton$impl');
let FlexItem = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
let FlexLayout = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
let FlexWrap = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexWrap$impl');
let BlockHeader = goog.forwardDeclare('org.dominokit.domino.ui.header.BlockHeader$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Theme = goog.forwardDeclare('org.dominokit.domino.ui.themes.Theme$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, SettingsComponent>}
  */
class SettingsComponent extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Card} */
    this.f_card__org_dominokit_samples_settings_SettingsComponent_;
  }
  
  /**
   * @return {!SettingsComponent}
   * @public
   */
  static $create__() {
    SettingsComponent.$clinit();
    let $instance = new SettingsComponent();
    $instance.$ctor__org_dominokit_samples_settings_SettingsComponent__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_settings_SettingsComponent__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_samples_settings_SettingsComponent();
    this.f_card__org_dominokit_samples_settings_SettingsComponent_.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, Card> */ style) =>{
      style.m_setMarginBottom__java_lang_String("0px").m_setHeight__java_lang_String("100%");
    })));
    this.f_card__org_dominokit_samples_settings_SettingsComponent_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Themes"));
    this.f_card__org_dominokit_samples_settings_SettingsComponent_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(FlexLayout.m_create__().m_setWrap__org_dominokit_domino_ui_grid_flex_FlexWrap(FlexWrap.f_WRAP_TOP_TO_BOTTOM__org_dominokit_domino_ui_grid_flex_FlexWrap).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_RED__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_PINK__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_PURPLE__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_DEEP_PURPLE__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_INDIGO__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_LIGHT_BLUE__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_CYAN__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_TEAL__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_GREEN__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_LIGHT_GREEN__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_LIME__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_YELLOW__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_AMBER__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_ORANGE__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_DEEP_ORANGE__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_BROWN__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_GREY__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_BLUE_GREY__org_dominokit_domino_ui_style_ColorScheme)).m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(ColorScheme.f_BLACK__org_dominokit_domino_ui_style_ColorScheme))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(Elements.m_hr__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(BlockHeader.m_create__java_lang_String("Notifications")).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("Show notifications"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(SwitchButton.m_create__().m_setOnTitle__java_lang_String("On").m_setOffTitle__java_lang_String("Off").m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, SwitchButton> */ arg0) =>{
      arg0.m_pullRight__();
    })))), IsElement)));
  }
  
  /**
   * @param {ColorScheme} colorScheme
   * @return {FlexItem}
   * @public
   */
  m_makeThemeSelector__org_dominokit_domino_ui_style_ColorScheme_$p_org_dominokit_samples_settings_SettingsComponent(colorScheme) {
    return /**@type {FlexItem} */ ($Casts.$to(FlexItem.m_create__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["theme-selector", colorScheme.m_color__().m_getBackground__(), Styles.f_default_shadow__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_on__org_jboss_gwt_elemento_core_EventType__org_jboss_gwt_elemento_core_EventCallbackFn(EventType.f_click__org_jboss_gwt_elemento_core_EventType, ((/** MouseEvent */ event) =>{
      Theme.$create__org_dominokit_domino_ui_style_ColorScheme(colorScheme).m_apply__();
    }))), FlexItem));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_card__org_dominokit_samples_settings_SettingsComponent_.m_asElement__(), $Overlay));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_settings_SettingsComponent() {
    this.f_card__org_dominokit_samples_settings_SettingsComponent_ = Card.m_create__java_lang_String("Settings");
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SettingsComponent.$clinit = (() =>{
    });
    SettingsComponent.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SettingsComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SettingsComponent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Card = goog.module.get('org.dominokit.domino.ui.cards.Card$impl');
    SwitchButton = goog.module.get('org.dominokit.domino.ui.forms.SwitchButton$impl');
    FlexItem = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
    FlexLayout = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
    FlexWrap = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexWrap$impl');
    BlockHeader = goog.module.get('org.dominokit.domino.ui.header.BlockHeader$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Theme = goog.module.get('org.dominokit.domino.ui.themes.Theme$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(SettingsComponent, $Util.$makeClassName('org.dominokit.samples.settings.SettingsComponent'));




exports = SettingsComponent; 
//# sourceMappingURL=SettingsComponent.js.map