/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.AttachDialogComponent$CompleteHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CompleteHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onComplete__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {CompleteHandler}
   * @public
   */
  static $adapt(fn) {
    CompleteHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CompleteHandler.$clinit = (() =>{
    });
    CompleteHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CompleteHandler, $Util.$makeClassName('org.dominokit.samples.attachments.AttachDialogComponent$CompleteHandler'));


CompleteHandler.$markImplementor(/** @type {Function} */ (CompleteHandler));


exports = CompleteHandler; 
//# sourceMappingURL=AttachDialogComponent$CompleteHandler.js.map