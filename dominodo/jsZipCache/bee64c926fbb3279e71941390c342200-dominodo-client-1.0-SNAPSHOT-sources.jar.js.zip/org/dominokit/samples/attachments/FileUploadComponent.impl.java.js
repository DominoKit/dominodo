/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.FileUploadComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.attachments.FileUploadComponent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.File.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let FileItem = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem$impl');
let RemoveFileHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler$impl');
let FileUpload = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileUpload$impl');
let OnAddFileHandler = goog.forwardDeclare('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler$impl');
let HasTask = goog.forwardDeclare('org.dominokit.samples.tasks.HasTask$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, FileUploadComponent>}
  */
class FileUploadComponent extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {FileUpload} */
    this.f_fileUpload__org_dominokit_samples_attachments_FileUploadComponent_;
  }
  
  /**
   * @param {HasTask} hasTask
   * @return {!FileUploadComponent}
   * @public
   */
  static $create__org_dominokit_samples_tasks_HasTask(hasTask) {
    FileUploadComponent.$clinit();
    let $instance = new FileUploadComponent();
    $instance.$ctor__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_tasks_HasTask(hasTask);
    return $instance;
  }
  
  /**
   * @param {HasTask} hasTask
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_tasks_HasTask(hasTask) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_samples_attachments_FileUploadComponent();
    this.f_fileUpload__org_dominokit_samples_attachments_FileUploadComponent_.m_multipleFiles__().m_setThumbSpans__int__int__int__int__int(4, 4, 4, 12, 12).m_manualUpload__().m_accept__java_lang_String("*/*").m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_h__int(3).m_textContent__java_lang_String("Drop files here or click to upload."), IsElement))).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_em__().m_textContent__java_lang_String("(This is just a demo upload. Selected files are not actually uploaded)"), IsElement))).m_onAddFile__org_dominokit_domino_ui_upload_FileUpload_OnAddFileHandler(OnAddFileHandler.$adapt(((/** FileItem */ fileItem) =>{
      window.console.info("adding attachement");
      hasTask.m_getTask__().m_getAttachments__().add(fileItem.m_getFile__().name);
      fileItem.m_addRemoveHandler__org_dominokit_domino_ui_upload_FileItem_RemoveFileHandler(RemoveFileHandler.$adapt(((/** File */ file) =>{
        hasTask.m_getTask__().m_getAttachments__().remove(file.name);
      })));
    })));
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {HasTask} hasTask
   * @return {FileUploadComponent}
   * @public
   */
  static m_create__org_dominokit_samples_tasks_HasTask(hasTask) {
    FileUploadComponent.$clinit();
    return FileUploadComponent.$create__org_dominokit_samples_tasks_HasTask(hasTask);
  }
  
  /**
   * @return {FileUpload}
   * @public
   */
  m_getFileUpload__() {
    return this.f_fileUpload__org_dominokit_samples_attachments_FileUploadComponent_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_fileUpload__org_dominokit_samples_attachments_FileUploadComponent_.m_asElement__();
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_attachments_FileUploadComponent() {
    this.f_fileUpload__org_dominokit_samples_attachments_FileUploadComponent_ = FileUpload.m_create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    FileUploadComponent.$clinit = (() =>{
    });
    FileUploadComponent.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FileUploadComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FileUploadComponent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    RemoveFileHandler = goog.module.get('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler$impl');
    FileUpload = goog.module.get('org.dominokit.domino.ui.upload.FileUpload$impl');
    OnAddFileHandler = goog.module.get('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(FileUploadComponent, $Util.$makeClassName('org.dominokit.samples.attachments.FileUploadComponent'));




exports = FileUploadComponent; 
//# sourceMappingURL=FileUploadComponent.js.map