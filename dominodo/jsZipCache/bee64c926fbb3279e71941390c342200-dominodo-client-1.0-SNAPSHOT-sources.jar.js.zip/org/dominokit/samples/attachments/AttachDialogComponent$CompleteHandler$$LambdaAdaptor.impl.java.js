/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.AttachDialogComponent$CompleteHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CompleteHandler = goog.require('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler$impl');


/**
 * @implements {CompleteHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function():void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():void} */
    this.f_$$fn__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler_$LambdaAdaptor__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler_$JsFunction(fn);
  }
  
  /**
   * @param {?function():void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler_$LambdaAdaptor__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onComplete__() {
    {
      let $function = this.f_$$fn__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler_$LambdaAdaptor;
      $function();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.samples.attachments.AttachDialogComponent$CompleteHandler$$LambdaAdaptor'));


CompleteHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=AttachDialogComponent$CompleteHandler$$LambdaAdaptor.js.map