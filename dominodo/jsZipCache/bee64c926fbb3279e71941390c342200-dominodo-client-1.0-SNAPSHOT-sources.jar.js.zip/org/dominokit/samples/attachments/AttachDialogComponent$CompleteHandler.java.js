/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.AttachDialogComponent$CompleteHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler.$LambdaAdaptor');


// Re-exports the implementation.
var CompleteHandler = goog.require('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler$impl');
exports = CompleteHandler;
 