/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.AttachDialogComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.attachments.AttachDialogComponent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseModal = goog.require('org.dominokit.domino.ui.modals.BaseModal$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ModalSize = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.samples.attachments.AttachDialogComponent.$LambdaAdaptor$4$impl');
let CompleteHandler = goog.forwardDeclare('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler$impl');
let FileUploadComponent = goog.forwardDeclare('org.dominokit.samples.attachments.FileUploadComponent$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseModal<AttachDialogComponent>}
  */
class AttachDialogComponent extends BaseModal {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @param {FileUploadComponent} fileUploadComponent
   * @param {CompleteHandler} onCompleteHandler
   * @return {!AttachDialogComponent}
   * @public
   */
  static $create__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler(fileUploadComponent, onCompleteHandler) {
    AttachDialogComponent.$clinit();
    let $instance = new AttachDialogComponent();
    $instance.$ctor__org_dominokit_samples_attachments_AttachDialogComponent__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler(fileUploadComponent, onCompleteHandler);
    return $instance;
  }
  
  /**
   * @param {FileUploadComponent} fileUploadComponent
   * @param {CompleteHandler} onCompleteHandler
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_attachments_AttachDialogComponent__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler(fileUploadComponent, onCompleteHandler) {
    this.$ctor__org_dominokit_domino_ui_modals_BaseModal__java_lang_String("Attach files");
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    this.m_setSize__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize(ModalSize.f_LARGE__org_dominokit_domino_ui_modals_IsModalDialog_ModalSize);
    this.f_style__org_dominokit_domino_ui_utils_BaseDominoElement.m_add__java_lang_String("task-modal");
    this.m_appendChild__org_jboss_gwt_elemento_core_IsElement(fileUploadComponent);
    this.m_appendFooterChild__org_jboss_gwt_elemento_core_IsElement(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_clear__()).m_linkify__(), Button)).m_setContent__java_lang_String("CLOSE"), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style) =>{
      style.m_setMinWidth__java_lang_String("120px");
    }))), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt) =>{
      if (Objects.m_nonNull__java_lang_Object(onCompleteHandler)) {
        onCompleteHandler.m_onComplete__();
      }
      this.m_close__();
    }))));
  }
  
  /**
   * @param {FileUploadComponent} fileUploadComponent
   * @param {CompleteHandler} onCompletehandler
   * @return {AttachDialogComponent}
   * @public
   */
  static m_create__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler(fileUploadComponent, onCompletehandler) {
    AttachDialogComponent.$clinit();
    return AttachDialogComponent.$create__org_dominokit_samples_attachments_FileUploadComponent__org_dominokit_samples_attachments_AttachDialogComponent_CompleteHandler(fileUploadComponent, onCompletehandler);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AttachDialogComponent.$clinit = (() =>{
    });
    AttachDialogComponent.$loadModules();
    BaseModal.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AttachDialogComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AttachDialogComponent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Objects = goog.module.get('java.util.Objects$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ModalSize = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.samples.attachments.AttachDialogComponent.$LambdaAdaptor$4$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(AttachDialogComponent, $Util.$makeClassName('org.dominokit.samples.attachments.AttachDialogComponent'));




exports = AttachDialogComponent; 
//# sourceMappingURL=AttachDialogComponent.js.map