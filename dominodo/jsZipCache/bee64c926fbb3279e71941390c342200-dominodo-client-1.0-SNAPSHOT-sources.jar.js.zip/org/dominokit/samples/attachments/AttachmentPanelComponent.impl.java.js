/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.AttachmentPanelComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.attachments.AttachmentPanelComponent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Badge = goog.forwardDeclare('org.dominokit.domino.ui.badges.Badge$impl');
let Chip = goog.forwardDeclare('org.dominokit.domino.ui.chips.Chip$impl');
let FlexItem = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
let FlexLayout = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let RemoveHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.samples.attachments.AttachmentPanelComponent.$LambdaAdaptor$5$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, AttachmentPanelComponent>}
  */
class AttachmentPanelComponent extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {FlexItem} */
    this.f_attachmentsItemsFlexItem__org_dominokit_samples_attachments_AttachmentPanelComponent_;
    /** @public {Task} */
    this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_;
    /** @public {Badge} */
    this.f_badge__org_dominokit_samples_attachments_AttachmentPanelComponent_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_samples_attachments_AttachmentPanelComponent_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_listContainer__org_dominokit_samples_attachments_AttachmentPanelComponent_;
    /** @public {Icon} */
    this.f_attachmentsCountIcon__org_dominokit_samples_attachments_AttachmentPanelComponent_;
    /** @public {ColorScheme} */
    this.f_projectColor__org_dominokit_samples_attachments_AttachmentPanelComponent_;
  }
  
  /**
   * @param {Task} task
   * @return {AttachmentPanelComponent}
   * @public
   */
  static m_create__org_dominokit_samples_Task(task) {
    AttachmentPanelComponent.$clinit();
    return AttachmentPanelComponent.$create__org_dominokit_samples_Task(task);
  }
  
  /**
   * @param {Task} task
   * @return {!AttachmentPanelComponent}
   * @public
   */
  static $create__org_dominokit_samples_Task(task) {
    AttachmentPanelComponent.$clinit();
    let $instance = new AttachmentPanelComponent();
    $instance.$ctor__org_dominokit_samples_attachments_AttachmentPanelComponent__org_dominokit_samples_Task(task);
    return $instance;
  }
  
  /**
   * @param {Task} task
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_attachments_AttachmentPanelComponent__org_dominokit_samples_Task(task) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_samples_attachments_AttachmentPanelComponent();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_ = task;
    this.f_projectColor__org_dominokit_samples_attachments_AttachmentPanelComponent_ = ColorScheme.m_valueOf__java_lang_String(task.m_getProject__().m_getColor__());
    this.f_attachmentsCountIcon__org_dominokit_samples_attachments_AttachmentPanelComponent_ = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_arrow_drop_down__().m_setToggleIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_arrow_drop_up__()), Icon)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Icon> */ style) =>{
      style.m_pullRight__().m_setLineHeight__java_lang_String("10px");
    }))), Icon)).m_collapse__(), Icon));
    this.f_badge__org_dominokit_samples_attachments_AttachmentPanelComponent_ = Badge.m_create__java_lang_String("0 Files");
    this.f_attachmentsItemsFlexItem__org_dominokit_samples_attachments_AttachmentPanelComponent_ = FlexItem.m_create__();
    /**@type {AttachmentPanelComponent} */ ($Casts.$to(this.m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLHeadingElement>} */ ($Casts.$to(Elements.m_h__int(5).m_textContent__java_lang_String("ATTACHMENTS"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {Badge} */ ($Casts.$to(/**@type {Badge} */ ($Casts.$to(this.f_badge__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$5(((/** Event */ evt) =>{
      if (task.m_getAttachments__().size() > 0) {
        this.f_listContainer__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_toggleDisplay__();
        this.f_attachmentsCountIcon__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_toggleIcon__();
      }
    }))), Badge)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Badge> */ style$1$) =>{
      style$1$.m_pullRight__().m_setCursor__java_lang_String("pointer");
    }))), Badge)).m_setBackground__org_dominokit_domino_ui_style_Color(this.f_projectColor__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_color__()).m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_attachmentsCountIcon__org_dominokit_samples_attachments_AttachmentPanelComponent_)), IsElement))), AttachmentPanelComponent)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(/**@type {DominoElement<HTMLDivElement>} */ ($Casts.$to(this.f_listContainer__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, DominoElement<HTMLDivElement>> */ style$2$) =>{
      style$2$.m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["attachments-panel", this.f_projectColor__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_lighten_5__().m_getBackground__()], j_l_String)));
    }))), DominoElement)).m_collapse__(), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(FlexLayout.m_create__().m_appendChild__org_dominokit_domino_ui_grid_flex_FlexItem(this.f_attachmentsItemsFlexItem__org_dominokit_samples_attachments_AttachmentPanelComponent_)));
    this.m_update__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_update__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__())) {
      this.f_attachmentsItemsFlexItem__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_clearElement__();
      this.f_attachmentsCountIcon__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_toggleDisplay__boolean(this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__().size() > 0);
      this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ?string */ attachment) =>{
        this.f_attachmentsItemsFlexItem__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(Chip.m_create__java_lang_String(attachment).m_setRemovable__boolean(true).m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE_GREY__org_dominokit_domino_ui_style_Color).m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_file_download__()).m_addRemoveHandler__org_dominokit_domino_ui_utils_HasRemoveHandler_RemoveHandler(RemoveHandler.$adapt((() =>{
          this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__().remove(attachment);
          this.f_badge__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_setText__java_lang_String(this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__().size() + " Files");
          this.f_attachmentsCountIcon__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_toggleDisplay__boolean(this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__().size() > 0);
          this.f_listContainer__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_toggleDisplay__boolean(this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__().size() > 0);
        }))));
      })));
      this.f_badge__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_setText__java_lang_String(this.f_task__org_dominokit_samples_attachments_AttachmentPanelComponent_.m_getAttachments__().size() + " Files");
    }
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_samples_attachments_AttachmentPanelComponent_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_attachments_AttachmentPanelComponent() {
    this.f_element__org_dominokit_samples_attachments_AttachmentPanelComponent_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_listContainer__org_dominokit_samples_attachments_AttachmentPanelComponent_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__()));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AttachmentPanelComponent.$clinit = (() =>{
    });
    AttachmentPanelComponent.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AttachmentPanelComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AttachmentPanelComponent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Badge = goog.module.get('org.dominokit.domino.ui.badges.Badge$impl');
    Chip = goog.module.get('org.dominokit.domino.ui.chips.Chip$impl');
    FlexItem = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
    FlexLayout = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    RemoveHandler = goog.module.get('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.samples.attachments.AttachmentPanelComponent.$LambdaAdaptor$5$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(AttachmentPanelComponent, $Util.$makeClassName('org.dominokit.samples.attachments.AttachmentPanelComponent'));




exports = AttachmentPanelComponent; 
//# sourceMappingURL=AttachmentPanelComponent.js.map