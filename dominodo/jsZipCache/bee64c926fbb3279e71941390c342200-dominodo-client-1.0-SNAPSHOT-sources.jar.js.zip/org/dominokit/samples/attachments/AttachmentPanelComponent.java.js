/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.AttachmentPanelComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.attachments.AttachmentPanelComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _Badge = goog.require('org.dominokit.domino.ui.badges.Badge');
const _Chip = goog.require('org.dominokit.domino.ui.chips.Chip');
const _FlexItem = goog.require('org.dominokit.domino.ui.grid.flex.FlexItem');
const _FlexLayout = goog.require('org.dominokit.domino.ui.grid.flex.FlexLayout');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _RemoveHandler = goog.require('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler');
const _Task = goog.require('org.dominokit.samples.Task');
const _$LambdaAdaptor$5 = goog.require('org.dominokit.samples.attachments.AttachmentPanelComponent.$LambdaAdaptor$5');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AttachmentPanelComponent = goog.require('org.dominokit.samples.attachments.AttachmentPanelComponent$impl');
exports = AttachmentPanelComponent;
 