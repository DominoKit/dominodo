/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.FileUploadComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.attachments.FileUploadComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.File.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _FileItem = goog.require('org.dominokit.domino.ui.upload.FileItem');
const _RemoveFileHandler = goog.require('org.dominokit.domino.ui.upload.FileItem.RemoveFileHandler');
const _FileUpload = goog.require('org.dominokit.domino.ui.upload.FileUpload');
const _OnAddFileHandler = goog.require('org.dominokit.domino.ui.upload.FileUpload.OnAddFileHandler');
const _HasTask = goog.require('org.dominokit.samples.tasks.HasTask');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var FileUploadComponent = goog.require('org.dominokit.samples.attachments.FileUploadComponent$impl');
exports = FileUploadComponent;
 