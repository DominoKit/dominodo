/**
 * @fileoverview transpiled from org.dominokit.samples.attachments.AttachDialogComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.attachments.AttachDialogComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseModal = goog.require('org.dominokit.domino.ui.modals.BaseModal');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ModalSize = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.ModalSize');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.samples.attachments.AttachDialogComponent.$LambdaAdaptor$4');
const _CompleteHandler = goog.require('org.dominokit.samples.attachments.AttachDialogComponent.CompleteHandler');
const _FileUploadComponent = goog.require('org.dominokit.samples.attachments.FileUploadComponent');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AttachDialogComponent = goog.require('org.dominokit.samples.attachments.AttachDialogComponent$impl');
exports = AttachDialogComponent;
 