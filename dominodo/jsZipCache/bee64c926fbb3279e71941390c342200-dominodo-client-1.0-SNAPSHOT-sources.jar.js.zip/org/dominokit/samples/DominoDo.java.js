/**
 * @fileoverview transpiled from org.dominokit.samples.DominoDo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.DominoDo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasMenuUiHandlers = goog.require('org.dominokit.samples.HasMenuUiHandlers');
const _HasTaskUiHandlers = goog.require('org.dominokit.samples.HasTaskUiHandlers');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Consumer = goog.require('java.util.function.Consumer');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Layout = goog.require('org.dominokit.domino.ui.layout.Layout');
const _NavigationBar = goog.require('org.dominokit.domino.ui.layout.NavigationBar');
const _TopBarAction = goog.require('org.dominokit.domino.ui.layout.TopBarAction');
const _Search = goog.require('org.dominokit.domino.ui.search.Search');
const _SearchHandler = goog.require('org.dominokit.domino.ui.search.Search.SearchHandler');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.samples.DominoDo.$LambdaAdaptor$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.samples.DominoDo.$LambdaAdaptor$2');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.samples.DominoDo.$LambdaAdaptor$3');
const _HasTasks = goog.require('org.dominokit.samples.HasTasks');
const _Priority = goog.require('org.dominokit.samples.Priority');
const _Status = goog.require('org.dominokit.samples.Status');
const _Task = goog.require('org.dominokit.samples.Task');
const _MenuComponent = goog.require('org.dominokit.samples.menu.MenuComponent');
const _SettingsComponent = goog.require('org.dominokit.samples.settings.SettingsComponent');
const _EditTaskDialog = goog.require('org.dominokit.samples.tasks.EditTaskDialog');
const _TasksList = goog.require('org.dominokit.samples.tasks.TasksList');
const _TasksRepository = goog.require('org.dominokit.samples.tasks.TasksRepository');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var DominoDo = goog.require('org.dominokit.samples.DominoDo$impl');
exports = DominoDo;
 