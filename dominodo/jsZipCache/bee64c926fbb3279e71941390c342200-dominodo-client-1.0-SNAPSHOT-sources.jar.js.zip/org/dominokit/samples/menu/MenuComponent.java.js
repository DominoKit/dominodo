/**
 * @fileoverview transpiled from org.dominokit.samples.menu.MenuComponent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.menu.MenuComponent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Tree = goog.require('org.dominokit.domino.ui.tree.Tree');
const _TreeItem = goog.require('org.dominokit.domino.ui.tree.TreeItem');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _Constants = goog.require('org.dominokit.samples.Constants');
const _HasMenuUiHandlers = goog.require('org.dominokit.samples.HasMenuUiHandlers');
const _Priority = goog.require('org.dominokit.samples.Priority');
const _$LambdaAdaptor$10 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$10');
const _$LambdaAdaptor$11 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$11');
const _$LambdaAdaptor$12 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$12');
const _$LambdaAdaptor$13 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$13');
const _$LambdaAdaptor$14 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$14');
const _$LambdaAdaptor$15 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$15');
const _$LambdaAdaptor$6 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$6');
const _$LambdaAdaptor$7 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$7');
const _$LambdaAdaptor$8 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$8');
const _$LambdaAdaptor$9 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$9');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var MenuComponent = goog.require('org.dominokit.samples.menu.MenuComponent$impl');
exports = MenuComponent;
 