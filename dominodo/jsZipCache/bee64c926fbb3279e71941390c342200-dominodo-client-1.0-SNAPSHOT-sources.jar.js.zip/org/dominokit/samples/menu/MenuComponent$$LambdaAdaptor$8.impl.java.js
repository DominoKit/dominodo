/**
 * @fileoverview transpiled from org.dominokit.samples.menu.MenuComponent$$LambdaAdaptor$8.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$8$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$8 extends j_l_Object {
  /**
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$8.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_samples_menu_MenuComponent_$LambdaAdaptor$8;
    this.$ctor__org_dominokit_samples_menu_MenuComponent_$LambdaAdaptor$8__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_menu_MenuComponent_$LambdaAdaptor$8__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_samples_menu_MenuComponent_$LambdaAdaptor$8 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_samples_menu_MenuComponent_$LambdaAdaptor$8;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$8.$clinit = (() =>{
    });
    $LambdaAdaptor$8.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$8;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$8);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$8, $Util.$makeClassName('org.dominokit.samples.menu.MenuComponent$$LambdaAdaptor$8'));




exports = $LambdaAdaptor$8; 
//# sourceMappingURL=MenuComponent$$LambdaAdaptor$8.js.map