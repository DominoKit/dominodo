/**
 * @fileoverview transpiled from org.dominokit.samples.menu.MenuComponent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.menu.MenuComponent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Tree = goog.forwardDeclare('org.dominokit.domino.ui.tree.Tree$impl');
let TreeItem = goog.forwardDeclare('org.dominokit.domino.ui.tree.TreeItem$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let Constants = goog.forwardDeclare('org.dominokit.samples.Constants$impl');
let HasMenuUiHandlers = goog.forwardDeclare('org.dominokit.samples.HasMenuUiHandlers$impl');
let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$9$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, MenuComponent>}
  */
class MenuComponent extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Tree} */
    this.f_menu__org_dominokit_samples_menu_MenuComponent_;
  }
  
  /**
   * @param {HasMenuUiHandlers} menuUiHandlers
   * @return {MenuComponent}
   * @public
   */
  static m_create__org_dominokit_samples_HasMenuUiHandlers(menuUiHandlers) {
    MenuComponent.$clinit();
    return MenuComponent.$create__org_dominokit_samples_HasMenuUiHandlers(menuUiHandlers);
  }
  
  /**
   * @param {HasMenuUiHandlers} menuUiHandlers
   * @return {!MenuComponent}
   * @public
   */
  static $create__org_dominokit_samples_HasMenuUiHandlers(menuUiHandlers) {
    MenuComponent.$clinit();
    let $instance = new MenuComponent();
    $instance.$ctor__org_dominokit_samples_menu_MenuComponent__org_dominokit_samples_HasMenuUiHandlers(menuUiHandlers);
    return $instance;
  }
  
  /**
   * @param {HasMenuUiHandlers} menuUiHandlers
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_menu_MenuComponent__org_dominokit_samples_HasMenuUiHandlers(menuUiHandlers) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_samples_menu_MenuComponent();
    /**@type {Tree} */ ($Casts.$to(this.f_menu__org_dominokit_samples_menu_MenuComponent_.m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Tree */ element) =>{
      element.m_getRoot__().m_style__().m_add__java_lang_String("menu-flow");
    }))), Tree)).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("All Tasks", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_inbox__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$6(((/** Event */ evt) =>{
      menuUiHandlers.m_onAllSelected__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Today's tasks", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_event__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$7(((/** Event */ evt$1$) =>{
      menuUiHandlers.m_onTodaySelected__();
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Next week", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_date_range__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$8(((/** Event */ evt$2$) =>{
      menuUiHandlers.m_onNextWeekSelected__();
    })))).m_addSeparator__().m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Important", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_priority_high__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_RED__org_dominokit_domino_ui_style_Color)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$9(((/** Event */ evt$3$) =>{
      menuUiHandlers.m_onPrioritySelected__org_dominokit_samples_Priority(Priority.f_IMPORTANT__org_dominokit_samples_Priority);
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Normal", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_low_priority__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_TEAL__org_dominokit_domino_ui_style_Color)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$10(((/** Event */ evt$4$) =>{
      menuUiHandlers.m_onPrioritySelected__org_dominokit_samples_Priority(Priority.f_NORMAL__org_dominokit_samples_Priority);
    })))).m_addSeparator__().m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(Constants.f_GWT__org_dominokit_samples_Constants, Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_inbox__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_PINK__org_dominokit_domino_ui_style_Color)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$11(((/** Event */ evt$5$) =>{
      menuUiHandlers.m_onProjectSelected__java_lang_String(Constants.f_GWT__org_dominokit_samples_Constants);
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Domino UI", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_inbox__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$12(((/** Event */ evt$6$) =>{
      menuUiHandlers.m_onProjectSelected__java_lang_String(Constants.f_DOMINO_UI__org_dominokit_samples_Constants);
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Nalu project", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_inbox__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BLUE__org_dominokit_domino_ui_style_Color)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$13(((/** Event */ evt$7$) =>{
      menuUiHandlers.m_onProjectSelected__java_lang_String(Constants.f_NALU_MVP__org_dominokit_samples_Constants);
    })))).m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Movies", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_inbox__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_BROWN__org_dominokit_domino_ui_style_Color)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$14(((/** Event */ evt$8$) =>{
      menuUiHandlers.m_onProjectSelected__java_lang_String(Constants.f_MOVIES__org_dominokit_samples_Constants);
    })))).m_addSeparator__().m_appendChild__org_dominokit_domino_ui_tree_TreeItem(TreeItem.m_create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon("Resolved", Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_done_all__().m_setColor__org_dominokit_domino_ui_style_Color(Color.f_GREEN__org_dominokit_domino_ui_style_Color)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$15(((/** Event */ evt$9$) =>{
      menuUiHandlers.m_onListResolved__();
    }))));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_menu__org_dominokit_samples_menu_MenuComponent_.m_asElement__(), $Overlay));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_menu_MenuComponent() {
    this.f_menu__org_dominokit_samples_menu_MenuComponent_ = Tree.m_create__java_lang_String("Todo");
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    MenuComponent.$clinit = (() =>{
    });
    MenuComponent.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof MenuComponent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, MenuComponent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Tree = goog.module.get('org.dominokit.domino.ui.tree.Tree$impl');
    TreeItem = goog.module.get('org.dominokit.domino.ui.tree.TreeItem$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    Constants = goog.module.get('org.dominokit.samples.Constants$impl');
    Priority = goog.module.get('org.dominokit.samples.Priority$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$9$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(MenuComponent, $Util.$makeClassName('org.dominokit.samples.menu.MenuComponent'));




exports = MenuComponent; 
//# sourceMappingURL=MenuComponent.js.map