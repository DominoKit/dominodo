/**
 * @fileoverview transpiled from org.dominokit.samples.menu.MenuComponent$$LambdaAdaptor$15.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$15');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');


// Re-exports the implementation.
var $LambdaAdaptor$15 = goog.require('org.dominokit.samples.menu.MenuComponent.$LambdaAdaptor$15$impl');
exports = $LambdaAdaptor$15;
 