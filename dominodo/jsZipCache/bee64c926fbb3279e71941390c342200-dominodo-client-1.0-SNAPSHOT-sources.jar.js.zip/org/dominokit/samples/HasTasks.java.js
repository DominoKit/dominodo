/**
 * @fileoverview transpiled from org.dominokit.samples.HasTasks.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.samples.HasTasks');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.samples.HasTasks.$LambdaAdaptor');


// Re-exports the implementation.
var HasTasks = goog.require('org.dominokit.samples.HasTasks$impl');
exports = HasTasks;
 