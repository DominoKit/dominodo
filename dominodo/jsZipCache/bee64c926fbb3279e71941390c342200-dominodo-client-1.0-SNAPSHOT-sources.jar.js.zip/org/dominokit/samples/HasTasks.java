package org.dominokit.samples;

@FunctionalInterface
public interface HasTasks {
    void update(boolean animate);
}
