/**
 * @fileoverview transpiled from org.dominokit.samples.HasTasks.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.HasTasks$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.samples.HasTasks.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasTasks {
  /**
   * @abstract
   * @param {boolean} animate
   * @return {void}
   * @public
   */
  m_update__boolean(animate) {
  }
  
  /**
   * @param {?function(boolean):void} fn
   * @return {HasTasks}
   * @public
   */
  static $adapt(fn) {
    HasTasks.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasTasks.$clinit = (() =>{
    });
    HasTasks.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_samples_HasTasks = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_samples_HasTasks;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_samples_HasTasks;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.samples.HasTasks.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasTasks, $Util.$makeClassName('org.dominokit.samples.HasTasks'));


HasTasks.$markImplementor(/** @type {Function} */ (HasTasks));


exports = HasTasks; 
//# sourceMappingURL=HasTasks.js.map