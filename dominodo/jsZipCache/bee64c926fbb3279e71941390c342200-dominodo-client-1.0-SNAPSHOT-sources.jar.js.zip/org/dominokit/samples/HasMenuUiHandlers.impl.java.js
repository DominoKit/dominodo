/**
 * @fileoverview transpiled from org.dominokit.samples.HasMenuUiHandlers.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.HasMenuUiHandlers$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');


/**
 * @interface
 */
class HasMenuUiHandlers {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onAllSelected__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onTodaySelected__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onNextWeekSelected__() {
  }
  
  /**
   * @abstract
   * @param {Priority} priority
   * @return {void}
   * @public
   */
  m_onPrioritySelected__org_dominokit_samples_Priority(priority) {
  }
  
  /**
   * @abstract
   * @param {?string} projectName
   * @return {void}
   * @public
   */
  m_onProjectSelected__java_lang_String(projectName) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onListResolved__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasMenuUiHandlers.$clinit = (() =>{
    });
    HasMenuUiHandlers.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_samples_HasMenuUiHandlers = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_samples_HasMenuUiHandlers;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_samples_HasMenuUiHandlers;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(HasMenuUiHandlers, $Util.$makeClassName('org.dominokit.samples.HasMenuUiHandlers'));


HasMenuUiHandlers.$markImplementor(/** @type {Function} */ (HasMenuUiHandlers));


exports = HasMenuUiHandlers; 
//# sourceMappingURL=HasMenuUiHandlers.js.map