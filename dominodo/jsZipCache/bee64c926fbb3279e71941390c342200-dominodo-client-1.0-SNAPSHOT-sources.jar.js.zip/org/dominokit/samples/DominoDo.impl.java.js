/**
 * @fileoverview transpiled from org.dominokit.samples.DominoDo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.DominoDo$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasMenuUiHandlers = goog.require('org.dominokit.samples.HasMenuUiHandlers$impl');
const HasTaskUiHandlers = goog.require('org.dominokit.samples.HasTaskUiHandlers$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Layout = goog.forwardDeclare('org.dominokit.domino.ui.layout.Layout$impl');
let NavigationBar = goog.forwardDeclare('org.dominokit.domino.ui.layout.NavigationBar$impl');
let TopBarAction = goog.forwardDeclare('org.dominokit.domino.ui.layout.TopBarAction$impl');
let Search = goog.forwardDeclare('org.dominokit.domino.ui.search.Search$impl');
let SearchHandler = goog.forwardDeclare('org.dominokit.domino.ui.search.Search.SearchHandler$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.samples.DominoDo.$LambdaAdaptor$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.samples.DominoDo.$LambdaAdaptor$2$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.samples.DominoDo.$LambdaAdaptor$3$impl');
let HasTasks = goog.forwardDeclare('org.dominokit.samples.HasTasks$impl');
let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let Status = goog.forwardDeclare('org.dominokit.samples.Status$impl');
let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');
let MenuComponent = goog.forwardDeclare('org.dominokit.samples.menu.MenuComponent$impl');
let SettingsComponent = goog.forwardDeclare('org.dominokit.samples.settings.SettingsComponent$impl');
let EditTaskDialog = goog.forwardDeclare('org.dominokit.samples.tasks.EditTaskDialog$impl');
let TasksList = goog.forwardDeclare('org.dominokit.samples.tasks.TasksList$impl');
let TasksRepository = goog.forwardDeclare('org.dominokit.samples.tasks.TasksRepository$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {HasMenuUiHandlers}
 * @implements {HasTaskUiHandlers}
  */
class DominoDo extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {TasksRepository} */
    this.f_tasksRepository__org_dominokit_samples_DominoDo_;
    /** @public {Layout} */
    this.f_layout__org_dominokit_samples_DominoDo_;
    /** @public {HasTasks} */
    this.f_currentTaskView__org_dominokit_samples_DominoDo_;
  }
  
  /**
   * @return {!DominoDo}
   * @public
   */
  static $create__() {
    DominoDo.$clinit();
    let $instance = new DominoDo();
    $instance.$ctor__org_dominokit_samples_DominoDo__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_DominoDo__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_samples_DominoDo();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_run__() {
    let search = Search.m_create__().m_onSearch__org_dominokit_domino_ui_search_Search_SearchHandler(SearchHandler.$adapt(((/** ?string */ arg0) =>{
      this.m_onSearch__java_lang_String_$p_org_dominokit_samples_DominoDo(arg0);
    })));
    this.f_layout__org_dominokit_samples_DominoDo_ = Layout.m_create__java_lang_String("DominoDo");
    this.f_layout__org_dominokit_samples_DominoDo_.m_navigationBar__java_util_function_Consumer(Consumer.$adapt(((/** NavigationBar */ navigationBar) =>{
      navigationBar.m_insertBefore__org_dominokit_domino_ui_utils_BaseDominoElement__elemental2_dom_Node(search, this.f_layout__org_dominokit_samples_DominoDo_.m_getNavigationBar__().m_firstChild__());
    }))).m_leftPanel__java_util_function_Consumer(Consumer.$adapt(((/** DominoElement<HTMLElement> */ leftPanel) =>{
      leftPanel.m_appendChild__org_jboss_gwt_elemento_core_IsElement(MenuComponent.m_create__org_dominokit_samples_HasMenuUiHandlers(this));
    }))).m_rightPanel__java_util_function_Consumer(Consumer.$adapt(((/** DominoElement<HTMLElement> */ rightPanel) =>{
      rightPanel.m_appendChild__org_jboss_gwt_elemento_core_IsElement(SettingsComponent.$create__());
    }))).m_topBar__java_util_function_Consumer(Consumer.$adapt(((/** DominoElement<HTMLUListElement> */ topBar) =>{
      /**@type {DominoElement<HTMLUListElement>} */ ($Casts.$to(topBar.m_appendChild__org_jboss_gwt_elemento_core_IsElement(TopBarAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_settings__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$1(((/** Event */ evt) =>{
        this.f_layout__org_dominokit_samples_DominoDo_.m_showRightPanel__();
      })))), DominoElement)).m_appendChild__org_jboss_gwt_elemento_core_IsElement(TopBarAction.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_search__()).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$2(((/** Event */ evt$1$) =>{
        search.m_open__();
      }))));
    }))).m_autoFixLeftPanel__().m_setLogo__org_jboss_gwt_elemento_core_IsElement(Elements.m_img__java_lang_String("./todo.png")).m_show__org_dominokit_domino_ui_style_ColorScheme(ColorScheme.f_BLUE__org_dominokit_domino_ui_style_ColorScheme);
    let addButton = /**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_add__()).m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_THEME__org_dominokit_domino_ui_style_Color), Button)).m_setContent__java_lang_String("ADD TASK"), Button)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Button> */ style) =>{
      style.m_add__java_lang_String("add-button");
    }))), Button)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ evt$2$) =>{
      this.m_showAddDialog___$p_org_dominokit_samples_DominoDo();
    }))), Button));
    $Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body.appendChild(addButton.m_asElement__());
    this.m_listAllTasks___$p_org_dominokit_samples_DominoDo();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_listAllTasks___$p_org_dominokit_samples_DominoDo() {
    this.m_onAllSelected__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_showAddDialog___$p_org_dominokit_samples_DominoDo() {
    EditTaskDialog.m_create__java_lang_String("Add task").m_onSave__java_util_function_Consumer(Consumer.$adapt(((/** Task */ task) =>{
      this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_addTask__org_dominokit_samples_Task(task);
      this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(false);
    }))).m_getModalDialog__().m_open__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_onAllSelected__() {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_listAll__();
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers("All Tasks", tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_onListResolved__() {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_listResolved__();
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers("Resolved", tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_onTodaySelected__() {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_listTodayTasks__();
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers("Today's tasks", tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_onNextWeekSelected__() {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_listNextWeekTasks__();
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers("Next week tasks", tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @override
   * @param {Priority} priority
   * @return {void}
   * @public
   */
  m_onPrioritySelected__org_dominokit_samples_Priority(priority) {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_listByPriority__org_dominokit_samples_Priority(priority);
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers(j_l_String.m_valueOf__java_lang_Object(($Objects.m_equals__java_lang_Object__java_lang_Object(Priority.f_IMPORTANT__org_dominokit_samples_Priority, priority) ? "Important" : "Normal")) + " tasks", tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @override
   * @param {?string} projectName
   * @return {void}
   * @public
   */
  m_onProjectSelected__java_lang_String(projectName) {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_listByProjectName__java_lang_String(projectName);
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers(j_l_String.m_valueOf__java_lang_Object(projectName) + " tasks", tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @override
   * @param {?string} tag
   * @return {void}
   * @public
   */
  m_onTagSelected__java_lang_String(tag) {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_findByTag__java_lang_String(tag);
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers("Search tag -" + j_l_String.m_valueOf__java_lang_Object(tag), tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @param {?string} searchToken
   * @return {void}
   * @public
   */
  m_onSearch__java_lang_String_$p_org_dominokit_samples_DominoDo(searchToken) {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_ = HasTasks.$adapt(((/** boolean */ animate) =>{
      let tasks = this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_findTasks__java_lang_String(searchToken);
      this.f_layout__org_dominokit_samples_DominoDo_.m_setContent__org_jboss_gwt_elemento_core_IsElement(TasksList.m_create__java_lang_String__java_util_List__org_dominokit_samples_HasTaskUiHandlers("Search results", tasks, this).m_update__boolean(animate));
    }));
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(true);
  }
  
  /**
   * @override
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onTaskDelete__org_dominokit_samples_Task(task) {
    this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_removeTask__org_dominokit_samples_Task(task);
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(false);
  }
  
  /**
   * @override
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onResolved__org_dominokit_samples_Task(task) {
    task.m_setStatus__org_dominokit_samples_Status(Status.f_COMPLETED__org_dominokit_samples_Status);
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(false);
  }
  
  /**
   * @override
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onUnResolve__org_dominokit_samples_Task(task) {
    task.m_setStatus__org_dominokit_samples_Status(Status.f_ACTIVE__org_dominokit_samples_Status);
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(false);
  }
  
  /**
   * @override
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onEditTask__org_dominokit_samples_Task(task) {
    EditTaskDialog.m_create__java_lang_String__org_dominokit_samples_Task("Add task", task).m_onSave__java_util_function_Consumer(Consumer.$adapt(((/** Task */ updatedTask) =>{
      this.f_tasksRepository__org_dominokit_samples_DominoDo_.m_addTask__org_dominokit_samples_Task(updatedTask);
      this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(false);
    }))).m_getModalDialog__().m_open__();
  }
  
  /**
   * @override
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onTaskPriorityChange__org_dominokit_samples_Task(task) {
    this.f_currentTaskView__org_dominokit_samples_DominoDo_.m_update__boolean(false);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_samples_DominoDo() {
    this.f_tasksRepository__org_dominokit_samples_DominoDo_ = TasksRepository.$create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DominoDo.$clinit = (() =>{
    });
    DominoDo.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DominoDo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DominoDo);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Layout = goog.module.get('org.dominokit.domino.ui.layout.Layout$impl');
    TopBarAction = goog.module.get('org.dominokit.domino.ui.layout.TopBarAction$impl');
    Search = goog.module.get('org.dominokit.domino.ui.search.Search$impl');
    SearchHandler = goog.module.get('org.dominokit.domino.ui.search.Search.SearchHandler$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.samples.DominoDo.$LambdaAdaptor$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.samples.DominoDo.$LambdaAdaptor$2$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.samples.DominoDo.$LambdaAdaptor$3$impl');
    HasTasks = goog.module.get('org.dominokit.samples.HasTasks$impl');
    Priority = goog.module.get('org.dominokit.samples.Priority$impl');
    Status = goog.module.get('org.dominokit.samples.Status$impl');
    MenuComponent = goog.module.get('org.dominokit.samples.menu.MenuComponent$impl');
    SettingsComponent = goog.module.get('org.dominokit.samples.settings.SettingsComponent$impl');
    EditTaskDialog = goog.module.get('org.dominokit.samples.tasks.EditTaskDialog$impl');
    TasksList = goog.module.get('org.dominokit.samples.tasks.TasksList$impl');
    TasksRepository = goog.module.get('org.dominokit.samples.tasks.TasksRepository$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(DominoDo, $Util.$makeClassName('org.dominokit.samples.DominoDo'));


HasMenuUiHandlers.$markImplementor(DominoDo);
HasTaskUiHandlers.$markImplementor(DominoDo);


exports = DominoDo; 
//# sourceMappingURL=DominoDo.js.map