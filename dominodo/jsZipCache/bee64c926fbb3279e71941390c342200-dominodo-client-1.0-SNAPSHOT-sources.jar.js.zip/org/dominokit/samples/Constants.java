package org.dominokit.samples;

public class Constants {
    public static final String DOMINO_UI = "Domino UI";
    public static final String NALU_MVP = "Nalu MVP";
    public static final String GWT = "GWT";
    public static final String MOVIES = "Movies";
}
