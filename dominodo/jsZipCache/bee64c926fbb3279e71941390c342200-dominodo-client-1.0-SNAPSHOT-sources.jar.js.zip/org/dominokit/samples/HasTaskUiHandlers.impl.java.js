/**
 * @fileoverview transpiled from org.dominokit.samples.HasTaskUiHandlers.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.HasTaskUiHandlers$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Task = goog.forwardDeclare('org.dominokit.samples.Task$impl');


/**
 * @interface
 */
class HasTaskUiHandlers {
  /**
   * @abstract
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onTaskDelete__org_dominokit_samples_Task(task) {
  }
  
  /**
   * @abstract
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onTaskPriorityChange__org_dominokit_samples_Task(task) {
  }
  
  /**
   * @abstract
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onEditTask__org_dominokit_samples_Task(task) {
  }
  
  /**
   * @abstract
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onResolved__org_dominokit_samples_Task(task) {
  }
  
  /**
   * @abstract
   * @param {Task} task
   * @return {void}
   * @public
   */
  m_onUnResolve__org_dominokit_samples_Task(task) {
  }
  
  /**
   * @abstract
   * @param {?string} tag
   * @return {void}
   * @public
   */
  m_onTagSelected__java_lang_String(tag) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasTaskUiHandlers.$clinit = (() =>{
    });
    HasTaskUiHandlers.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_samples_HasTaskUiHandlers = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_samples_HasTaskUiHandlers;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_samples_HasTaskUiHandlers;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(HasTaskUiHandlers, $Util.$makeClassName('org.dominokit.samples.HasTaskUiHandlers'));


HasTaskUiHandlers.$markImplementor(/** @type {Function} */ (HasTaskUiHandlers));


exports = HasTaskUiHandlers; 
//# sourceMappingURL=HasTaskUiHandlers.js.map