/**
 * @fileoverview transpiled from org.dominokit.samples.Constants.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.Constants$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Constants extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!Constants}
   * @public
   */
  static $create__() {
    Constants.$clinit();
    let $instance = new Constants();
    $instance.$ctor__org_dominokit_samples_Constants__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_Constants__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Constants.$clinit = (() =>{
    });
    Constants.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Constants;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Constants);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(Constants, $Util.$makeClassName('org.dominokit.samples.Constants'));


/** @public {?string} @const */
Constants.f_DOMINO_UI__org_dominokit_samples_Constants = "Domino UI";


/** @public {?string} @const */
Constants.f_NALU_MVP__org_dominokit_samples_Constants = "Nalu MVP";


/** @public {?string} @const */
Constants.f_GWT__org_dominokit_samples_Constants = "GWT";


/** @public {?string} @const */
Constants.f_MOVIES__org_dominokit_samples_Constants = "Movies";




exports = Constants; 
//# sourceMappingURL=Constants.js.map