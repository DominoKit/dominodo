package org.dominokit.domino.ui.datepicker;

import java.lang.Object;
import java.lang.Override;
import java.util.Date;
import javax.annotation.Generated;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.EditorVisitor;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class DateBox_SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  private DateBox editor;

  private Date object;

  @Override
  protected DateBox getEditor() {
    return editor;
  }

  @Override
  protected void setEditor(Editor editor) {
    this.editor = (DateBox) editor;
  }

  @Override
  public Date getObject() {
    return object;
  }

  @Override
  protected void setObject(Object object) {
    this.object = (Date) object;
  }

  @Override
  protected void initializeSubDelegates() {
  }

  @Override
  public void accept(EditorVisitor visitor) {
  }
}
