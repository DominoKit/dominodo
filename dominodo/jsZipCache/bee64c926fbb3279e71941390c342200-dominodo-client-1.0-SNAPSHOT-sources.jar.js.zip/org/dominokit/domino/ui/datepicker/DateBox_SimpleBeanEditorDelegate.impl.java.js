/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DateBox_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DateBox_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class DateBox__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DateBox} */
    this.f_editor__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate_;
    /** @public {Date} */
    this.f_object__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!DateBox__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    DateBox__SimpleBeanEditorDelegate.$clinit();
    let $instance = new DateBox__SimpleBeanEditorDelegate();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {DateBox}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate_ = /**@type {DateBox} */ ($Casts.$to(editor, DateBox));
  }
  
  /**
   * @override
   * @return {Date}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_dominokit_domino_ui_datepicker_DateBox_SimpleBeanEditorDelegate_ = /**@type {Date} */ ($Casts.$to(object, Date));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateBox__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    DateBox__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateBox__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateBox__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Date = goog.module.get('java.util.Date$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(DateBox__SimpleBeanEditorDelegate, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DateBox_SimpleBeanEditorDelegate'));




exports = DateBox__SimpleBeanEditorDelegate; 
//# sourceMappingURL=DateBox_SimpleBeanEditorDelegate.js.map