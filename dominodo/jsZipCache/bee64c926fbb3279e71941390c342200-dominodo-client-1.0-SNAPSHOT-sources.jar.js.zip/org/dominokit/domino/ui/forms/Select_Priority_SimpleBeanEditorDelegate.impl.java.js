/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select_Priority_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.Select_Priority_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let Priority = goog.forwardDeclare('org.dominokit.samples.Priority$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Select__Priority__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Select} */
    this.f_editor__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate_;
    /** @public {Priority} */
    this.f_object__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!Select__Priority__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    Select__Priority__SimpleBeanEditorDelegate.$clinit();
    let $instance = new Select__Priority__SimpleBeanEditorDelegate();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate_ = /**@type {Select} */ ($Casts.$to(editor, Select));
  }
  
  /**
   * @override
   * @return {Priority}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_dominokit_domino_ui_forms_Select_Priority_SimpleBeanEditorDelegate_ = /**@type {Priority} */ ($Casts.$to(object, Priority));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Select__Priority__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    Select__Priority__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Select__Priority__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Select__Priority__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    Priority = goog.module.get('org.dominokit.samples.Priority$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Select__Priority__SimpleBeanEditorDelegate, $Util.$makeClassName('org.dominokit.domino.ui.forms.Select_Priority_SimpleBeanEditorDelegate'));




exports = Select__Priority__SimpleBeanEditorDelegate; 
//# sourceMappingURL=Select_Priority_SimpleBeanEditorDelegate.js.map