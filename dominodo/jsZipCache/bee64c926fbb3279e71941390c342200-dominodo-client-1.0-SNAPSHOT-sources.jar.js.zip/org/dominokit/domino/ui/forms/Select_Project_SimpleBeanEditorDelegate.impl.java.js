/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.Select_Project_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.Select_Project_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let Project = goog.forwardDeclare('org.dominokit.samples.Project$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Select__Project__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Select} */
    this.f_editor__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate_;
    /** @public {Project} */
    this.f_object__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!Select__Project__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    Select__Project__SimpleBeanEditorDelegate.$clinit();
    let $instance = new Select__Project__SimpleBeanEditorDelegate();
    $instance.$ctor__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {Select}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate_ = /**@type {Select} */ ($Casts.$to(editor, Select));
  }
  
  /**
   * @override
   * @return {Project}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_dominokit_domino_ui_forms_Select_Project_SimpleBeanEditorDelegate_ = /**@type {Project} */ ($Casts.$to(object, Project));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Select__Project__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    Select__Project__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Select__Project__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Select__Project__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    Project = goog.module.get('org.dominokit.samples.Project$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Select__Project__SimpleBeanEditorDelegate, $Util.$makeClassName('org.dominokit.domino.ui.forms.Select_Project_SimpleBeanEditorDelegate'));




exports = Select__Project__SimpleBeanEditorDelegate; 
//# sourceMappingURL=Select_Project_SimpleBeanEditorDelegate.js.map