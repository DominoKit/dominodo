package org.dominokit.domino.ui.forms;

import java.lang.Object;
import java.lang.Override;
import javax.annotation.Generated;
import org.dominokit.samples.Project;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.EditorVisitor;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class Select_Project_SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  private Select editor;

  private Project object;

  @Override
  protected Select getEditor() {
    return editor;
  }

  @Override
  protected void setEditor(Editor editor) {
    this.editor = (Select) editor;
  }

  @Override
  public Project getObject() {
    return object;
  }

  @Override
  protected void setObject(Object object) {
    this.object = (Project) object;
  }

  @Override
  protected void initializeSubDelegates() {
  }

  @Override
  public void accept(EditorVisitor visitor) {
  }
}
