/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.TextBox_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.TextBox_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class TextBox__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {TextBox} */
    this.f_editor__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate_;
    /** @public {?string} */
    this.f_object__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!TextBox__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    TextBox__SimpleBeanEditorDelegate.$clinit();
    let $instance = new TextBox__SimpleBeanEditorDelegate();
    $instance.$ctor__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {TextBox}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate_ = /**@type {TextBox} */ ($Casts.$to(editor, TextBox));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_dominokit_domino_ui_forms_TextBox_SimpleBeanEditorDelegate_ = /**@type {?string} */ ($Casts.$to(object, j_l_String));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TextBox__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    TextBox__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TextBox__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TextBox__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TextBox__SimpleBeanEditorDelegate, $Util.$makeClassName('org.dominokit.domino.ui.forms.TextBox_SimpleBeanEditorDelegate'));




exports = TextBox__SimpleBeanEditorDelegate; 
//# sourceMappingURL=TextBox_SimpleBeanEditorDelegate.js.map