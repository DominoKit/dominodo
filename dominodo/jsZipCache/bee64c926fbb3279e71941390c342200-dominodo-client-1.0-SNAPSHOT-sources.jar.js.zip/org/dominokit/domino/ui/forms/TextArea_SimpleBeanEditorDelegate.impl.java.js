/**
 * @fileoverview transpiled from org.dominokit.domino.ui.forms.TextArea_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.forms.TextArea_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let TextArea = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextArea$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class TextArea__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {TextArea} */
    this.f_editor__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate_;
    /** @public {?string} */
    this.f_object__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!TextArea__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    TextArea__SimpleBeanEditorDelegate.$clinit();
    let $instance = new TextArea__SimpleBeanEditorDelegate();
    $instance.$ctor__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {TextArea}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate_ = /**@type {TextArea} */ ($Casts.$to(editor, TextArea));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_dominokit_domino_ui_forms_TextArea_SimpleBeanEditorDelegate_ = /**@type {?string} */ ($Casts.$to(object, j_l_String));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TextArea__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    TextArea__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TextArea__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TextArea__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    TextArea = goog.module.get('org.dominokit.domino.ui.forms.TextArea$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TextArea__SimpleBeanEditorDelegate, $Util.$makeClassName('org.dominokit.domino.ui.forms.TextArea_SimpleBeanEditorDelegate'));




exports = TextArea__SimpleBeanEditorDelegate; 
//# sourceMappingURL=TextArea_SimpleBeanEditorDelegate.js.map