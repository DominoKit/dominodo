package org.dominokit.domino.ui.forms;

import java.lang.Object;
import java.lang.Override;
import javax.annotation.Generated;
import org.dominokit.samples.Priority;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.EditorVisitor;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class Select_Priority_SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  private Select editor;

  private Priority object;

  @Override
  protected Select getEditor() {
    return editor;
  }

  @Override
  protected void setEditor(Editor editor) {
    this.editor = (Select) editor;
  }

  @Override
  public Priority getObject() {
    return object;
  }

  @Override
  protected void setObject(Object object) {
    this.object = (Priority) object;
  }

  @Override
  protected void initializeSubDelegates() {
  }

  @Override
  public void accept(EditorVisitor visitor) {
  }
}
