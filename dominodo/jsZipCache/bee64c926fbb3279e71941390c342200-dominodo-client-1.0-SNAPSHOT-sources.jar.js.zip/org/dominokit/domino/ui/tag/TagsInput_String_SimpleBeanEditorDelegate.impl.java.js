/**
 * @fileoverview transpiled from org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let TagsInput = goog.forwardDeclare('org.dominokit.domino.ui.tag.TagsInput$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class TagsInput__String__SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {TagsInput} */
    this.f_editor__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate_;
    /** @public {List<?string>} */
    this.f_object__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @return {!TagsInput__String__SimpleBeanEditorDelegate}
   * @public
   */
  static $create__() {
    TagsInput__String__SimpleBeanEditorDelegate.$clinit();
    let $instance = new TagsInput__String__SimpleBeanEditorDelegate();
    $instance.$ctor__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__();
  }
  
  /**
   * @override
   * @return {TagsInput}
   * @public
   */
  m_getEditor__() {
    return this.f_editor__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {Editor} editor
   * @return {void}
   * @public
   */
  m_setEditor__org_gwtproject_editor_client_Editor(editor) {
    this.f_editor__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate_ = /**@type {TagsInput} */ ($Casts.$to(editor, TagsInput));
  }
  
  /**
   * @override
   * @return {List<?string>}
   * @public
   */
  m_getObject__() {
    return this.f_object__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate_;
  }
  
  /**
   * @override
   * @param {*} object
   * @return {void}
   * @public
   */
  m_setObject__java_lang_Object(object) {
    this.f_object__org_dominokit_domino_ui_tag_TagsInput_String_SimpleBeanEditorDelegate_ = /**@type {List<?string>} */ ($Casts.$to(object, List));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_initializeSubDelegates__() {
  }
  
  /**
   * @override
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TagsInput__String__SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    TagsInput__String__SimpleBeanEditorDelegate.$loadModules();
    SimpleBeanEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TagsInput__String__SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TagsInput__String__SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    List = goog.module.get('java.util.List$impl');
    TagsInput = goog.module.get('org.dominokit.domino.ui.tag.TagsInput$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TagsInput__String__SimpleBeanEditorDelegate, $Util.$makeClassName('org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate'));




exports = TagsInput__String__SimpleBeanEditorDelegate; 
//# sourceMappingURL=TagsInput_String_SimpleBeanEditorDelegate.js.map