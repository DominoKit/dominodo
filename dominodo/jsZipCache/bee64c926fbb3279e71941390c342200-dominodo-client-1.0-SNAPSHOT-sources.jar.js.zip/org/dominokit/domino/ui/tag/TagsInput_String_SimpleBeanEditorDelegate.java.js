/**
 * @fileoverview transpiled from org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SimpleBeanEditorDelegate = goog.require('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate');
const _List = goog.require('java.util.List');
const _TagsInput = goog.require('org.dominokit.domino.ui.tag.TagsInput');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TagsInput__String__SimpleBeanEditorDelegate = goog.require('org.dominokit.domino.ui.tag.TagsInput_String_SimpleBeanEditorDelegate$impl');
exports = TagsInput__String__SimpleBeanEditorDelegate;
 