package org.dominokit.domino.ui.tag;

import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import javax.annotation.Generated;
import org.gwtproject.editor.client.Editor;
import org.gwtproject.editor.client.EditorVisitor;
import org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate;

@Generated("org.gwtproject.editor.processor.DriverProcessor")
public class TagsInput_String_SimpleBeanEditorDelegate extends SimpleBeanEditorDelegate {
  private TagsInput editor;

  private List<String> object;

  @Override
  protected TagsInput getEditor() {
    return editor;
  }

  @Override
  protected void setEditor(Editor editor) {
    this.editor = (TagsInput) editor;
  }

  @Override
  public List<String> getObject() {
    return object;
  }

  @Override
  protected void setObject(Object object) {
    this.object = (List<String>) object;
  }

  @Override
  protected void initializeSubDelegates() {
  }

  @Override
  public void accept(EditorVisitor visitor) {
  }
}
