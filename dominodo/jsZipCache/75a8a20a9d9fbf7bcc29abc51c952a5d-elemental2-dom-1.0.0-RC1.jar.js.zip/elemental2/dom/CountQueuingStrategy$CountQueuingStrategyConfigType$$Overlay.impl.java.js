/**
 * @fileoverview transpiled from elemental2.dom.CountQueuingStrategy$CountQueuingStrategyConfigType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.CountQueuingStrategy.CountQueuingStrategyConfigType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class CountQueuingStrategyConfigType_$Overlay {
  /**
   * @return {?}
   * @public
   */
  static m_create__() {
    CountQueuingStrategyConfigType_$Overlay.$clinit();
    return /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CountQueuingStrategyConfigType_$Overlay.$clinit = (() =>{
    });
    CountQueuingStrategyConfigType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};



exports = CountQueuingStrategyConfigType_$Overlay; 
//# sourceMappingURL=CountQueuingStrategy$CountQueuingStrategyConfigType$$Overlay.js.map