/**
 * @fileoverview transpiled from elemental2.dom.FetchEvent$RespondWithRUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.FetchEvent.RespondWithRUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Response_$Overlay = goog.forwardDeclare('elemental2.dom.Response.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.promise.IThenable.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class RespondWithRUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    RespondWithRUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), RespondWithRUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {IThenable<Response>}
   * @public
   */
  static m_asIThenable__elemental2_dom_FetchEvent_RespondWithRUnionType($thisArg) {
    RespondWithRUnionType_$Overlay.$clinit();
    return /**@type {IThenable<Response>} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Response}
   * @public
   */
  static m_asResponse__elemental2_dom_FetchEvent_RespondWithRUnionType($thisArg) {
    RespondWithRUnionType_$Overlay.$clinit();
    return /**@type {Response} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), Response_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isResponse__elemental2_dom_FetchEvent_RespondWithRUnionType($thisArg) {
    RespondWithRUnionType_$Overlay.$clinit();
    return Response_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RespondWithRUnionType_$Overlay.$clinit = (() =>{
    });
    RespondWithRUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Response_$Overlay = goog.module.get('elemental2.dom.Response.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.promise.IThenable.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = RespondWithRUnionType_$Overlay; 
//# sourceMappingURL=FetchEvent$RespondWithRUnionType$$Overlay.js.map