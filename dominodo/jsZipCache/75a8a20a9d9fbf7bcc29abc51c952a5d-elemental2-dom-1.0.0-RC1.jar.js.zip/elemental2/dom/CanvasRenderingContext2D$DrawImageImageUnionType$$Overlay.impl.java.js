/**
 * @fileoverview transpiled from elemental2.dom.CanvasRenderingContext2D$DrawImageImageUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.CanvasRenderingContext2D.DrawImageImageUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLCanvasElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let HTMLVideoElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLVideoElement.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class DrawImageImageUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    DrawImageImageUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), DrawImageImageUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {HTMLCanvasElement}
   * @public
   */
  static m_asHTMLCanvasElement__elemental2_dom_CanvasRenderingContext2D_DrawImageImageUnionType($thisArg) {
    DrawImageImageUnionType_$Overlay.$clinit();
    return /**@type {HTMLCanvasElement} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {HTMLImageElement}
   * @public
   */
  static m_asHTMLImageElement__elemental2_dom_CanvasRenderingContext2D_DrawImageImageUnionType($thisArg) {
    DrawImageImageUnionType_$Overlay.$clinit();
    return /**@type {HTMLImageElement} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), HTMLImageElement_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {HTMLVideoElement}
   * @public
   */
  static m_asHTMLVideoElement__elemental2_dom_CanvasRenderingContext2D_DrawImageImageUnionType($thisArg) {
    DrawImageImageUnionType_$Overlay.$clinit();
    return /**@type {HTMLVideoElement} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), HTMLVideoElement_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isHTMLCanvasElement__elemental2_dom_CanvasRenderingContext2D_DrawImageImageUnionType($thisArg) {
    DrawImageImageUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isHTMLImageElement__elemental2_dom_CanvasRenderingContext2D_DrawImageImageUnionType($thisArg) {
    DrawImageImageUnionType_$Overlay.$clinit();
    return HTMLImageElement_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isHTMLVideoElement__elemental2_dom_CanvasRenderingContext2D_DrawImageImageUnionType($thisArg) {
    DrawImageImageUnionType_$Overlay.$clinit();
    return HTMLVideoElement_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DrawImageImageUnionType_$Overlay.$clinit = (() =>{
    });
    DrawImageImageUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLCanvasElement.$Overlay$impl');
    HTMLImageElement_$Overlay = goog.module.get('elemental2.dom.HTMLImageElement.$Overlay$impl');
    HTMLVideoElement_$Overlay = goog.module.get('elemental2.dom.HTMLVideoElement.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = DrawImageImageUnionType_$Overlay; 
//# sourceMappingURL=CanvasRenderingContext2D$DrawImageImageUnionType$$Overlay.js.map