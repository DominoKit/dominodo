/**
 * @fileoverview transpiled from elemental2.dom.Event$ComposedPathArrayUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.Event.ComposedPathArrayUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Document.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _ShadowRoot_$Overlay = goog.require('elemental2.dom.ShadowRoot.$Overlay');
const _Window_$Overlay = goog.require('elemental2.dom.Window.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ComposedPathArrayUnionType_$Overlay = goog.require('elemental2.dom.Event.ComposedPathArrayUnionType.$Overlay$impl');
exports = ComposedPathArrayUnionType_$Overlay;
 