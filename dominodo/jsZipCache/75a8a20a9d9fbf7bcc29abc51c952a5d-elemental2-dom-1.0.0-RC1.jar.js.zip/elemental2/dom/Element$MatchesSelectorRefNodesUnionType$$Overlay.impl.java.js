/**
 * @fileoverview transpiled from elemental2.dom.Element$MatchesSelectorRefNodesUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Element.MatchesSelectorRefNodesUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let NodeList_$Overlay = goog.forwardDeclare('elemental2.dom.NodeList.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class MatchesSelectorRefNodesUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    MatchesSelectorRefNodesUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), MatchesSelectorRefNodesUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Node}
   * @public
   */
  static m_asNode__elemental2_dom_Element_MatchesSelectorRefNodesUnionType($thisArg) {
    MatchesSelectorRefNodesUnionType_$Overlay.$clinit();
    return /**@type {Node} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {NodeList<*>}
   * @public
   */
  static m_asNodeList__elemental2_dom_Element_MatchesSelectorRefNodesUnionType($thisArg) {
    MatchesSelectorRefNodesUnionType_$Overlay.$clinit();
    return /**@type {NodeList<*>} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), NodeList_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isNode__elemental2_dom_Element_MatchesSelectorRefNodesUnionType($thisArg) {
    MatchesSelectorRefNodesUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isNodeList__elemental2_dom_Element_MatchesSelectorRefNodesUnionType($thisArg) {
    MatchesSelectorRefNodesUnionType_$Overlay.$clinit();
    return NodeList_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    MatchesSelectorRefNodesUnionType_$Overlay.$clinit = (() =>{
    });
    MatchesSelectorRefNodesUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.Node.$Overlay$impl');
    NodeList_$Overlay = goog.module.get('elemental2.dom.NodeList.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = MatchesSelectorRefNodesUnionType_$Overlay; 
//# sourceMappingURL=Element$MatchesSelectorRefNodesUnionType$$Overlay.js.map