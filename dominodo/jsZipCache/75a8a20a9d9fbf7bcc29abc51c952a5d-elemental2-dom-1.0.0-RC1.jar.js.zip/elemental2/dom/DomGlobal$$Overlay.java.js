/**
 * @fileoverview transpiled from elemental2.dom.DomGlobal$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.DomGlobal.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay');
const _Transferable_$Overlay = goog.require('elemental2.core.Transferable.$Overlay');
const _Database_$Overlay = goog.require('elemental2.dom.Database.$Overlay');
const _DatabaseCallback_$Overlay = goog.require('elemental2.dom.DatabaseCallback.$Overlay');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.FetchInputUnionType.$Overlay');
const _OpenDatabaseCallbackUnionType_$Overlay = goog.require('elemental2.dom.DomGlobal.OpenDatabaseCallbackUnionType.$Overlay');
const _PostMessageTargetOriginOrPortsOrTransferUnionType_$Overlay = goog.require('elemental2.dom.DomGlobal.PostMessageTargetOriginOrPortsOrTransferUnionType.$Overlay');
const _PostMessageTargetOriginOrTransferUnionType_$Overlay = goog.require('elemental2.dom.DomGlobal.PostMessageTargetOriginOrTransferUnionType.$Overlay');
const _SetIntervalCallbackUnionType_$Overlay = goog.require('elemental2.dom.DomGlobal.SetIntervalCallbackUnionType.$Overlay');
const _SetTimeoutCallbackUnionType_$Overlay = goog.require('elemental2.dom.DomGlobal.SetTimeoutCallbackUnionType.$Overlay');
const _HTMLDocument_$Overlay = goog.require('elemental2.dom.HTMLDocument.$Overlay');
const _Location_$Overlay = goog.require('elemental2.dom.Location.$Overlay');
const _Navigator_$Overlay = goog.require('elemental2.dom.Navigator.$Overlay');
const _Request_$Overlay = goog.require('elemental2.dom.Request.$Overlay');
const _RequestInit_$Overlay = goog.require('elemental2.dom.RequestInit.$Overlay');
const _Response_$Overlay = goog.require('elemental2.dom.Response.$Overlay');
const _Screen_$Overlay = goog.require('elemental2.dom.Screen.$Overlay');
const _Window_$Overlay = goog.require('elemental2.dom.Window.$Overlay');
const _Promise_$Overlay = goog.require('elemental2.promise.Promise.$Overlay');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay$impl');
exports = DomGlobal_$Overlay;
 