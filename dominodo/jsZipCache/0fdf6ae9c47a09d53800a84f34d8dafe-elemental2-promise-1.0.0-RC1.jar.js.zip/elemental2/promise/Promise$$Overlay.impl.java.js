/**
 * @fileoverview transpiled from elemental2.promise.Promise$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.promise.Promise.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let IThenable_$Overlay = goog.forwardDeclare('elemental2.promise.IThenable.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.promise.Promise.ResolveValueUnionType.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class Promise_$Overlay {
  /**
   * @template M_V
   * @param {IThenable<M_V>} value
   * @return {Promise<M_V>}
   * @public
   */
  static m_resolve__elemental2_promise_IThenable(value) {
    Promise_$Overlay.$clinit();
    return /**@type {Promise<*>} */ (Promise.resolve(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value))));
  }
  
  /**
   * @template M_V
   * @param {M_V} value
   * @return {Promise<M_V>}
   * @public
   */
  static m_resolve__java_lang_Object(value) {
    Promise_$Overlay.$clinit();
    return /**@type {Promise<*>} */ (Promise.resolve(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value))));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Promise_$Overlay.$clinit = (() =>{
    });
    Promise_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Promise;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(Promise_$Overlay, $Util.$makeClassName('Promise'));


exports = Promise_$Overlay; 
//# sourceMappingURL=Promise$$Overlay.js.map