/**
 * @fileoverview transpiled from elemental2.promise.Promise$PromiseExecutorCallbackFn$ResolveCallbackFn$ResolveUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.promise.Promise.PromiseExecutorCallbackFn.ResolveCallbackFn.ResolveUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.promise.IThenable.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ResolveUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ResolveUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ResolveUnionType_$Overlay));
  }
  
  /**
   * @template C_PromiseExecutorCallbackFn_ResolveCallbackFn_ResolveUnionType_T
   * @param {?} $thisArg
   * @return {IThenable<C_PromiseExecutorCallbackFn_ResolveCallbackFn_ResolveUnionType_T>}
   * @public
   */
  static m_asIThenable__elemental2_promise_Promise_PromiseExecutorCallbackFn_ResolveCallbackFn_ResolveUnionType($thisArg) {
    ResolveUnionType_$Overlay.$clinit();
    return /**@type {IThenable<*>} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @template C_PromiseExecutorCallbackFn_ResolveCallbackFn_ResolveUnionType_T
   * @param {?} $thisArg
   * @return {C_PromiseExecutorCallbackFn_ResolveCallbackFn_ResolveUnionType_T}
   * @public
   */
  static m_asT__elemental2_promise_Promise_PromiseExecutorCallbackFn_ResolveCallbackFn_ResolveUnionType($thisArg) {
    ResolveUnionType_$Overlay.$clinit();
    return Js.m_cast__java_lang_Object($thisArg);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ResolveUnionType_$Overlay.$clinit = (() =>{
    });
    ResolveUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.promise.IThenable.$Overlay$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = ResolveUnionType_$Overlay; 
//# sourceMappingURL=Promise$PromiseExecutorCallbackFn$ResolveCallbackFn$ResolveUnionType$$Overlay.js.map