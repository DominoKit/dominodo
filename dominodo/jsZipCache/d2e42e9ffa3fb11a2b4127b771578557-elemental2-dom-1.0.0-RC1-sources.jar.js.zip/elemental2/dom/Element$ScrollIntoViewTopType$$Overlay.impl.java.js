/**
 * @fileoverview transpiled from elemental2.dom.Element$ScrollIntoViewTopType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Element.ScrollIntoViewTopType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class ScrollIntoViewTopType_$Overlay {
  /**
   * @return {?}
   * @public
   */
  static m_create__() {
    ScrollIntoViewTopType_$Overlay.$clinit();
    return /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ScrollIntoViewTopType_$Overlay.$clinit = (() =>{
    });
    ScrollIntoViewTopType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};



exports = ScrollIntoViewTopType_$Overlay; 
//# sourceMappingURL=Element$ScrollIntoViewTopType$$Overlay.js.map