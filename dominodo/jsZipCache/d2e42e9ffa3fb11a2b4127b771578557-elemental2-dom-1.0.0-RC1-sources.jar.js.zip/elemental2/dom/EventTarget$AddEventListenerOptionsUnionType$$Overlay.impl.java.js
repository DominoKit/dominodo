/**
 * @fileoverview transpiled from elemental2.dom.EventTarget$AddEventListenerOptionsUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.EventTarget.AddEventListenerOptionsUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.AddEventListenerOptions.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class AddEventListenerOptionsUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    AddEventListenerOptionsUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), AddEventListenerOptionsUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {AddEventListenerOptions}
   * @public
   */
  static m_asAddEventListenerOptions__elemental2_dom_EventTarget_AddEventListenerOptionsUnionType($thisArg) {
    AddEventListenerOptionsUnionType_$Overlay.$clinit();
    return /**@type {AddEventListenerOptions} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_asBoolean__elemental2_dom_EventTarget_AddEventListenerOptionsUnionType($thisArg) {
    AddEventListenerOptionsUnionType_$Overlay.$clinit();
    return Js.m_asBoolean__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isBoolean__elemental2_dom_EventTarget_AddEventListenerOptionsUnionType($thisArg) {
    AddEventListenerOptionsUnionType_$Overlay.$clinit();
    return Boolean.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AddEventListenerOptionsUnionType_$Overlay.$clinit = (() =>{
    });
    AddEventListenerOptionsUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.AddEventListenerOptions.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = AddEventListenerOptionsUnionType_$Overlay; 
//# sourceMappingURL=EventTarget$AddEventListenerOptionsUnionType$$Overlay.js.map