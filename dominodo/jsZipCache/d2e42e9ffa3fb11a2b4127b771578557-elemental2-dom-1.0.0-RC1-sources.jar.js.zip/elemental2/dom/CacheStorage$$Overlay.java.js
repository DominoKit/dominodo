/**
 * @fileoverview transpiled from elemental2.dom.CacheStorage$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.CacheStorage.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _CacheQueryOptions_$Overlay = goog.require('elemental2.dom.CacheQueryOptions.$Overlay');
const _$Overlay = goog.require('elemental2.dom.CacheStorage.MatchRequestUnionType.$Overlay');
const _Request_$Overlay = goog.require('elemental2.dom.Request.$Overlay');
const _Response_$Overlay = goog.require('elemental2.dom.Response.$Overlay');
const _Promise_$Overlay = goog.require('elemental2.promise.Promise.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var CacheStorage_$Overlay = goog.require('elemental2.dom.CacheStorage.$Overlay$impl');
exports = CacheStorage_$Overlay;
 