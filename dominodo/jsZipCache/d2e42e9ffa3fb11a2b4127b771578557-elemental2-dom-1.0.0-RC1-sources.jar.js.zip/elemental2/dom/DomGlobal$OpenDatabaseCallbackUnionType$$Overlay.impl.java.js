/**
 * @fileoverview transpiled from elemental2.dom.DomGlobal$OpenDatabaseCallbackUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.DomGlobal.OpenDatabaseCallbackUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Database_$Overlay = goog.forwardDeclare('elemental2.dom.Database.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.DatabaseCallback.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $JavaScriptFunction = goog.forwardDeclare('vmbootstrap.JavaScriptFunction$impl');


class OpenDatabaseCallbackUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    OpenDatabaseCallbackUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), OpenDatabaseCallbackUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {DatabaseCallback}
   * @public
   */
  static m_asDatabaseCallback__elemental2_dom_DomGlobal_OpenDatabaseCallbackUnionType($thisArg) {
    OpenDatabaseCallbackUnionType_$Overlay.$clinit();
    return /**@type {DatabaseCallback} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {?function(Database):*}
   * @public
   */
  static m_asOpenDatabaseCallbackFn__elemental2_dom_DomGlobal_OpenDatabaseCallbackUnionType($thisArg) {
    OpenDatabaseCallbackUnionType_$Overlay.$clinit();
    return /**@type {?function(Database):*} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $JavaScriptFunction));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isOpenDatabaseCallbackFn__elemental2_dom_DomGlobal_OpenDatabaseCallbackUnionType($thisArg) {
    OpenDatabaseCallbackUnionType_$Overlay.$clinit();
    return $JavaScriptFunction.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    OpenDatabaseCallbackUnionType_$Overlay.$clinit = (() =>{
    });
    OpenDatabaseCallbackUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.DatabaseCallback.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $JavaScriptFunction = goog.module.get('vmbootstrap.JavaScriptFunction$impl');
  }
  
  
};



exports = OpenDatabaseCallbackUnionType_$Overlay; 
//# sourceMappingURL=DomGlobal$OpenDatabaseCallbackUnionType$$Overlay.js.map