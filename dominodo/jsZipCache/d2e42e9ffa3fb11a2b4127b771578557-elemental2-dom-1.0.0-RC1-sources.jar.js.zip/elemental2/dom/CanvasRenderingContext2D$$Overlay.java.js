/**
 * @fileoverview transpiled from elemental2.dom.CanvasRenderingContext2D$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.CanvasRenderingContext2D.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _CanvasPattern_$Overlay = goog.require('elemental2.dom.CanvasPattern.$Overlay');
const _$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.ClipOptFillRuleOrPathUnionType.$Overlay');
const _CreatePatternImageUnionType_$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.CreatePatternImageUnionType.$Overlay');
const _DrawImageImageUnionType_$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.DrawImageImageUnionType.$Overlay');
const _FillOptFillRuleOrPathUnionType_$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.FillOptFillRuleOrPathUnionType.$Overlay');
const _SetFillColorP0UnionType_$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.SetFillColorP0UnionType.$Overlay');
const _SetStrokeColorP0UnionType_$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.SetStrokeColorP0UnionType.$Overlay');
const _HTMLCanvasElement_$Overlay = goog.require('elemental2.dom.HTMLCanvasElement.$Overlay');
const _HTMLImageElement_$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _HTMLVideoElement_$Overlay = goog.require('elemental2.dom.HTMLVideoElement.$Overlay');
const _Path2D_$Overlay = goog.require('elemental2.dom.Path2D.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var CanvasRenderingContext2D_$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.$Overlay$impl');
exports = CanvasRenderingContext2D_$Overlay;
 