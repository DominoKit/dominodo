/**
 * @fileoverview transpiled from elemental2.dom.CanvasRenderingContext2D$CreatePatternImageUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.CanvasRenderingContext2D.CreatePatternImageUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLCanvasElement.$Overlay');
const _HTMLImageElement_$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _HTMLVideoElement_$Overlay = goog.require('elemental2.dom.HTMLVideoElement.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var CreatePatternImageUnionType_$Overlay = goog.require('elemental2.dom.CanvasRenderingContext2D.CreatePatternImageUnionType.$Overlay$impl');
exports = CreatePatternImageUnionType_$Overlay;
 