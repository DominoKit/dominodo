/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$DateDayClickedHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Date = goog.require('java.util.Date');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler.$LambdaAdaptor');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');


// Re-exports the implementation.
var DateDayClickedHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
exports = DateDayClickedHandler;
 