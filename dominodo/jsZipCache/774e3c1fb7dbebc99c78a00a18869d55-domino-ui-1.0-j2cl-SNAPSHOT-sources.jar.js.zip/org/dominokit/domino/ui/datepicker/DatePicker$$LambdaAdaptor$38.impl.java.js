/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$$LambdaAdaptor$38.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$38$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$38 extends j_l_Object {
  /**
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$38.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$38;
    this.$ctor__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$38__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$38__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$38 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_$LambdaAdaptor$38;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$38.$clinit = (() =>{
    });
    $LambdaAdaptor$38.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$38;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$38);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$38, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker$$LambdaAdaptor$38'));




exports = $LambdaAdaptor$38; 
//# sourceMappingURL=DatePicker$$LambdaAdaptor$38.js.map