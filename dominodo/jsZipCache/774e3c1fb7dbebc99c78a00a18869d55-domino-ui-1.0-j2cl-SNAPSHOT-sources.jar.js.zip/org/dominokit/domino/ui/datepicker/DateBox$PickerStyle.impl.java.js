/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DateBox$PickerStyle.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<PickerStyle>}
  */
class PickerStyle extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!PickerStyle}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new PickerStyle();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!PickerStyle}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    PickerStyle.$clinit();
    if ($Equality.$same(PickerStyle.$f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_, null)) {
      PickerStyle.$f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_ = $Enums.createMapFromValues(PickerStyle.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, PickerStyle.$f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_);
  }
  
  /**
   * @return {!Array<!PickerStyle>}
   * @public
   */
  static m_values__() {
    PickerStyle.$clinit();
    return /**@type {!Array<PickerStyle>} */ ($Arrays.$init([PickerStyle.$f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle, PickerStyle.$f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle], PickerStyle));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {PickerStyle} */ ($Casts.$to(arg0, PickerStyle)));
  }
  
  /**
   * @return {!PickerStyle}
   * @public
   */
  static get f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle() {
    return (PickerStyle.$clinit(), PickerStyle.$f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle);
  }
  
  /**
   * @param {!PickerStyle} value
   * @return {void}
   * @public
   */
  static set f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle(value) {
    (PickerStyle.$clinit(), PickerStyle.$f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle = value);
  }
  
  /**
   * @return {!PickerStyle}
   * @public
   */
  static get f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle() {
    return (PickerStyle.$clinit(), PickerStyle.$f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle);
  }
  
  /**
   * @param {!PickerStyle} value
   * @return {void}
   * @public
   */
  static set f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle(value) {
    (PickerStyle.$clinit(), PickerStyle.$f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle = value);
  }
  
  /**
   * @return {Map<?string, !PickerStyle>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_() {
    return (PickerStyle.$clinit(), PickerStyle.$f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_);
  }
  
  /**
   * @param {Map<?string, !PickerStyle>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_(value) {
    (PickerStyle.$clinit(), PickerStyle.$f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    PickerStyle.$clinit = (() =>{
    });
    PickerStyle.$loadModules();
    Enum.$clinit();
    PickerStyle.$f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle = PickerStyle.$create__java_lang_String__int($Util.$makeEnumName("MODAL"), PickerStyle.$ordinal$f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle);
    PickerStyle.$f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle = PickerStyle.$create__java_lang_String__int($Util.$makeEnumName("POPOVER"), PickerStyle.$ordinal$f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle);
    PickerStyle.$f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof PickerStyle;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, PickerStyle);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(PickerStyle, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DateBox$PickerStyle'));


/** @private {!PickerStyle} */
PickerStyle.$f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle;


/** @private {!PickerStyle} */
PickerStyle.$f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle;


/** @private {Map<?string, !PickerStyle>} */
PickerStyle.$f_namesToValuesMap__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle_;


/** @public {number} @const */
PickerStyle.$ordinal$f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle = 0;


/** @public {number} @const */
PickerStyle.$ordinal$f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle = 1;




exports = PickerStyle; 
//# sourceMappingURL=DateBox$PickerStyle.js.map