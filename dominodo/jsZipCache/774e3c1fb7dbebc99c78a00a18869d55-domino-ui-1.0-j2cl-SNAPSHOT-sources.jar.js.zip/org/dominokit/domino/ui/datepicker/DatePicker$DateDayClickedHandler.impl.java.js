/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$DateDayClickedHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler.$LambdaAdaptor$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');


/**
 * @interface
 */
class DateDayClickedHandler {
  /**
   * @abstract
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {void}
   * @public
   */
  m_onDateDayClicked__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo) {
  }
  
  /**
   * @param {?function(Date, DateTimeFormatInfo):void} fn
   * @return {DateDayClickedHandler}
   * @public
   */
  static $adapt(fn) {
    DateDayClickedHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateDayClickedHandler.$clinit = (() =>{
    });
    DateDayClickedHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DateDayClickedHandler, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker$DateDayClickedHandler'));


DateDayClickedHandler.$markImplementor(/** @type {Function} */ (DateDayClickedHandler));


exports = DateDayClickedHandler; 
//# sourceMappingURL=DatePicker$DateDayClickedHandler.js.map