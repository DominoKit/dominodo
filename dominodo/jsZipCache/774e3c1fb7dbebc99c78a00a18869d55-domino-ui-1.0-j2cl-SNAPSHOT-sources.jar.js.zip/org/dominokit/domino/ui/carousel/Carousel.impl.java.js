/**
 * @fileoverview transpiled from org.dominokit.domino.ui.carousel.Carousel.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.carousel.Carousel$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLOListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLOListElement.$Overlay$impl');
let MutationRecord_$Overlay = goog.forwardDeclare('elemental2.dom.MutationRecord.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$1$impl');
let $LambdaAdaptor$10 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$10$impl');
let $LambdaAdaptor$11 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$11$impl');
let $LambdaAdaptor$12 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$12$impl');
let $LambdaAdaptor$13 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$13$impl');
let $LambdaAdaptor$14 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$14$impl');
let $LambdaAdaptor$15 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$15$impl');
let $LambdaAdaptor$6 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$6$impl');
let $LambdaAdaptor$7 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$7$impl');
let $LambdaAdaptor$8 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$8$impl');
let $LambdaAdaptor$9 = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$9$impl');
let Slide = goog.forwardDeclare('org.dominokit.domino.ui.carousel.Slide$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let SwipeUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.SwipeUtil$impl');
let SwipeDirection = goog.forwardDeclare('org.dominokit.domino.ui.utils.SwipeUtil.SwipeDirection$impl');
let Timer = goog.forwardDeclare('org.gwtproject.timer.client.Timer$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let ObserverCallback = goog.forwardDeclare('org.jboss.gwt.elemento.core.ObserverCallback$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, Carousel>}
  */
class Carousel extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLOListElement} */
    this.f_indicatorsElement__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {HTMLDivElement} */
    this.f_slidesElement__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {boolean} */
    this.f_autoSlide__org_dominokit_domino_ui_carousel_Carousel_ = false;
    /** @public {HTMLAnchorElement} */
    this.f_prevElement__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {HTMLAnchorElement} */
    this.f_nextElement__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {List<Slide>} */
    this.f_slides__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {Slide} */
    this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {Slide} */
    this.f_targetSlide__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {Timer} */
    this.f_timer__org_dominokit_domino_ui_carousel_Carousel_;
    /** @public {number} */
    this.f_autoSlideDuration__org_dominokit_domino_ui_carousel_Carousel_ = 0;
    /** @public {boolean} */
    this.f_attached__org_dominokit_domino_ui_carousel_Carousel_ = false;
  }
  
  /**
   * @return {!Carousel}
   * @public
   */
  static $create__() {
    Carousel.$clinit();
    let $instance = new Carousel();
    $instance.$ctor__org_dominokit_domino_ui_carousel_Carousel__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_carousel_Carousel__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_carousel_Carousel();
    this.f_nextElement__org_dominokit_domino_ui_carousel_Carousel_.addEventListener("click", new $LambdaAdaptor$6(((/** Event */ evt) =>{
      this.m_resetTimer___$p_org_dominokit_domino_ui_carousel_Carousel();
      this.m_nextSlide___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    this.f_prevElement__org_dominokit_domino_ui_carousel_Carousel_.addEventListener("click", new $LambdaAdaptor$7(((/** Event */ evt$1$) =>{
      this.m_resetTimer___$p_org_dominokit_domino_ui_carousel_Carousel();
      this.m_prevSlide___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    this.f_timer__org_dominokit_domino_ui_carousel_Carousel_ = $1.$create__org_dominokit_domino_ui_carousel_Carousel(this);
    this.m_addAttachListener___$p_org_dominokit_domino_ui_carousel_Carousel();
    this.m_addDetachListener___$p_org_dominokit_domino_ui_carousel_Carousel();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_resetTimer___$p_org_dominokit_domino_ui_carousel_Carousel() {
    this.f_timer__org_dominokit_domino_ui_carousel_Carousel_.m_cancel__();
    this.f_timer__org_dominokit_domino_ui_carousel_Carousel_.m_scheduleRepeating__int(this.f_autoSlideDuration__org_dominokit_domino_ui_carousel_Carousel_);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addDetachListener___$p_org_dominokit_domino_ui_carousel_Carousel() {
    ElementUtil.m_onDetach__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback(this.m_asElement__(), ObserverCallback.$adapt(((/** MutationRecord */ mutationRecord) =>{
      this.f_attached__org_dominokit_domino_ui_carousel_Carousel_ = false;
      this.m_stopAutoSlide__();
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_addAttachListener___$p_org_dominokit_domino_ui_carousel_Carousel() {
    ElementUtil.m_onAttach__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback(this.m_asElement__(), ObserverCallback.$adapt(((/** MutationRecord */ mutationRecord) =>{
      this.f_attached__org_dominokit_domino_ui_carousel_Carousel_ = true;
      if (this.f_autoSlide__org_dominokit_domino_ui_carousel_Carousel_) {
        this.f_timer__org_dominokit_domino_ui_carousel_Carousel_.m_scheduleRepeating__int(this.f_autoSlideDuration__org_dominokit_domino_ui_carousel_Carousel_);
      }
      this.m_addDetachListener___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
  }
  
  /**
   * @return {Carousel}
   * @public
   */
  static m_create__() {
    Carousel.$clinit();
    return Carousel.$create__();
  }
  
  /**
   * @param {Slide} slide
   * @return {Carousel}
   * @public
   * @deprecated
   */
  m_addSlide__org_dominokit_domino_ui_carousel_Slide(slide) {
    return this.m_appendChild__org_dominokit_domino_ui_carousel_Slide(slide);
  }
  
  /**
   * @param {Slide} slide
   * @return {Carousel}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_carousel_Slide(slide) {
    this.m_getIndicatorsElement__().m_appendChild__elemental2_dom_Node(slide.m_getIndicatorElement__().m_asElement__());
    this.f_slidesElement__org_dominokit_domino_ui_carousel_Carousel_.appendChild(slide.m_asElement__());
    slide.m_getIndicatorElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("click", new $LambdaAdaptor$8(((/** Event */ evt) =>{
      this.m_resetTimer___$p_org_dominokit_domino_ui_carousel_Carousel();
      this.m_gotToSlide__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(slide, "");
    })));
    slide.m_asElement__().addEventListener("webkitTransitionEnd", new $LambdaAdaptor$9(((/** Event */ evt$1$) =>{
      this.m_removeMotionStyles___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    slide.m_asElement__().addEventListener("MSTransitionEnd", new $LambdaAdaptor$10(((/** Event */ evt$2$) =>{
      this.m_removeMotionStyles___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    slide.m_asElement__().addEventListener("mozTransitionEnd", new $LambdaAdaptor$11(((/** Event */ evt$3$) =>{
      this.m_removeMotionStyles___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    slide.m_asElement__().addEventListener("otransitionend", new $LambdaAdaptor$12(((/** Event */ evt$4$) =>{
      this.m_removeMotionStyles___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    slide.m_asElement__().addEventListener("transitionend", new $LambdaAdaptor$13(((/** Event */ evt$5$) =>{
      this.m_removeMotionStyles___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    if (this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.isEmpty()) {
      slide.m_activate__();
      this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_ = slide;
    }
    this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.add(slide);
    SwipeUtil.m_addSwipeListener__org_dominokit_domino_ui_utils_SwipeUtil_SwipeDirection__elemental2_dom_HTMLElement__elemental2_dom_EventListener(SwipeDirection.f_LEFT__org_dominokit_domino_ui_utils_SwipeUtil_SwipeDirection, slide.m_asElement__(), new $LambdaAdaptor$14(((/** Event */ evt$6$) =>{
      this.m_nextSlide___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    SwipeUtil.m_addSwipeListener__org_dominokit_domino_ui_utils_SwipeUtil_SwipeDirection__elemental2_dom_HTMLElement__elemental2_dom_EventListener(SwipeDirection.f_RIGHT__org_dominokit_domino_ui_utils_SwipeUtil_SwipeDirection, slide.m_asElement__(), new $LambdaAdaptor$15(((/** Event */ evt$7$) =>{
      this.m_prevSlide___$p_org_dominokit_domino_ui_carousel_Carousel();
    })));
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_nextSlide___$p_org_dominokit_domino_ui_carousel_Carousel() {
    let /** Slide */ nextSlide;
    if (this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_) < this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.size() - 1) {
      nextSlide = /**@type {Slide} */ ($Casts.$to(this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.getAtIndex(this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_) + 1), Slide));
    } else {
      nextSlide = /**@type {Slide} */ ($Casts.$to(this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.getAtIndex(0), Slide));
    }
    this.m_gotToSlide__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(nextSlide, "next");
  }
  
  /**
   * @return {void}
   * @public
   */
  m_prevSlide___$p_org_dominokit_domino_ui_carousel_Carousel() {
    let /** Slide */ prevSlide;
    if (this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_) > 0) {
      prevSlide = /**@type {Slide} */ ($Casts.$to(this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.getAtIndex(this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_) - 1), Slide));
    } else {
      prevSlide = /**@type {Slide} */ ($Casts.$to(this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.getAtIndex(this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.size() - 1), Slide));
    }
    this.m_gotToSlide__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(prevSlide, "prev");
  }
  
  /**
   * @param {Slide} slide
   * @param {?string} source
   * @return {void}
   * @public
   */
  m_gotToSlide__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(slide, source) {
    if (!slide.m_hasActiveStyle__()) {
      this.f_targetSlide__org_dominokit_domino_ui_carousel_Carousel_ = slide;
      slide.m_getIndicatorElement__().m_style__().m_add__java_lang_String("active");
      this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_.m_getIndicatorElement__().m_style__().m_remove__java_lang_String("active");
      slide.m_style__().m_add__java_lang_String(this.m_getPostionStyle__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(slide, source));
      $Overlay.m_setTimeout__elemental2_dom_DomGlobal_SetTimeoutCallbackFn__double__arrayOf_java_lang_Object((/** @param {...*} p0 */ (...p0) =>{
        this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_.m_getIndicatorElement__().m_style__().m_remove__java_lang_String("active");
        let directionStyle = this.m_getDirectionStyle__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(slide, source);
        /**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(slide)).m_add__java_lang_String(directionStyle);
        /**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_)).m_add__java_lang_String(directionStyle);
      }), 50, []);
    }
  }
  
  /**
   * @param {Slide} target
   * @param {?string} source
   * @return {?string}
   * @public
   */
  m_getPostionStyle__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(target, source) {
    if ((this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(target) > this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_) && !j_l_String.m_equals__java_lang_String__java_lang_Object("prev", source)) || (j_l_String.m_equals__java_lang_String__java_lang_Object("next", source) && !j_l_String.m_equals__java_lang_String__java_lang_Object("", "source"))) {
      return "next";
    } else {
      return "prev";
    }
  }
  
  /**
   * @param {Slide} target
   * @param {?string} source
   * @return {?string}
   * @public
   */
  m_getDirectionStyle__org_dominokit_domino_ui_carousel_Slide__java_lang_String_$p_org_dominokit_domino_ui_carousel_Carousel(target, source) {
    if ((this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(target) > this.f_slides__org_dominokit_domino_ui_carousel_Carousel_.indexOf(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_) && !j_l_String.m_equals__java_lang_String__java_lang_Object("prev", source)) || (j_l_String.m_equals__java_lang_String__java_lang_Object("next", source) && !j_l_String.m_equals__java_lang_String__java_lang_Object("", "source"))) {
      return "left";
    } else {
      return "right";
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_removeMotionStyles___$p_org_dominokit_domino_ui_carousel_Carousel() {
    /**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_)).m_remove__java_lang_String("left").m_remove__java_lang_String("right").m_remove__java_lang_String("next").m_remove__java_lang_String("prev");
    this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_.m_deActivate__();
    /**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_targetSlide__org_dominokit_domino_ui_carousel_Carousel_)).m_remove__java_lang_String("left").m_remove__java_lang_String("right").m_remove__java_lang_String("next").m_remove__java_lang_String("prev");
    this.f_targetSlide__org_dominokit_domino_ui_carousel_Carousel_.m_activate__();
    this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_ = this.f_targetSlide__org_dominokit_domino_ui_carousel_Carousel_;
  }
  
  /**
   * @param {number} slideDuration
   * @return {Carousel}
   * @public
   */
  m_startAutoSlide__int(slideDuration) {
    this.f_autoSlide__org_dominokit_domino_ui_carousel_Carousel_ = true;
    this.f_autoSlideDuration__org_dominokit_domino_ui_carousel_Carousel_ = slideDuration;
    if (this.f_attached__org_dominokit_domino_ui_carousel_Carousel_) {
      this.f_timer__org_dominokit_domino_ui_carousel_Carousel_.m_scheduleRepeating__int(slideDuration);
    }
    return this;
  }
  
  /**
   * @return {Carousel}
   * @public
   */
  m_stopAutoSlide__() {
    if (this.f_timer__org_dominokit_domino_ui_carousel_Carousel_.m_isRunning__()) {
      this.f_timer__org_dominokit_domino_ui_carousel_Carousel_.m_cancel__();
    }
    this.m_addAttachListener___$p_org_dominokit_domino_ui_carousel_Carousel();
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_carousel_Carousel_;
  }
  
  /**
   * @return {DominoElement<HTMLOListElement>}
   * @public
   */
  m_getIndicatorsElement__() {
    return /**@type {DominoElement<HTMLOListElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_indicatorsElement__org_dominokit_domino_ui_carousel_Carousel_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getSlidesElement__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_slidesElement__org_dominokit_domino_ui_carousel_Carousel_));
  }
  
  /**
   * @return {List<Slide>}
   * @public
   */
  m_getSlides__() {
    return this.f_slides__org_dominokit_domino_ui_carousel_Carousel_;
  }
  
  /**
   * @return {Slide}
   * @public
   */
  m_getActiveSlide__() {
    return this.f_activeSlide__org_dominokit_domino_ui_carousel_Carousel_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_carousel_Carousel() {
    this.f_indicatorsElement__org_dominokit_domino_ui_carousel_Carousel_ = /**@type {HTMLOListElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLOListElement>} */ ($Casts.$to(Elements.m_ol__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["carousel-indicators"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLOListElement_$Overlay));
    this.f_slidesElement__org_dominokit_domino_ui_carousel_Carousel_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["carousel-inner"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_autoSlide__org_dominokit_domino_ui_carousel_Carousel_ = false;
    this.f_prevElement__org_dominokit_domino_ui_carousel_Carousel_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["left", "carousel-control"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "button"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["glyphicon", "glyphicon-chevron-left"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("aria-hidden", "true")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["sr-only"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String("Previous"), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLAnchorElement_$Overlay));
    this.f_nextElement__org_dominokit_domino_ui_carousel_Carousel_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["right", "carousel-control"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "button"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["glyphicon", "glyphicon-chevron-right"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("aria-hidden", "true")), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["sr-only"], j_l_String))), HtmlContentBuilder)).m_textContent__java_lang_String("Next"), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLAnchorElement_$Overlay));
    this.f_element__org_dominokit_domino_ui_carousel_Carousel_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__elemental2_dom_Node(this.f_indicatorsElement__org_dominokit_domino_ui_carousel_Carousel_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_slidesElement__org_dominokit_domino_ui_carousel_Carousel_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_prevElement__org_dominokit_domino_ui_carousel_Carousel_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_nextElement__org_dominokit_domino_ui_carousel_Carousel_), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["carousel", "slide"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_slides__org_dominokit_domino_ui_carousel_Carousel_ = /**@type {!ArrayList<Slide>} */ (ArrayList.$create__());
    this.f_autoSlideDuration__org_dominokit_domino_ui_carousel_Carousel_ = 3000;
    this.f_attached__org_dominokit_domino_ui_carousel_Carousel_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Carousel.$clinit = (() =>{
    });
    Carousel.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Carousel;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Carousel);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLOListElement_$Overlay = goog.module.get('elemental2.dom.HTMLOListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    $1 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$1$impl');
    $LambdaAdaptor$10 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$10$impl');
    $LambdaAdaptor$11 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$11$impl');
    $LambdaAdaptor$12 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$12$impl');
    $LambdaAdaptor$13 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$13$impl');
    $LambdaAdaptor$14 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$14$impl');
    $LambdaAdaptor$15 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$15$impl');
    $LambdaAdaptor$6 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$6$impl');
    $LambdaAdaptor$7 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$7$impl');
    $LambdaAdaptor$8 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$8$impl');
    $LambdaAdaptor$9 = goog.module.get('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$9$impl');
    Slide = goog.module.get('org.dominokit.domino.ui.carousel.Slide$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    SwipeUtil = goog.module.get('org.dominokit.domino.ui.utils.SwipeUtil$impl');
    SwipeDirection = goog.module.get('org.dominokit.domino.ui.utils.SwipeUtil.SwipeDirection$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    ObserverCallback = goog.module.get('org.jboss.gwt.elemento.core.ObserverCallback$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Carousel, $Util.$makeClassName('org.dominokit.domino.ui.carousel.Carousel'));




exports = Carousel; 
//# sourceMappingURL=Carousel.js.map