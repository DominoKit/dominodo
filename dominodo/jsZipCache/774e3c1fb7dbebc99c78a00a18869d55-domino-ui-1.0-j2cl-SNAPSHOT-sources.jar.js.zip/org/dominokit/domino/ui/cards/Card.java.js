/**
 * @fileoverview transpiled from org.dominokit.domino.ui.cards.Card.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.cards.Card');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _MarginBottomUnionType_$Overlay = goog.require('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay');
const _Document_$Overlay = goog.require('elemental2.dom.Document.$Overlay');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _HTMLUListElement_$Overlay = goog.require('elemental2.dom.HTMLUListElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Text_$Overlay = goog.require('elemental2.dom.Text.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _$LambdaAdaptor$5 = goog.require('org.dominokit.domino.ui.cards.Card.$LambdaAdaptor$5');
const _HeaderAction = goog.require('org.dominokit.domino.ui.cards.HeaderAction');
const _Templated__Card = goog.require('org.dominokit.domino.ui.cards.Templated_Card');
const _Collapsible = goog.require('org.dominokit.domino.ui.collapsible.Collapsible');
const _CollapseCompletedHandler = goog.require('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler');
const _ExpandCompletedHandler = goog.require('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Card = goog.require('org.dominokit.domino.ui.cards.Card$impl');
exports = Card;
 