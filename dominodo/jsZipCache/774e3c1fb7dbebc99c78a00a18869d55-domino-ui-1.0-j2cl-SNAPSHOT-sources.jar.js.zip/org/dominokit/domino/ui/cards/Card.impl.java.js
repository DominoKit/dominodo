/**
 * @fileoverview transpiled from org.dominokit.domino.ui.cards.Card.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.cards.Card$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let MarginBottomUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
let Document_$Overlay = goog.forwardDeclare('elemental2.dom.Document.$Overlay$impl');
let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $LambdaAdaptor$5 = goog.forwardDeclare('org.dominokit.domino.ui.cards.Card.$LambdaAdaptor$5$impl');
let HeaderAction = goog.forwardDeclare('org.dominokit.domino.ui.cards.HeaderAction$impl');
let Templated__Card = goog.forwardDeclare('org.dominokit.domino.ui.cards.Templated_Card$impl');
let Collapsible = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible$impl');
let CollapseCompletedHandler = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler$impl');
let ExpandCompletedHandler = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @extends {BaseDominoElement<HTMLDivElement, Card>}
 * @implements {HasBackground<Card>}
 * @implements {IsElement<HTMLDivElement>}
  */
class Card extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Text} */
    this.f_title__org_dominokit_domino_ui_cards_Card_;
    /** @public {Text} */
    this.f_description__org_dominokit_domino_ui_cards_Card_;
    /** @public {HTMLDivElement} */
    this.f_header__org_dominokit_domino_ui_cards_Card;
    /** @public {HTMLElement} */
    this.f_headerTitle__org_dominokit_domino_ui_cards_Card;
    /** @public {HTMLElement} */
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card;
    /** @public {HTMLUListElement} */
    this.f_headerBar__org_dominokit_domino_ui_cards_Card;
    /** @public {HTMLDivElement} */
    this.f_body__org_dominokit_domino_ui_cards_Card;
    /** @public {boolean} */
    this.f_collapsible__org_dominokit_domino_ui_cards_Card_ = false;
    /** @public {HTMLLIElement} */
    this.f_collapseAction__org_dominokit_domino_ui_cards_Card_;
    /** @public {BaseIcon} */
    this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_;
    /** @public {Collapsible} */
    this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_;
    /** @public {number} */
    this.f_collapseDuration__org_dominokit_domino_ui_cards_Card_ = 0;
    /** @public {boolean} */
    this.f_collapsed__org_dominokit_domino_ui_cards_Card_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_cards_Card__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_cards_Card();
  }
  
  /**
   * @return {Card}
   * @public
   */
  static m_create__() {
    Card.$clinit();
    let templated_basicCard = Templated__Card.$create__();
    templated_basicCard.m_asElement__().removeChild(templated_basicCard.f_header__org_dominokit_domino_ui_cards_Card);
    return templated_basicCard;
  }
  
  /**
   * @param {?string} title
   * @return {Card}
   * @public
   */
  static m_create__java_lang_String(title) {
    Card.$clinit();
    let templated_basicCard = Templated__Card.$create__();
    templated_basicCard.m_setTitle__java_lang_String(title);
    return templated_basicCard;
  }
  
  /**
   * @param {?string} title
   * @param {?string} description
   * @return {Card}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(title, description) {
    Card.$clinit();
    let templated_basicCard = Templated__Card.$create__();
    templated_basicCard.m_setTitle__java_lang_String(title);
    templated_basicCard.m_setDescription__java_lang_String(description);
    return templated_basicCard;
  }
  
  /**
   * @param {?string} name
   * @param {?string} info
   * @return {Card}
   * @public
   */
  static m_createProfile__java_lang_String__java_lang_String(name, info) {
    Card.$clinit();
    let profileCard = Card.m_create__java_lang_String__java_lang_String(name, info);
    /**@type {HTMLDivElement} */ ($Casts.$to(profileCard.m_asElement__(), $Overlay)).style.marginBottom = MarginBottomUnionType_$Overlay.m_of__java_lang_Object(Integer.m_valueOf__int(0));
    profileCard.m_setBackground__org_dominokit_domino_ui_style_Color(Color.f_THEME__org_dominokit_domino_ui_style_Color);
    return profileCard;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_init___$pp_org_dominokit_domino_ui_cards() {
    this.f_headerTitle__org_dominokit_domino_ui_cards_Card.insertBefore(this.f_title__org_dominokit_domino_ui_cards_Card_, this.f_headerDescription__org_dominokit_domino_ui_cards_Card);
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card.appendChild(this.f_description__org_dominokit_domino_ui_cards_Card_);
    this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_ = Collapsible.m_create__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card);
    if (this.f_collapsed__org_dominokit_domino_ui_cards_Card_) {
      this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_.m_collapse__();
    }
    this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_.m_addCollapseHandler__org_dominokit_domino_ui_collapsible_Collapsible_CollapseCompletedHandler(CollapseCompletedHandler.$adapt((() =>{
      if (this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
        this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_down__().m_getName__();
      }
    })));
    this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_.m_addExpandHandler__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler(ExpandCompletedHandler.$adapt((() =>{
      if (this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
        this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_.m_asElement__().textContent = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_up__().m_getName__();
      }
    })));
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {?string} titleText
   * @return {Card}
   * @public
   */
  m_setTitle__java_lang_String(titleText) {
    this.f_title__org_dominokit_domino_ui_cards_Card_.textContent = titleText;
    return this;
  }
  
  /**
   * @param {?string} descriptionText
   * @return {Card}
   * @public
   */
  m_setDescription__java_lang_String(descriptionText) {
    this.f_description__org_dominokit_domino_ui_cards_Card_.textContent = descriptionText;
    return this;
  }
  
  /**
   * @param {Node} content
   * @return {Card}
   * @public
   * @deprecated
   */
  m_appendDescriptionContent__elemental2_dom_Node(content) {
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card.appendChild(content);
    return this;
  }
  
  /**
   * @param {Node} node
   * @return {Card}
   * @public
   */
  m_appendDescriptionChild__elemental2_dom_Node(node) {
    this.f_headerDescription__org_dominokit_domino_ui_cards_Card.appendChild(node);
    return this;
  }
  
  /**
   * @param {IsElement} element
   * @return {Card}
   * @public
   */
  m_appendDescriptionChild__org_jboss_gwt_elemento_core_IsElement(element) {
    return this.m_appendDescriptionChild__elemental2_dom_Node(element.m_asElement__());
  }
  
  /**
   * @param {Node} content
   * @return {Card}
   * @public
   * @deprecated
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.m_getBody__().m_appendChild__elemental2_dom_Node(content);
    return this;
  }
  
  /**
   * @param {IsElement} element
   * @return {Card}
   * @public
   * @deprecated
   */
  m_appendContent__org_jboss_gwt_elemento_core_IsElement(element) {
    this.m_getBody__().m_appendChild__elemental2_dom_Node(element.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @param {Node} content
   * @return {Card}
   * @public
   */
  m_appendChild__elemental2_dom_Node(content) {
    this.m_getBody__().m_appendChild__elemental2_dom_Node(content);
    return this;
  }
  
  /**
   * @override
   * @param {IsElement} element
   * @return {Card}
   * @public
   */
  m_appendChild__org_jboss_gwt_elemento_core_IsElement(element) {
    this.m_getBody__().m_appendChild__elemental2_dom_Node(element.m_asElement__());
    return this;
  }
  
  /**
   * @return {DominoElement<HTMLUListElement>}
   * @public
   */
  m_getHeaderBar__() {
    return /**@type {DominoElement<HTMLUListElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_headerBar__org_dominokit_domino_ui_cards_Card));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getBody__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card));
  }
  
  /**
   * @param {Color} background
   * @return {Card}
   * @public
   */
  m_setHeaderBackground__org_dominokit_domino_ui_style_Color(background) {
    /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_header__org_dominokit_domino_ui_cards_Card)).m_add__java_lang_String(background.m_getBackground__());
    return this;
  }
  
  /**
   * @param {Color} background
   * @return {Card}
   * @public
   */
  m_setBodyBackground__org_dominokit_domino_ui_style_Color(background) {
    /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card)).m_add__java_lang_String(background.m_getBackground__());
    return this;
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_condenseBody__() {
    this.m_getBody__().m_style__().m_setPadding__java_lang_String("0px");
    return this;
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {Card}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    this.m_setHeaderBackground__org_dominokit_domino_ui_style_Color(background);
    this.m_setBodyBackground__org_dominokit_domino_ui_style_Color(background);
    return this;
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getHeader__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_header__org_dominokit_domino_ui_cards_Card));
  }
  
  /**
   * @return {DominoElement<HTMLElement>}
   * @public
   */
  m_getHeaderTitle__() {
    return /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_headerTitle__org_dominokit_domino_ui_cards_Card));
  }
  
  /**
   * @return {DominoElement<HTMLElement>}
   * @public
   */
  m_getHeaderDescription__() {
    return /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_headerDescription__org_dominokit_domino_ui_cards_Card));
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {HTMLLIElement}
   * @public
   */
  static m_createIcon__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Card.$clinit();
    return /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(icon), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @param {EventListener} eventListener
   * @return {Card}
   * @public
   */
  m_addHeaderAction__org_dominokit_domino_ui_icons_BaseIcon__elemental2_dom_EventListener(icon, eventListener) {
    let actionItem = this.m_createHeaderAction__org_dominokit_domino_ui_icons_BaseIcon_$p_org_dominokit_domino_ui_cards_Card(icon);
    actionItem.addEventListener("click", eventListener);
    this.m_putAction__elemental2_dom_HTMLLIElement_$p_org_dominokit_domino_ui_cards_Card(actionItem);
    return this;
  }
  
  /**
   * @param {HeaderAction} headerAction
   * @return {Card}
   * @public
   */
  m_addHeaderAction__org_dominokit_domino_ui_cards_HeaderAction(headerAction) {
    this.m_putAction__elemental2_dom_HTMLLIElement_$p_org_dominokit_domino_ui_cards_Card(headerAction.m_asElement__());
    return this;
  }
  
  /**
   * @param {HTMLLIElement} actionItem
   * @return {void}
   * @public
   */
  m_putAction__elemental2_dom_HTMLLIElement_$p_org_dominokit_domino_ui_cards_Card(actionItem) {
    if (Objects.m_nonNull__java_lang_Object(this.f_collapseAction__org_dominokit_domino_ui_cards_Card_) && this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
      this.f_headerBar__org_dominokit_domino_ui_cards_Card.insertBefore(actionItem, this.f_collapseAction__org_dominokit_domino_ui_cards_Card_);
    } else {
      this.f_headerBar__org_dominokit_domino_ui_cards_Card.appendChild(actionItem);
    }
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {HTMLLIElement}
   * @public
   */
  m_createHeaderAction__org_dominokit_domino_ui_icons_BaseIcon_$p_org_dominokit_domino_ui_cards_Card(icon) {
    return /**@type {HTMLLIElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLLIElement>} */ ($Casts.$to(Elements.m_li__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {BaseIcon} */ ($Casts.$to(icon.m_withWaves__(), BaseIcon)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, BaseIcon> */ style) =>{
      style.m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_pull_right__org_dominokit_domino_ui_style_Styles, "action-icon"], j_l_String)));
    })))), IsElement))), HtmlContentBuilder)).m_asElement__(), HTMLLIElement_$Overlay));
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_setCollapsible__() {
    this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_ = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_keyboard_arrow_up__();
    if (Objects.m_isNull__java_lang_Object(this.f_collapseAction__org_dominokit_domino_ui_cards_Card_)) {
      this.f_collapseAction__org_dominokit_domino_ui_cards_Card_ = this.m_createHeaderAction__org_dominokit_domino_ui_icons_BaseIcon_$p_org_dominokit_domino_ui_cards_Card(this.f_collapseIcon__org_dominokit_domino_ui_cards_Card_);
    }
    this.f_collapseAction__org_dominokit_domino_ui_cards_Card_.addEventListener("click", new $LambdaAdaptor$5(((/** Event */ evt) =>{
      if (this.f_collapsible__org_dominokit_domino_ui_cards_Card_) {
        if (this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_.m_isCollapsed__()) {
          this.m_expand__();
        } else {
          this.m_collapse__();
        }
      }
    })));
    this.m_putAction__elemental2_dom_HTMLLIElement_$p_org_dominokit_domino_ui_cards_Card(this.f_collapseAction__org_dominokit_domino_ui_cards_Card_);
    this.f_collapsible__org_dominokit_domino_ui_cards_Card_ = true;
    return this;
  }
  
  /**
   * @override
   * @return {Card}
   * @public
   */
  m_collapse__() {
    this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_.m_collapse__();
    return this;
  }
  
  /**
   * @override
   * @return {Card}
   * @public
   */
  m_expand__() {
    this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_.m_expand__();
    return this;
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_toggle__() {
    if (this.f_collapsed__org_dominokit_domino_ui_cards_Card_) {
      this.m_expand__();
    } else {
      this.m_collapse__();
    }
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isCollapsed__() {
    return this.f_bodyCollapsible__org_dominokit_domino_ui_cards_Card_.m_isCollapsed__();
  }
  
  /**
   * @param {?string} padding
   * @return {Card}
   * @public
   */
  m_setBodyPadding__java_lang_String(padding) {
    /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card)).m_setPadding__java_lang_String(padding);
    return this;
  }
  
  /**
   * @param {?string} padding
   * @return {Card}
   * @public
   */
  m_setBodyPaddingLeft__java_lang_String(padding) {
    /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card)).m_setPaddingLeft__java_lang_String(padding);
    return this;
  }
  
  /**
   * @param {?string} padding
   * @return {Card}
   * @public
   */
  m_setBodyPaddingRight__java_lang_String(padding) {
    /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card)).m_setPaddingRight__java_lang_String(padding);
    return this;
  }
  
  /**
   * @param {?string} padding
   * @return {Card}
   * @public
   */
  m_setBodyPaddingTop__java_lang_String(padding) {
    /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card)).m_setPaddingTop__java_lang_String(padding);
    return this;
  }
  
  /**
   * @param {?string} padding
   * @return {Card}
   * @public
   */
  m_setBodyPaddingBottom__java_lang_String(padding) {
    /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card)).m_setPaddingBottom__java_lang_String(padding);
    return this;
  }
  
  /**
   * @override
   * @return {Style<HTMLDivElement, Card>}
   * @public
   */
  m_style__() {
    return /**@type {Style<HTMLDivElement, Card>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this));
  }
  
  /**
   * @return {Style<HTMLDivElement, IsElement<HTMLDivElement>>}
   * @public
   */
  m_bodyStyle__() {
    return /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_body__org_dominokit_domino_ui_cards_Card));
  }
  
  /**
   * @param {number} collapseDuration
   * @return {Card}
   * @public
   */
  m_setCollapseDuration__int(collapseDuration) {
    this.f_collapseDuration__org_dominokit_domino_ui_cards_Card_ = collapseDuration;
    return this;
  }
  
  /**
   * @return {Card}
   * @public
   */
  m_clearBody__() {
    this.m_getBody__().m_clearElement__();
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_cards_Card() {
    this.f_title__org_dominokit_domino_ui_cards_Card_ = Document_$Overlay.m_createTextNode__elemental2_dom_Document__java_lang_String(DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay, "");
    this.f_description__org_dominokit_domino_ui_cards_Card_ = Document_$Overlay.m_createTextNode__elemental2_dom_Document__java_lang_String(DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay, "");
    this.f_collapsible__org_dominokit_domino_ui_cards_Card_ = false;
    this.f_collapseDuration__org_dominokit_domino_ui_cards_Card_ = 1;
    this.f_collapsed__org_dominokit_domino_ui_cards_Card_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Card.$clinit = (() =>{
    });
    Card.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Card;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Card);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    MarginBottomUnionType_$Overlay = goog.module.get('elemental2.dom.CSSProperties.MarginBottomUnionType.$Overlay$impl');
    Document_$Overlay = goog.module.get('elemental2.dom.Document.$Overlay$impl');
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $LambdaAdaptor$5 = goog.module.get('org.dominokit.domino.ui.cards.Card.$LambdaAdaptor$5$impl');
    Templated__Card = goog.module.get('org.dominokit.domino.ui.cards.Templated_Card$impl');
    Collapsible = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible$impl');
    CollapseCompletedHandler = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler$impl');
    ExpandCompletedHandler = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler$impl');
    BaseIcon = goog.module.get('org.dominokit.domino.ui.icons.BaseIcon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Card, $Util.$makeClassName('org.dominokit.domino.ui.cards.Card'));


HasBackground.$markImplementor(Card);
IsElement.$markImplementor(Card);


exports = Card; 
//# sourceMappingURL=Card.js.map