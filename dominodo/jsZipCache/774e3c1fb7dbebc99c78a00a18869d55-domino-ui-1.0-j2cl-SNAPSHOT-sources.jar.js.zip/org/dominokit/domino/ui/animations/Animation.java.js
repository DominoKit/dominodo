/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Animation.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.animations.Animation');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$1 = goog.require('org.dominokit.domino.ui.animations.Animation.$1');
const _$LambdaAdaptor$2 = goog.require('org.dominokit.domino.ui.animations.Animation.$LambdaAdaptor$2');
const _CompleteCallback = goog.require('org.dominokit.domino.ui.animations.Animation.CompleteCallback');
const _StartHandler = goog.require('org.dominokit.domino.ui.animations.Animation.StartHandler');
const _Transition = goog.require('org.dominokit.domino.ui.animations.Transition');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');


// Re-exports the implementation.
var Animation = goog.require('org.dominokit.domino.ui.animations.Animation$impl');
exports = Animation;
 