/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Animation.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.animations.Animation$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.$1$impl');
let $LambdaAdaptor$2 = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.$LambdaAdaptor$2$impl');
let CompleteCallback = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');
let StartHandler = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.StartHandler$impl');
let Transition = goog.forwardDeclare('org.dominokit.domino.ui.animations.Transition$impl');
let BaseDominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');


class Animation extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {CompleteCallback} */
    this.f_DEFAULT_CALLBACK__org_dominokit_domino_ui_animations_Animation_;
    /** @public {StartHandler} */
    this.f_DEFAULT_START_HANDLER__org_dominokit_domino_ui_animations_Animation_;
    /** @public {number} */
    this.f_duration__org_dominokit_domino_ui_animations_Animation_ = 0;
    /** @public {number} */
    this.f_delay__org_dominokit_domino_ui_animations_Animation_ = 0;
    /** @public {boolean} */
    this.f_infinite__org_dominokit_domino_ui_animations_Animation_ = false;
    /** @public {DominoElement<HTMLElement>} */
    this.f_element__org_dominokit_domino_ui_animations_Animation_;
    /** @public {Transition} */
    this.f_transition__org_dominokit_domino_ui_animations_Animation_;
    /** @public {CompleteCallback} */
    this.f_callback__org_dominokit_domino_ui_animations_Animation_;
    /** @public {StartHandler} */
    this.f_startHandler__org_dominokit_domino_ui_animations_Animation_;
    /** @public {EventListener} */
    this.f_stopListener__org_dominokit_domino_ui_animations_Animation_;
  }
  
  /**
   * Factory method corresponding to constructor 'Animation(HTMLElement)'.
   * @param {HTMLElement} element
   * @return {!Animation}
   * @public
   */
  static $create__elemental2_dom_HTMLElement(element) {
    Animation.$clinit();
    let $instance = new Animation();
    $instance.$ctor__org_dominokit_domino_ui_animations_Animation__elemental2_dom_HTMLElement(element);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Animation(HTMLElement)'.
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_animations_Animation__elemental2_dom_HTMLElement(element) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_animations_Animation();
    this.f_element__org_dominokit_domino_ui_animations_Animation_ = /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(element));
  }
  
  /**
   * Factory method corresponding to constructor 'Animation(HTMLElement, int, int, boolean)'.
   * @param {HTMLElement} element
   * @param {number} duration
   * @param {number} delay
   * @param {boolean} infinite
   * @return {!Animation}
   * @public
   */
  static $create__elemental2_dom_HTMLElement__int__int__boolean(element, duration, delay, infinite) {
    Animation.$clinit();
    let $instance = new Animation();
    $instance.$ctor__org_dominokit_domino_ui_animations_Animation__elemental2_dom_HTMLElement__int__int__boolean(element, duration, delay, infinite);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Animation(HTMLElement, int, int, boolean)'.
   * @param {HTMLElement} element
   * @param {number} duration
   * @param {number} delay
   * @param {boolean} infinite
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_animations_Animation__elemental2_dom_HTMLElement__int__int__boolean(element, duration, delay, infinite) {
    this.$ctor__org_dominokit_domino_ui_animations_Animation__elemental2_dom_HTMLElement(element);
    this.f_duration__org_dominokit_domino_ui_animations_Animation_ = duration;
    this.f_delay__org_dominokit_domino_ui_animations_Animation_ = delay;
    this.f_infinite__org_dominokit_domino_ui_animations_Animation_ = infinite;
  }
  
  /**
   * @param {HTMLElement} element
   * @return {Animation}
   * @public
   */
  static m_create__elemental2_dom_HTMLElement(element) {
    Animation.$clinit();
    return Animation.$create__elemental2_dom_HTMLElement(element);
  }
  
  /**
   * @param {BaseDominoElement} element
   * @return {Animation}
   * @public
   */
  static m_create__org_dominokit_domino_ui_utils_BaseDominoElement(element) {
    Animation.$clinit();
    return Animation.$create__elemental2_dom_HTMLElement(element.m_asElement__());
  }
  
  /**
   * @param {IsElement} element
   * @return {Animation}
   * @public
   */
  static m_create__org_jboss_gwt_elemento_core_IsElement(element) {
    Animation.$clinit();
    return Animation.$create__elemental2_dom_HTMLElement(element.m_asElement__());
  }
  
  /**
   * @param {number} duration
   * @return {Animation}
   * @public
   */
  m_duration__int(duration) {
    this.f_duration__org_dominokit_domino_ui_animations_Animation_ = duration;
    return this;
  }
  
  /**
   * @param {number} delay
   * @return {Animation}
   * @public
   */
  m_delay__int(delay) {
    this.f_delay__org_dominokit_domino_ui_animations_Animation_ = delay;
    return this;
  }
  
  /**
   * @return {Animation}
   * @public
   */
  m_infinite__() {
    this.f_infinite__org_dominokit_domino_ui_animations_Animation_ = true;
    return this;
  }
  
  /**
   * @param {Transition} transition
   * @return {Animation}
   * @public
   */
  m_transition__org_dominokit_domino_ui_animations_Transition(transition) {
    this.f_transition__org_dominokit_domino_ui_animations_Animation_ = transition;
    return this;
  }
  
  /**
   * @param {CompleteCallback} callback
   * @return {Animation}
   * @public
   */
  m_callback__org_dominokit_domino_ui_animations_Animation_CompleteCallback(callback) {
    this.f_callback__org_dominokit_domino_ui_animations_Animation_ = callback;
    return this;
  }
  
  /**
   * @param {StartHandler} startHandler
   * @return {Animation}
   * @public
   */
  m_beforeStart__org_dominokit_domino_ui_animations_Animation_StartHandler(startHandler) {
    this.f_startHandler__org_dominokit_domino_ui_animations_Animation_ = startHandler;
    return this;
  }
  
  /**
   * @return {Animation}
   * @public
   */
  m_animate__() {
    if (this.f_delay__org_dominokit_domino_ui_animations_Animation_ > 0) {
      $1.$create__org_dominokit_domino_ui_animations_Animation(this).m_schedule__int(this.f_delay__org_dominokit_domino_ui_animations_Animation_);
    } else {
      this.m_animateElement___$p_org_dominokit_domino_ui_animations_Animation();
    }
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_animateElement___$p_org_dominokit_domino_ui_animations_Animation() {
    this.f_startHandler__org_dominokit_domino_ui_animations_Animation_.m_beforeStart__elemental2_dom_HTMLElement(this.f_element__org_dominokit_domino_ui_animations_Animation_.m_asElement__());
    this.f_stopListener__org_dominokit_domino_ui_animations_Animation_ = new $LambdaAdaptor$2(((/** Event */ evt) =>{
      this.m_stop__();
    }));
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_addEventListener__java_lang_String__elemental2_dom_EventListener("webkitAnimationEnd", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_addEventListener__java_lang_String__elemental2_dom_EventListener("MSAnimationEnd", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_addEventListener__java_lang_String__elemental2_dom_EventListener("mozAnimationEnd", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_addEventListener__java_lang_String__elemental2_dom_EventListener("oanimationend", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_addEventListener__java_lang_String__elemental2_dom_EventListener("animationend", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_setTransitionDuration__java_lang_String(this.f_duration__org_dominokit_domino_ui_animations_Animation_ + "ms");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_setProperty__java_lang_String__java_lang_String("animation-duration", this.f_duration__org_dominokit_domino_ui_animations_Animation_ + "ms");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_setProperty__java_lang_String__java_lang_String("-webkit-animation-duration", this.f_duration__org_dominokit_domino_ui_animations_Animation_ + "ms");
    if (this.f_infinite__org_dominokit_domino_ui_animations_Animation_) {
      this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_add__java_lang_String("infinite");
    }
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_add__java_lang_String("animated");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_add__java_lang_String("ease-in-out");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_add__java_lang_String(this.f_transition__org_dominokit_domino_ui_animations_Animation_.m_getStyle__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_stop__() {
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_remove__java_lang_String(this.f_transition__org_dominokit_domino_ui_animations_Animation_.m_getStyle__());
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_remove__java_lang_String("animated");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_remove__java_lang_String("infinite");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_remove__java_lang_String("ease-in-out");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_removeProperty__java_lang_String("animation-duration");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_style__().m_removeProperty__java_lang_String("-webkit-animation-duration");
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_removeEventListener__java_lang_String__elemental2_dom_EventListener("webkitAnimationEnd", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_removeEventListener__java_lang_String__elemental2_dom_EventListener("MSAnimationEnd", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_removeEventListener__java_lang_String__elemental2_dom_EventListener("mozAnimationEnd", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_removeEventListener__java_lang_String__elemental2_dom_EventListener("oanimationend", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_element__org_dominokit_domino_ui_animations_Animation_.m_removeEventListener__java_lang_String__elemental2_dom_EventListener("animationend", this.f_stopListener__org_dominokit_domino_ui_animations_Animation_);
    this.f_callback__org_dominokit_domino_ui_animations_Animation_.m_onComplete__elemental2_dom_HTMLElement(this.f_element__org_dominokit_domino_ui_animations_Animation_.m_asElement__());
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_animations_Animation() {
    this.f_DEFAULT_CALLBACK__org_dominokit_domino_ui_animations_Animation_ = CompleteCallback.$adapt(((/** HTMLElement */ element) =>{
    }));
    this.f_DEFAULT_START_HANDLER__org_dominokit_domino_ui_animations_Animation_ = StartHandler.$adapt(((/** HTMLElement */ element$1$) =>{
    }));
    this.f_duration__org_dominokit_domino_ui_animations_Animation_ = 800;
    this.f_delay__org_dominokit_domino_ui_animations_Animation_ = 0;
    this.f_infinite__org_dominokit_domino_ui_animations_Animation_ = false;
    this.f_transition__org_dominokit_domino_ui_animations_Animation_ = Transition.f_BOUNCE__org_dominokit_domino_ui_animations_Transition;
    this.f_callback__org_dominokit_domino_ui_animations_Animation_ = this.f_DEFAULT_CALLBACK__org_dominokit_domino_ui_animations_Animation_;
    this.f_startHandler__org_dominokit_domino_ui_animations_Animation_ = this.f_DEFAULT_START_HANDLER__org_dominokit_domino_ui_animations_Animation_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Animation.$clinit = (() =>{
    });
    Animation.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Animation;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Animation);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $1 = goog.module.get('org.dominokit.domino.ui.animations.Animation.$1$impl');
    $LambdaAdaptor$2 = goog.module.get('org.dominokit.domino.ui.animations.Animation.$LambdaAdaptor$2$impl');
    CompleteCallback = goog.module.get('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');
    StartHandler = goog.module.get('org.dominokit.domino.ui.animations.Animation.StartHandler$impl');
    Transition = goog.module.get('org.dominokit.domino.ui.animations.Transition$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
  }
  
  
};

$Util.$setClassMetadata(Animation, $Util.$makeClassName('org.dominokit.domino.ui.animations.Animation'));




exports = Animation; 
//# sourceMappingURL=Animation.js.map