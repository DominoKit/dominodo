/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Animation$CompleteCallback.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.CompleteCallback.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CompleteCallback {
  /**
   * @abstract
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  m_onComplete__elemental2_dom_HTMLElement(element) {
  }
  
  /**
   * @param {?function(HTMLElement):void} fn
   * @return {CompleteCallback}
   * @public
   */
  static $adapt(fn) {
    CompleteCallback.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CompleteCallback.$clinit = (() =>{
    });
    CompleteCallback.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_animations_Animation_CompleteCallback = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_animations_Animation_CompleteCallback;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_animations_Animation_CompleteCallback;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.animations.Animation.CompleteCallback.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CompleteCallback, $Util.$makeClassName('org.dominokit.domino.ui.animations.Animation$CompleteCallback'));


CompleteCallback.$markImplementor(/** @type {Function} */ (CompleteCallback));


exports = CompleteCallback; 
//# sourceMappingURL=Animation$CompleteCallback.js.map