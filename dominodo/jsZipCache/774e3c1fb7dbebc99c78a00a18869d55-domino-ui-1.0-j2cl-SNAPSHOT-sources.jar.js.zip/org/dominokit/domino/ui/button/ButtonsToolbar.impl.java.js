/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.ButtonsToolbar.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.ButtonsToolbar$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLElement, ButtonsToolbar>}
  */
class ButtonsToolbar extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_;
  }
  
  /**
   * @return {!ButtonsToolbar}
   * @public
   */
  static $create__() {
    ButtonsToolbar.$clinit();
    let $instance = new ButtonsToolbar();
    $instance.$ctor__org_dominokit_domino_ui_button_ButtonsToolbar__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_ButtonsToolbar__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_button_ButtonsToolbar();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {ButtonsToolbar}
   * @public
   */
  static m_create__() {
    ButtonsToolbar.$clinit();
    return ButtonsToolbar.$create__();
  }
  
  /**
   * @param {ButtonsGroup} group
   * @return {ButtonsToolbar}
   * @public
   */
  m_addGroup__org_dominokit_domino_ui_button_group_ButtonsGroup(group) {
    this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_.appendChild(group.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_ButtonsToolbar() {
    this.f_toolbarElement__org_dominokit_domino_ui_button_ButtonsToolbar_ = /**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["btn-toolbar"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "toolbar"), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ButtonsToolbar.$clinit = (() =>{
    });
    ButtonsToolbar.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsToolbar;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsToolbar);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ButtonsToolbar, $Util.$makeClassName('org.dominokit.domino.ui.button.ButtonsToolbar'));




exports = ButtonsToolbar; 
//# sourceMappingURL=ButtonsToolbar.js.map