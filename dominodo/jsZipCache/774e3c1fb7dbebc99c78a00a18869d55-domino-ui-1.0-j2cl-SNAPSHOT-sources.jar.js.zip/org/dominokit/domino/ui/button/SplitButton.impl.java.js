/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.SplitButton.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.SplitButton$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLElement, SplitButton>}
  */
class SplitButton extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_groupElement__org_dominokit_domino_ui_button_SplitButton_;
  }
  
  /**
   * Factory method corresponding to constructor 'SplitButton(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {!SplitButton}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    SplitButton.$clinit();
    let $instance = new SplitButton();
    $instance.$ctor__org_dominokit_domino_ui_button_SplitButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SplitButton(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_SplitButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_button_SplitButton();
    this.m_addButton__org_dominokit_domino_ui_button_Button_$p_org_dominokit_domino_ui_button_SplitButton(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String(content).m_setButtonType__org_dominokit_domino_ui_style_StyleType(type), Button)));
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * Factory method corresponding to constructor 'SplitButton(String, Color)'.
   * @param {?string} content
   * @param {Color} background
   * @return {!SplitButton}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    SplitButton.$clinit();
    let $instance = new SplitButton();
    $instance.$ctor__org_dominokit_domino_ui_button_SplitButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SplitButton(String, Color)'.
   * @param {?string} content
   * @param {Color} background
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_SplitButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_button_SplitButton();
    this.m_addButton__org_dominokit_domino_ui_button_Button_$p_org_dominokit_domino_ui_button_SplitButton(/**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String(content).m_setBackground__org_dominokit_domino_ui_style_Color(background), Button)));
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * Factory method corresponding to constructor 'SplitButton(String)'.
   * @param {?string} content
   * @return {!SplitButton}
   * @public
   */
  static $create__java_lang_String(content) {
    SplitButton.$clinit();
    let $instance = new SplitButton();
    $instance.$ctor__org_dominokit_domino_ui_button_SplitButton__java_lang_String(content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SplitButton(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_SplitButton__java_lang_String(content) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_button_SplitButton();
    this.m_addButton__org_dominokit_domino_ui_button_Button_$p_org_dominokit_domino_ui_button_SplitButton(Button.m_create__java_lang_String(content));
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {Button} button
   * @return {void}
   * @public
   */
  m_addButton__org_dominokit_domino_ui_button_Button_$p_org_dominokit_domino_ui_button_SplitButton(button) {
    this.f_groupElement__org_dominokit_domino_ui_button_SplitButton_.appendChild(button.m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_groupElement__org_dominokit_domino_ui_button_SplitButton_;
  }
  
  /**
   * @param {?string} content
   * @return {SplitButton}
   * @public
   */
  static m_create__java_lang_String(content) {
    SplitButton.$clinit();
    return SplitButton.$create__java_lang_String(content);
  }
  
  /**
   * @param {?string} content
   * @param {Color} background
   * @return {SplitButton}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    SplitButton.$clinit();
    return SplitButton.$create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background);
  }
  
  /**
   * @param {?string} content
   * @param {StyleType} type
   * @return {SplitButton}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    SplitButton.$clinit();
    return SplitButton.$create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
  }
  
  /**
   * @param {?string} content
   * @return {SplitButton}
   * @public
   */
  static m_createDefault__java_lang_String(content) {
    SplitButton.$clinit();
    return SplitButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {SplitButton}
   * @public
   */
  static m_createPrimary__java_lang_String(content) {
    SplitButton.$clinit();
    return SplitButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {SplitButton}
   * @public
   */
  static m_createSuccess__java_lang_String(content) {
    SplitButton.$clinit();
    return SplitButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {SplitButton}
   * @public
   */
  static m_createInfo__java_lang_String(content) {
    SplitButton.$clinit();
    return SplitButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {SplitButton}
   * @public
   */
  static m_createWarning__java_lang_String(content) {
    SplitButton.$clinit();
    return SplitButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {SplitButton}
   * @public
   */
  static m_createDanger__java_lang_String(content) {
    SplitButton.$clinit();
    return SplitButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {DropdownButton} dropdownButton
   * @return {SplitButton}
   * @public
   */
  m_addDropdown__org_dominokit_domino_ui_button_DropdownButton(dropdownButton) {
    this.f_groupElement__org_dominokit_domino_ui_button_SplitButton_.appendChild(dropdownButton.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {Style<HTMLElement, SplitButton>}
   * @public
   */
  m_style__() {
    return /**@type {Style<HTMLElement, SplitButton>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_SplitButton() {
    this.f_groupElement__org_dominokit_domino_ui_button_SplitButton_ = ButtonsGroup.m_create__().m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SplitButton.$clinit = (() =>{
    });
    SplitButton.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SplitButton;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SplitButton);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    ButtonsGroup = goog.module.get('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(SplitButton, $Util.$makeClassName('org.dominokit.domino.ui.button.SplitButton'));




exports = SplitButton; 
//# sourceMappingURL=SplitButton.js.map