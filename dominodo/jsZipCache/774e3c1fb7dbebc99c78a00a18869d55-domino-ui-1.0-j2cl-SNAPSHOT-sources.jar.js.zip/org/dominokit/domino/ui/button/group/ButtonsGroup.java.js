/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.group.ButtonsGroup.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.group.ButtonsGroup');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IsGroup = goog.require('org.dominokit.domino.ui.button.group.IsGroup');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _ButtonSize = goog.require('org.dominokit.domino.ui.button.ButtonSize');
const _DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ButtonsGroup = goog.require('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
exports = ButtonsGroup;
 