/**
 * @fileoverview transpiled from org.dominokit.domino.ui.column.Column$OnXSmall.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.column.Column.OnXSmall$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<OnXSmall>}
  */
class OnXSmall extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_column_Column_OnXSmall_;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!OnXSmall}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new OnXSmall();
    $instance.$ctor__org_dominokit_domino_ui_column_Column_OnXSmall__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_column_Column_OnXSmall__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_column_Column_OnXSmall_ = style;
  }
  
  /**
   * @param {number} xsmall
   * @return {OnXSmall}
   * @public
   */
  static m_of__int(xsmall) {
    OnXSmall.$clinit();
    return OnXSmall.m_valueOf__java_lang_String(Column.m_asNumberString__int_$p_org_dominokit_domino_ui_column_Column(xsmall));
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_column_Column_OnXSmall_;
  }
  
  /**
   * @param {string} name
   * @return {!OnXSmall}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    OnXSmall.$clinit();
    if ($Equality.$same(OnXSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_, null)) {
      OnXSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_ = $Enums.createMapFromValues(OnXSmall.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, OnXSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_);
  }
  
  /**
   * @return {!Array<!OnXSmall>}
   * @public
   */
  static m_values__() {
    OnXSmall.$clinit();
    return /**@type {!Array<OnXSmall>} */ ($Arrays.$init([OnXSmall.$f_one__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_two__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_three__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_four__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_five__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_six__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall, OnXSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall], OnXSmall));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {OnXSmall} */ ($Casts.$to(arg0, OnXSmall)));
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_one__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_one__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_one__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_one__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_two__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_two__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_two__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_two__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_three__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_three__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_three__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_three__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_four__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_four__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_four__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_four__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_five__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_five__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_five__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_five__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_six__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_six__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_six__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_six__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_seven__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_seven__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_eight__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_eight__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_nine__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_nine__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_ten__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_ten__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {!OnXSmall}
   * @public
   */
  static get f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall() {
    return (OnXSmall.$clinit(), OnXSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall);
  }
  
  /**
   * @param {!OnXSmall} value
   * @return {void}
   * @public
   */
  static set f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall = value);
  }
  
  /**
   * @return {Map<?string, !OnXSmall>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_() {
    return (OnXSmall.$clinit(), OnXSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_);
  }
  
  /**
   * @param {Map<?string, !OnXSmall>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_(value) {
    (OnXSmall.$clinit(), OnXSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    OnXSmall.$clinit = (() =>{
    });
    OnXSmall.$loadModules();
    Enum.$clinit();
    OnXSmall.$f_one__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("one"), OnXSmall.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-1");
    OnXSmall.$f_two__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("two"), OnXSmall.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-2");
    OnXSmall.$f_three__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("three"), OnXSmall.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-3");
    OnXSmall.$f_four__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("four"), OnXSmall.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-4");
    OnXSmall.$f_five__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("five"), OnXSmall.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-5");
    OnXSmall.$f_six__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("six"), OnXSmall.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-6");
    OnXSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("seven"), OnXSmall.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-7");
    OnXSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eight"), OnXSmall.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-8");
    OnXSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("nine"), OnXSmall.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-9");
    OnXSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ten"), OnXSmall.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-10");
    OnXSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eleven"), OnXSmall.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-11");
    OnXSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall = OnXSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("twelve"), OnXSmall.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall, "col-xs-12");
    OnXSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof OnXSmall;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, OnXSmall);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(OnXSmall, $Util.$makeClassName('org.dominokit.domino.ui.column.Column$OnXSmall'));


/** @private {!OnXSmall} */
OnXSmall.$f_one__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_two__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_three__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_four__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_five__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_six__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {!OnXSmall} */
OnXSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall;


/** @private {Map<?string, !OnXSmall>} */
OnXSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXSmall_;


/** @public {number} @const */
OnXSmall.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnXSmall = 0;


/** @public {number} @const */
OnXSmall.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnXSmall = 1;


/** @public {number} @const */
OnXSmall.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnXSmall = 2;


/** @public {number} @const */
OnXSmall.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnXSmall = 3;


/** @public {number} @const */
OnXSmall.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnXSmall = 4;


/** @public {number} @const */
OnXSmall.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnXSmall = 5;


/** @public {number} @const */
OnXSmall.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnXSmall = 6;


/** @public {number} @const */
OnXSmall.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnXSmall = 7;


/** @public {number} @const */
OnXSmall.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnXSmall = 8;


/** @public {number} @const */
OnXSmall.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnXSmall = 9;


/** @public {number} @const */
OnXSmall.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnXSmall = 10;


/** @public {number} @const */
OnXSmall.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnXSmall = 11;




exports = OnXSmall; 
//# sourceMappingURL=Column$OnXSmall.js.map