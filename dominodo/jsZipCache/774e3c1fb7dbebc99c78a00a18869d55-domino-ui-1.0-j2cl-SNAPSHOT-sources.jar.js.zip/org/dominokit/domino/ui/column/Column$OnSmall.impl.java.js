/**
 * @fileoverview transpiled from org.dominokit.domino.ui.column.Column$OnSmall.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.column.Column.OnSmall$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<OnSmall>}
  */
class OnSmall extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_column_Column_OnSmall_;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!OnSmall}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new OnSmall();
    $instance.$ctor__org_dominokit_domino_ui_column_Column_OnSmall__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_column_Column_OnSmall__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_column_Column_OnSmall_ = style;
  }
  
  /**
   * @param {number} small
   * @return {OnSmall}
   * @public
   */
  static m_of__int(small) {
    OnSmall.$clinit();
    return OnSmall.m_valueOf__java_lang_String(Column.m_asNumberString__int_$p_org_dominokit_domino_ui_column_Column(small));
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_column_Column_OnSmall_;
  }
  
  /**
   * @param {string} name
   * @return {!OnSmall}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    OnSmall.$clinit();
    if ($Equality.$same(OnSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_, null)) {
      OnSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_ = $Enums.createMapFromValues(OnSmall.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, OnSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_);
  }
  
  /**
   * @return {!Array<!OnSmall>}
   * @public
   */
  static m_values__() {
    OnSmall.$clinit();
    return /**@type {!Array<OnSmall>} */ ($Arrays.$init([OnSmall.$f_one__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_two__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_three__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_four__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_five__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_six__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnSmall, OnSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnSmall], OnSmall));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {OnSmall} */ ($Casts.$to(arg0, OnSmall)));
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_one__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_one__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_one__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_one__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_two__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_two__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_two__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_two__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_three__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_three__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_three__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_three__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_four__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_four__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_four__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_four__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_five__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_five__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_five__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_five__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_six__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_six__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_six__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_six__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_seven__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_seven__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_eight__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_eight__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_nine__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_nine__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_ten__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_ten__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_eleven__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_eleven__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {!OnSmall}
   * @public
   */
  static get f_twelve__org_dominokit_domino_ui_column_Column_OnSmall() {
    return (OnSmall.$clinit(), OnSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnSmall);
  }
  
  /**
   * @param {!OnSmall} value
   * @return {void}
   * @public
   */
  static set f_twelve__org_dominokit_domino_ui_column_Column_OnSmall(value) {
    (OnSmall.$clinit(), OnSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnSmall = value);
  }
  
  /**
   * @return {Map<?string, !OnSmall>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_() {
    return (OnSmall.$clinit(), OnSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_);
  }
  
  /**
   * @param {Map<?string, !OnSmall>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_(value) {
    (OnSmall.$clinit(), OnSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    OnSmall.$clinit = (() =>{
    });
    OnSmall.$loadModules();
    Enum.$clinit();
    OnSmall.$f_one__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("one"), OnSmall.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-1");
    OnSmall.$f_two__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("two"), OnSmall.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-2");
    OnSmall.$f_three__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("three"), OnSmall.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-3");
    OnSmall.$f_four__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("four"), OnSmall.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-4");
    OnSmall.$f_five__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("five"), OnSmall.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-5");
    OnSmall.$f_six__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("six"), OnSmall.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-6");
    OnSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("seven"), OnSmall.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-7");
    OnSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eight"), OnSmall.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-8");
    OnSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("nine"), OnSmall.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-9");
    OnSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ten"), OnSmall.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-10");
    OnSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eleven"), OnSmall.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-11");
    OnSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnSmall = OnSmall.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("twelve"), OnSmall.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnSmall, "col-sm-12");
    OnSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof OnSmall;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, OnSmall);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(OnSmall, $Util.$makeClassName('org.dominokit.domino.ui.column.Column$OnSmall'));


/** @private {!OnSmall} */
OnSmall.$f_one__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_two__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_three__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_four__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_five__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_six__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_seven__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_eight__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_nine__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_ten__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_eleven__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {!OnSmall} */
OnSmall.$f_twelve__org_dominokit_domino_ui_column_Column_OnSmall;


/** @private {Map<?string, !OnSmall>} */
OnSmall.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnSmall_;


/** @public {number} @const */
OnSmall.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnSmall = 0;


/** @public {number} @const */
OnSmall.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnSmall = 1;


/** @public {number} @const */
OnSmall.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnSmall = 2;


/** @public {number} @const */
OnSmall.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnSmall = 3;


/** @public {number} @const */
OnSmall.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnSmall = 4;


/** @public {number} @const */
OnSmall.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnSmall = 5;


/** @public {number} @const */
OnSmall.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnSmall = 6;


/** @public {number} @const */
OnSmall.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnSmall = 7;


/** @public {number} @const */
OnSmall.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnSmall = 8;


/** @public {number} @const */
OnSmall.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnSmall = 9;


/** @public {number} @const */
OnSmall.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnSmall = 10;


/** @public {number} @const */
OnSmall.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnSmall = 11;




exports = OnSmall; 
//# sourceMappingURL=Column$OnSmall.js.map