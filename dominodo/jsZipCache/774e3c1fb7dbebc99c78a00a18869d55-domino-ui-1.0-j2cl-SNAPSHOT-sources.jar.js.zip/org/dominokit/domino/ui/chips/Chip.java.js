/**
 * @fileoverview transpiled from org.dominokit.domino.ui.chips.Chip.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.chips.Chip');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasDeselectionHandler = goog.require('org.dominokit.domino.ui.utils.HasDeselectionHandler');
const _HasRemoveHandler = goog.require('org.dominokit.domino.ui.utils.HasRemoveHandler');
const _HasSelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _$LambdaAdaptor$16 = goog.require('org.dominokit.domino.ui.chips.Chip.$LambdaAdaptor$16');
const _$LambdaAdaptor$17 = goog.require('org.dominokit.domino.ui.chips.Chip.$LambdaAdaptor$17');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _DeselectionHandler = goog.require('org.dominokit.domino.ui.utils.HasDeselectionHandler.DeselectionHandler');
const _RemoveHandler = goog.require('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Chip = goog.require('org.dominokit.domino.ui.chips.Chip$impl');
exports = Chip;
 