/**
 * @fileoverview transpiled from org.dominokit.domino.ui.chips.ChipsGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.chips.ChipsGroup$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasSelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Chip = goog.forwardDeclare('org.dominokit.domino.ui.chips.Chip$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, ChipsGroup>}
 * @implements {Switchable<ChipsGroup>}
 * @implements {HasSelectionHandler<ChipsGroup, Chip>}
  */
class ChipsGroup extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_chips_ChipsGroup_;
    /** @public {List<Chip>} */
    this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_;
    /** @public {Chip} */
    this.f_selectedChip__org_dominokit_domino_ui_chips_ChipsGroup_;
    /** @public {List<SelectionHandler<Chip>>} */
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_ChipsGroup_;
  }
  
  /**
   * @return {!ChipsGroup}
   * @public
   */
  static $create__() {
    ChipsGroup.$clinit();
    let $instance = new ChipsGroup();
    $instance.$ctor__org_dominokit_domino_ui_chips_ChipsGroup__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_chips_ChipsGroup__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_chips_ChipsGroup();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {ChipsGroup}
   * @public
   */
  static m_create__() {
    ChipsGroup.$clinit();
    return ChipsGroup.$create__();
  }
  
  /**
   * @param {Chip} chip
   * @return {ChipsGroup}
   * @public
   * @deprecated
   */
  m_addChip__org_dominokit_domino_ui_chips_Chip(chip) {
    return this.m_appendChild__org_dominokit_domino_ui_chips_Chip(chip);
  }
  
  /**
   * @param {Chip} chip
   * @return {ChipsGroup}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_chips_Chip(chip) {
    chip.m_setSelectable__boolean(true);
    chip.m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(SelectionHandler.$adapt(((/** ?string */ value) =>{
      for (let $iterator = this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.m_iterator__(); $iterator.m_hasNext__(); ) {
        let c = /**@type {Chip} */ ($Casts.$to($iterator.m_next__(), Chip));
        if (!$Objects.m_equals__java_lang_Object__java_lang_Object(c, chip)) {
          c.m_deselect__();
        }
      }
      this.f_selectedChip__org_dominokit_domino_ui_chips_ChipsGroup_ = chip;
      this.f_selectionHandlers__org_dominokit_domino_ui_chips_ChipsGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectionHandler<Chip> */ handler) =>{
        handler.m_onSelection__java_lang_Object(chip);
      })));
    })));
    this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.add(chip);
    this.f_element__org_dominokit_domino_ui_chips_ChipsGroup_.appendChild(chip.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {ChipsGroup}
   * @public
   */
  m_enable__() {
    this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Chip */ arg0) =>{
      arg0.m_enable__();
    })));
    return this;
  }
  
  /**
   * @override
   * @return {ChipsGroup}
   * @public
   */
  m_disable__() {
    this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Chip */ arg0) =>{
      arg0.m_disable__();
    })));
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.m_stream__().m_allMatch__java_util_function_Predicate(Predicate.$adapt(((/** Chip */ arg0) =>{
      return arg0.m_isEnabled__();
    })));
  }
  
  /**
   * @return {Chip}
   * @public
   */
  m_getSelectedChip__() {
    return this.f_selectedChip__org_dominokit_domino_ui_chips_ChipsGroup_;
  }
  
  /**
   * @override
   * @param {SelectionHandler<Chip>} selectionHandler
   * @return {ChipsGroup}
   * @public
   */
  m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(selectionHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_ChipsGroup_.add(selectionHandler);
    return this;
  }
  
  /**
   * @override
   * @param {SelectionHandler<Chip>} selectionHandler
   * @return {ChipsGroup}
   * @public
   */
  m_removeSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(selectionHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_ChipsGroup_.remove(selectionHandler);
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_chips_ChipsGroup_;
  }
  
  /**
   * @param {ColorScheme} colorScheme
   * @return {ChipsGroup}
   * @public
   */
  m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(colorScheme) {
    this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Chip */ chip) =>{
      chip.m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(colorScheme);
    })));
    return this;
  }
  
  /**
   * @param {number} index
   * @return {ChipsGroup}
   * @public
   */
  m_selectAt__int(index) {
    if (index >= 0 && index < this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.size()) {
      /**@type {Chip} */ ($Casts.$to(this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_.getAtIndex(index), Chip)).m_select__();
    }
    return this;
  }
  
  /**
   * @return {List<Chip>}
   * @public
   */
  m_getChips__() {
    return this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_chips_ChipsGroup() {
    this.f_element__org_dominokit_domino_ui_chips_ChipsGroup_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay));
    this.f_chips__org_dominokit_domino_ui_chips_ChipsGroup_ = /**@type {!ArrayList<Chip>} */ (ArrayList.$create__());
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_ChipsGroup_ = /**@type {!ArrayList<SelectionHandler<Chip>>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ChipsGroup.$clinit = (() =>{
    });
    ChipsGroup.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ChipsGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ChipsGroup);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Chip = goog.module.get('org.dominokit.domino.ui.chips.Chip$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(ChipsGroup, $Util.$makeClassName('org.dominokit.domino.ui.chips.ChipsGroup'));


Switchable.$markImplementor(ChipsGroup);
HasSelectionHandler.$markImplementor(ChipsGroup);


exports = ChipsGroup; 
//# sourceMappingURL=ChipsGroup.js.map