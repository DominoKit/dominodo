/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$CanCountTo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.CanCountTo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.counter.Counter.CanCountTo.$LambdaAdaptor');
const _HasInterval = goog.require('org.dominokit.domino.ui.counter.Counter.HasInterval');


// Re-exports the implementation.
var CanCountTo = goog.require('org.dominokit.domino.ui.counter.Counter.CanCountTo$impl');
exports = CanCountTo;
 