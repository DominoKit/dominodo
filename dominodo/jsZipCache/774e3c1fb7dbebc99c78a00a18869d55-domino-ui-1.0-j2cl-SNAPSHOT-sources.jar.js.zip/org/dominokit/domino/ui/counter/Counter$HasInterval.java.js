/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasInterval.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasInterval');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasIncrement = goog.require('org.dominokit.domino.ui.counter.Counter.HasIncrement');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.counter.Counter.HasInterval.$LambdaAdaptor');


// Re-exports the implementation.
var HasInterval = goog.require('org.dominokit.domino.ui.counter.Counter.HasInterval$impl');
exports = HasInterval;
 