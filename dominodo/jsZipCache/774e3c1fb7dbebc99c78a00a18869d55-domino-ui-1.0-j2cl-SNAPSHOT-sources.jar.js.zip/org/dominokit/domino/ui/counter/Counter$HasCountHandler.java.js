/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasCountHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasCountHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Counter = goog.require('org.dominokit.domino.ui.counter.Counter');
const _CountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.CountHandler');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.counter.Counter.HasCountHandler.$LambdaAdaptor');


// Re-exports the implementation.
var HasCountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.HasCountHandler$impl');
exports = HasCountHandler;
 