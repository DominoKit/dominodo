/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $1 = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.$1$impl');
let CanCountTo = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CanCountTo$impl');
let CountHandler = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');
let CounterBuilder = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CounterBuilder$impl');
let Timer = goog.forwardDeclare('org.gwtproject.timer.client.Timer$impl');


class Counter extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Timer} */
    this.f_timer__org_dominokit_domino_ui_counter_Counter_;
    /** @public {number} */
    this.f_countFrom__org_dominokit_domino_ui_counter_Counter_ = 0;
    /** @public {number} */
    this.f_countTo__org_dominokit_domino_ui_counter_Counter_ = 0;
    /** @public {number} */
    this.f_interval__org_dominokit_domino_ui_counter_Counter_ = 0;
    /** @public {number} */
    this.f_increment__org_dominokit_domino_ui_counter_Counter_ = 0;
    /** @public {number} */
    this.f_currentValue__org_dominokit_domino_ui_counter_Counter_ = 0;
    /** @public {CountHandler} */
    this.f_countHandler__org_dominokit_domino_ui_counter_Counter_;
  }
  
  /**
   * @param {number} countFrom
   * @param {number} countTo
   * @param {number} interval
   * @param {number} increment
   * @param {CountHandler} countHandler
   * @return {!Counter}
   * @public
   */
  static $create__int__int__int__int__org_dominokit_domino_ui_counter_Counter_CountHandler(countFrom, countTo, interval, increment, countHandler) {
    Counter.$clinit();
    let $instance = new Counter();
    $instance.$ctor__org_dominokit_domino_ui_counter_Counter__int__int__int__int__org_dominokit_domino_ui_counter_Counter_CountHandler(countFrom, countTo, interval, increment, countHandler);
    return $instance;
  }
  
  /**
   * @param {number} countFrom
   * @param {number} countTo
   * @param {number} interval
   * @param {number} increment
   * @param {CountHandler} countHandler
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_counter_Counter__int__int__int__int__org_dominokit_domino_ui_counter_Counter_CountHandler(countFrom, countTo, interval, increment, countHandler) {
    this.$ctor__java_lang_Object__();
    this.f_countFrom__org_dominokit_domino_ui_counter_Counter_ = countFrom;
    this.f_countTo__org_dominokit_domino_ui_counter_Counter_ = countTo;
    this.f_interval__org_dominokit_domino_ui_counter_Counter_ = interval;
    this.f_increment__org_dominokit_domino_ui_counter_Counter_ = increment;
    this.f_countHandler__org_dominokit_domino_ui_counter_Counter_ = countHandler;
    this.m_initTimer___$p_org_dominokit_domino_ui_counter_Counter();
  }
  
  /**
   * @param {number} countFrom
   * @return {CanCountTo}
   * @public
   */
  static m_countFrom__int(countFrom) {
    Counter.$clinit();
    return CounterBuilder.$create__int(countFrom);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initTimer___$p_org_dominokit_domino_ui_counter_Counter() {
    this.f_timer__org_dominokit_domino_ui_counter_Counter_ = $1.$create__org_dominokit_domino_ui_counter_Counter(this);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_notifyCount___$p_org_dominokit_domino_ui_counter_Counter() {
    if (this.f_currentValue__org_dominokit_domino_ui_counter_Counter_ <= this.f_countTo__org_dominokit_domino_ui_counter_Counter_) {
      this.f_countHandler__org_dominokit_domino_ui_counter_Counter_.m_onCount__int(this.f_currentValue__org_dominokit_domino_ui_counter_Counter_);
    } else {
      this.f_countHandler__org_dominokit_domino_ui_counter_Counter_.m_onCount__int(this.f_countTo__org_dominokit_domino_ui_counter_Counter_);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_startCounting__() {
    if (this.f_timer__org_dominokit_domino_ui_counter_Counter_.m_isRunning__()) {
      this.f_timer__org_dominokit_domino_ui_counter_Counter_.m_cancel__();
    }
    this.f_currentValue__org_dominokit_domino_ui_counter_Counter_ = this.f_countFrom__org_dominokit_domino_ui_counter_Counter_;
    this.f_countHandler__org_dominokit_domino_ui_counter_Counter_.m_onCount__int(this.f_countFrom__org_dominokit_domino_ui_counter_Counter_);
    this.f_timer__org_dominokit_domino_ui_counter_Counter_.m_scheduleRepeating__int(this.f_interval__org_dominokit_domino_ui_counter_Counter_);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Counter.$clinit = (() =>{
    });
    Counter.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Counter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Counter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $1 = goog.module.get('org.dominokit.domino.ui.counter.Counter.$1$impl');
    CounterBuilder = goog.module.get('org.dominokit.domino.ui.counter.Counter.CounterBuilder$impl');
  }
  
  
};

$Util.$setClassMetadata(Counter, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter'));




exports = Counter; 
//# sourceMappingURL=Counter.js.map