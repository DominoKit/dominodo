/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasCountHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasCountHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Counter = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter$impl');
let CountHandler = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.HasCountHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasCountHandler {
  /**
   * @abstract
   * @param {CountHandler} handler
   * @return {Counter}
   * @public
   */
  m_onCount__org_dominokit_domino_ui_counter_Counter_CountHandler(handler) {
  }
  
  /**
   * @param {?function(CountHandler):Counter} fn
   * @return {HasCountHandler}
   * @public
   */
  static $adapt(fn) {
    HasCountHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasCountHandler.$clinit = (() =>{
    });
    HasCountHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_HasCountHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_counter_Counter_HasCountHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_HasCountHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.counter.Counter.HasCountHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasCountHandler, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$HasCountHandler'));


HasCountHandler.$markImplementor(/** @type {Function} */ (HasCountHandler));


exports = HasCountHandler; 
//# sourceMappingURL=Counter$HasCountHandler.js.map