/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$CountHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CountHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CountHandler {
  /**
   * @abstract
   * @param {number} count
   * @return {void}
   * @public
   */
  m_onCount__int(count) {
  }
  
  /**
   * @param {?function(number):void} fn
   * @return {CountHandler}
   * @public
   */
  static $adapt(fn) {
    CountHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CountHandler.$clinit = (() =>{
    });
    CountHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_CountHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_counter_Counter_CountHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_CountHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.counter.Counter.CountHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CountHandler, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$CountHandler'));


CountHandler.$markImplementor(/** @type {Function} */ (CountHandler));


exports = CountHandler; 
//# sourceMappingURL=Counter$CountHandler.js.map