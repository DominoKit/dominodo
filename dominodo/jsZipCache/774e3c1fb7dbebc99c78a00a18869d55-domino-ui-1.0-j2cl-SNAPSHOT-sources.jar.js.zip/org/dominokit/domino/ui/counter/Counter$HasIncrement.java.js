/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasIncrement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasIncrement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasCountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.HasCountHandler');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.counter.Counter.HasIncrement.$LambdaAdaptor');


// Re-exports the implementation.
var HasIncrement = goog.require('org.dominokit.domino.ui.counter.Counter.HasIncrement$impl');
exports = HasIncrement;
 