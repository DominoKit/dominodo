/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasInterval.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasInterval$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HasIncrement = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.HasIncrement$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.HasInterval.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasInterval {
  /**
   * @abstract
   * @param {number} interval
   * @return {HasIncrement}
   * @public
   */
  m_every__int(interval) {
  }
  
  /**
   * @param {?function(number):HasIncrement} fn
   * @return {HasInterval}
   * @public
   */
  static $adapt(fn) {
    HasInterval.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasInterval.$clinit = (() =>{
    });
    HasInterval.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_HasInterval = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_counter_Counter_HasInterval;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_HasInterval;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.counter.Counter.HasInterval.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasInterval, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$HasInterval'));


HasInterval.$markImplementor(/** @type {Function} */ (HasInterval));


exports = HasInterval; 
//# sourceMappingURL=Counter$HasInterval.js.map