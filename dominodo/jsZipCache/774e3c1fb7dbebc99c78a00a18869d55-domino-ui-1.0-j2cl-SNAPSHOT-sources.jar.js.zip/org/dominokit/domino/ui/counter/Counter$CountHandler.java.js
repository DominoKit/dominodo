/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$CountHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.CountHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.counter.Counter.CountHandler.$LambdaAdaptor');


// Re-exports the implementation.
var CountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');
exports = CountHandler;
 