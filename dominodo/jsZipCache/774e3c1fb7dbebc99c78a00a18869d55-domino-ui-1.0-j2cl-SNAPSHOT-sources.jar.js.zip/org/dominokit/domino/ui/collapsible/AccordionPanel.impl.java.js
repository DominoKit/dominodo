/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.AccordionPanel.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.AccordionPanel$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible$impl');

let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, AccordionPanel>}
 * @implements {IsCollapsible<AccordionPanel>}
  */
class AccordionPanel extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {DominoElement<HTMLHeadingElement>} */
    this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {DominoElement<HTMLAnchorElement>} */
    this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {?string} */
    this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_;
    /** @public {BaseIcon<?>} */
    this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_;
  }
  
  /**
   * Factory method corresponding to constructor 'AccordionPanel(String)'.
   * @param {?string} title
   * @return {!AccordionPanel}
   * @public
   */
  static $create__java_lang_String(title) {
    AccordionPanel.$clinit();
    let $instance = new AccordionPanel();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String(title);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccordionPanel(String)'.
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String(title) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_collapsible_AccordionPanel();
    this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_setTextContent__java_lang_String(title);
    this.m_init___$p_org_dominokit_domino_ui_collapsible_AccordionPanel();
  }
  
  /**
   * Factory method corresponding to constructor 'AccordionPanel(String, Node)'.
   * @param {?string} title
   * @param {Node} content
   * @return {!AccordionPanel}
   * @public
   */
  static $create__java_lang_String__elemental2_dom_Node(title, content) {
    AccordionPanel.$clinit();
    let $instance = new AccordionPanel();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String__elemental2_dom_Node(title, content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AccordionPanel(String, Node)'.
   * @param {?string} title
   * @param {Node} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_AccordionPanel__java_lang_String__elemental2_dom_Node(title, content) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_collapsible_AccordionPanel();
    this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_setTextContent__java_lang_String(title);
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__elemental2_dom_Node(content);
    this.m_init___$p_org_dominokit_domino_ui_collapsible_AccordionPanel();
  }
  
  /**
   * @param {?string} title
   * @return {AccordionPanel}
   * @public
   */
  static m_create__java_lang_String(title) {
    AccordionPanel.$clinit();
    return AccordionPanel.$create__java_lang_String(title);
  }
  
  /**
   * @param {?string} title
   * @param {Node} content
   * @return {AccordionPanel}
   * @public
   */
  static m_create__java_lang_String__elemental2_dom_Node(title, content) {
    AccordionPanel.$clinit();
    return AccordionPanel.$create__java_lang_String__elemental2_dom_Node(title, content);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_init___$p_org_dominokit_domino_ui_collapsible_AccordionPanel() {
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    this.m_collapse__();
  }
  
  /**
   * @param {?string} title
   * @return {AccordionPanel}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_setTextContent__java_lang_String(title);
    return this;
  }
  
  /**
   * @override
   * @param {Node} content
   * @return {AccordionPanel}
   * @public
   */
  m_setContent__elemental2_dom_Node(content) {
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_setTextContent__java_lang_String("");
    return this.m_appendChild__elemental2_dom_Node(content);
  }
  
  /**
   * @param {Node} content
   * @return {AccordionPanel}
   * @public
   * @deprecated
   */
  m_appendContent__elemental2_dom_Node(content) {
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__elemental2_dom_Node(content);
    return this;
  }
  
  /**
   * @override
   * @param {Node} content
   * @return {AccordionPanel}
   * @public
   */
  m_appendChild__elemental2_dom_Node(content) {
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_appendChild__elemental2_dom_Node(content);
    return this;
  }
  
  /**
   * @override
   * @param {IsElement} content
   * @return {AccordionPanel}
   * @public
   */
  m_appendChild__org_jboss_gwt_elemento_core_IsElement(content) {
    return this.m_appendChild__elemental2_dom_Node(content.m_asElement__());
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_asElement__(), $Overlay));
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_primary__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-primary");
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_success__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-success");
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_warning__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-warning");
  }
  
  /**
   * @return {AccordionPanel}
   * @public
   */
  m_danger__() {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible("panel-danger");
  }
  
  /**
   * @param {Color} color
   * @return {AccordionPanel}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    return this.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible(color.m_getStyle__());
  }
  
  /**
   * @param {?string} style
   * @return {AccordionPanel}
   * @public
   */
  m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible(style) {
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_style__().m_remove__java_lang_String(this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_ = style;
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_style__().m_add__java_lang_String(this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_);
    return this;
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {AccordionPanel}
   * @public
   */
  m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    if (Objects.m_nonNull__java_lang_Object(this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_)) {
      this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_remove__();
    }
    this.f_panelIcon__org_dominokit_domino_ui_collapsible_AccordionPanel_ = icon;
    this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_insertFirst__org_dominokit_domino_ui_utils_BaseDominoElement(icon);
    return this;
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getBody__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_));
  }
  
  /**
   * @override
   * @return {HTMLAnchorElement}
   * @public
   */
  m_getClickableElement__() {
    return /**@type {HTMLAnchorElement} */ ($Casts.$to(this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_asElement__(), HTMLAnchorElement_$Overlay));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_getCollapsibleElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_.m_asElement__(), $Overlay));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_collapsible_AccordionPanel() {
    this.f_element__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel panel-primary"], j_l_String)))));
    this.f_headerElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-heading"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "tab")));
    this.f_headingElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {DominoElement<HTMLHeadingElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_h__int(4).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-title"], j_l_String)))));
    this.f_clickableElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_a__().m_attr__java_lang_String__java_lang_String("role", "button")));
    this.f_collapsibleElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-collapse"], j_l_String)))));
    this.f_bodyElement__org_dominokit_domino_ui_collapsible_AccordionPanel_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-body"], j_l_String)))));
    this.f_panelStyle__org_dominokit_domino_ui_collapsible_AccordionPanel_ = "panel-primary";
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AccordionPanel.$clinit = (() =>{
    });
    AccordionPanel.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AccordionPanel;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AccordionPanel);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(AccordionPanel, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.AccordionPanel'));


IsCollapsible.$markImplementor(AccordionPanel);


exports = AccordionPanel; 
//# sourceMappingURL=AccordionPanel.js.map