/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const StoreDataChangeListener = goog.require('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');

let DataChangedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');


/**
 * @template C_T
 * @implements {StoreDataChangeListener<C_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(DataChangedEvent<C_T>):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(DataChangedEvent<C_T>):void} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(DataChangedEvent<C_T>):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {DataChangedEvent<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onDataChanged__org_dominokit_domino_ui_datatable_store_DataChangedEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$$LambdaAdaptor'));


StoreDataChangeListener.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=StoreDataChangeListener$$LambdaAdaptor.js.map