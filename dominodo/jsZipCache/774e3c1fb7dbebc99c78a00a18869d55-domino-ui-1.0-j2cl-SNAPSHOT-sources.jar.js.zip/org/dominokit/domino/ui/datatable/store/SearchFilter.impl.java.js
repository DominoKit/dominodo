/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.SearchFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.SearchFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let SearchEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.SearchFilter.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 */
class SearchFilter {
  /**
   * @abstract
   * @param {SearchEvent} event
   * @param {C_T} record
   * @return {boolean}
   * @public
   */
  m_filterRecord__org_dominokit_domino_ui_datatable_events_SearchEvent__java_lang_Object(event, record) {
  }
  
  /**
   * @template C_T
   * @param {?function(SearchEvent, C_T):boolean} fn
   * @return {SearchFilter<C_T>}
   * @public
   */
  static $adapt(fn) {
    SearchFilter.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SearchFilter.$clinit = (() =>{
    });
    SearchFilter.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_SearchFilter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_store_SearchFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_SearchFilter;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.store.SearchFilter.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SearchFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.SearchFilter'));


SearchFilter.$markImplementor(/** @type {Function} */ (SearchFilter));


exports = SearchFilter; 
//# sourceMappingURL=SearchFilter.js.map