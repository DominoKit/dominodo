/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _$Overlay = goog.require('elemental2.dom.Document.$Overlay');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _HTMLTableCellElement_$Overlay = goog.require('elemental2.dom.HTMLTableCellElement.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _CellRenderer = goog.require('org.dominokit.domino.ui.datatable.CellRenderer');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _CellStyler = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _MarkerColor = goog.require('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');


// Re-exports the implementation.
var RowMarkerPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$impl');
exports = RowMarkerPlugin;
 