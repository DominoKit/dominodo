/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.TableConfig.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.TableConfig');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HasMultiSelectionSupport = goog.require('org.dominokit.domino.ui.utils.HasMultiSelectionSupport');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLTableCellElement_$Overlay = goog.require('elemental2.dom.HTMLTableCellElement.$Overlay');
const _HTMLTableSectionElement_$Overlay = goog.require('elemental2.dom.HTMLTableSectionElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _RowCell = goog.require('org.dominokit.domino.ui.datatable.RowCell');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _Tooltip = goog.require('org.dominokit.domino.ui.popover.Tooltip');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TableConfig = goog.require('org.dominokit.domino.ui.datatable.TableConfig$impl');
exports = TableConfig;
 