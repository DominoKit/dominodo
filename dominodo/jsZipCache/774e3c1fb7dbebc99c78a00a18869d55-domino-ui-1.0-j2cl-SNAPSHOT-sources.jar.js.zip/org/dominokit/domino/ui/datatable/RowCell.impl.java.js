/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.RowCell.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.RowCell$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');


/**
 * @template C_T
  */
class RowCell extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {ColumnConfig<C_T>} */
    this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_;
    /** @public {CellInfo<C_T>} */
    this.f_cellInfo__org_dominokit_domino_ui_datatable_RowCell_;
  }
  
  /**
   * @template C_T
   * @param {CellInfo<C_T>} cellInfo
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {!RowCell<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo__org_dominokit_domino_ui_datatable_ColumnConfig(cellInfo, columnConfig) {
    RowCell.$clinit();
    let $instance = new RowCell();
    $instance.$ctor__org_dominokit_domino_ui_datatable_RowCell__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo__org_dominokit_domino_ui_datatable_ColumnConfig(cellInfo, columnConfig);
    return $instance;
  }
  
  /**
   * @param {CellInfo<C_T>} cellInfo
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_RowCell__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo__org_dominokit_domino_ui_datatable_ColumnConfig(cellInfo, columnConfig) {
    this.$ctor__java_lang_Object__();
    this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_ = columnConfig;
    this.f_cellInfo__org_dominokit_domino_ui_datatable_RowCell_ = cellInfo;
  }
  
  /**
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_getColumnConfig__() {
    return this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updateCell__() {
    ElementUtil.m_clear__elemental2_dom_Element(this.f_cellInfo__org_dominokit_domino_ui_datatable_RowCell_.m_getElement__());
    let style = /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_cellInfo__org_dominokit_domino_ui_datatable_RowCell_.m_getElement__()));
    if (Objects.m_nonNull__java_lang_Object(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getMinWidth__())) {
      style.m_setMinWidth__java_lang_String(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getMinWidth__());
      this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getHeadElement__().m_style__().m_setMinWidth__java_lang_String(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getMinWidth__());
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getMaxWidth__())) {
      style.m_setMaxWidth__java_lang_String(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getMaxWidth__());
      this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getHeadElement__().m_style__().m_setMaxWidth__java_lang_String(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getMaxWidth__());
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getTextAlign__())) {
      style.m_setTextAlign__java_lang_String(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getTextAlign__());
      this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getHeadElement__().m_style__().m_setTextAlign__java_lang_String(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getTextAlign__());
    }
    this.f_cellInfo__org_dominokit_domino_ui_datatable_RowCell_.m_getElement__().appendChild(this.f_columnConfig__org_dominokit_domino_ui_datatable_RowCell_.m_getCellRenderer__().m_asElement__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(this.f_cellInfo__org_dominokit_domino_ui_datatable_RowCell_));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RowCell.$clinit = (() =>{
    });
    RowCell.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RowCell;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RowCell);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Objects = goog.module.get('java.util.Objects$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
  }
  
  
};

$Util.$setClassMetadata(RowCell, $Util.$makeClassName('org.dominokit.domino.ui.datatable.RowCell'));




exports = RowCell; 
//# sourceMappingURL=RowCell.js.map