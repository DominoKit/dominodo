/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.SortPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.SortPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _SortEvent = goog.require('org.dominokit.domino.ui.datatable.events.SortEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _$LambdaAdaptor$32 = goog.require('org.dominokit.domino.ui.datatable.plugins.SortPlugin.$LambdaAdaptor$32');
const _SortContainer = goog.require('org.dominokit.domino.ui.datatable.plugins.SortPlugin.SortContainer');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Arrays = goog.require('vmbootstrap.Arrays');


// Re-exports the implementation.
var SortPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.SortPlugin$impl');
exports = SortPlugin;
 