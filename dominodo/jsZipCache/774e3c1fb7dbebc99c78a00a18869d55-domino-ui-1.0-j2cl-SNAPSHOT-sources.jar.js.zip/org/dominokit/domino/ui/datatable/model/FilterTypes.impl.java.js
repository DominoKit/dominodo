/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.FilterTypes.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<FilterTypes>}
  */
class FilterTypes extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!FilterTypes}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new FilterTypes();
    $instance.$ctor__org_dominokit_domino_ui_datatable_model_FilterTypes__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_model_FilterTypes__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!FilterTypes}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    FilterTypes.$clinit();
    if ($Equality.$same(FilterTypes.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_, null)) {
      FilterTypes.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_ = $Enums.createMapFromValues(FilterTypes.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, FilterTypes.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_);
  }
  
  /**
   * @return {!Array<!FilterTypes>}
   * @public
   */
  static m_values__() {
    FilterTypes.$clinit();
    return /**@type {!Array<FilterTypes>} */ ($Arrays.$init([FilterTypes.$f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes, FilterTypes.$f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes], FilterTypes));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {FilterTypes} */ ($Casts.$to(arg0, FilterTypes)));
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {!FilterTypes}
   * @public
   */
  static get f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes() {
    return (FilterTypes.$clinit(), FilterTypes.$f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes);
  }
  
  /**
   * @param {!FilterTypes} value
   * @return {void}
   * @public
   */
  static set f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes = value);
  }
  
  /**
   * @return {Map<?string, !FilterTypes>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_() {
    return (FilterTypes.$clinit(), FilterTypes.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_);
  }
  
  /**
   * @param {Map<?string, !FilterTypes>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_(value) {
    (FilterTypes.$clinit(), FilterTypes.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    FilterTypes.$clinit = (() =>{
    });
    FilterTypes.$loadModules();
    Enum.$clinit();
    FilterTypes.$f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("STRING"), FilterTypes.$ordinal$f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("INTEGER"), FilterTypes.$ordinal$f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("LONG"), FilterTypes.$ordinal$f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("DOUBLE"), FilterTypes.$ordinal$f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("SHORT"), FilterTypes.$ordinal$f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("FLOAT"), FilterTypes.$ordinal$f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("DECIMAL"), FilterTypes.$ordinal$f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("BOOLEAN"), FilterTypes.$ordinal$f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("DATE"), FilterTypes.$ordinal$f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes = FilterTypes.$create__java_lang_String__int($Util.$makeEnumName("ENUM"), FilterTypes.$ordinal$f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes);
    FilterTypes.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FilterTypes;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FilterTypes);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(FilterTypes, $Util.$makeClassName('org.dominokit.domino.ui.datatable.model.FilterTypes'));


/** @private {!FilterTypes} */
FilterTypes.$f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {!FilterTypes} */
FilterTypes.$f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes;


/** @private {Map<?string, !FilterTypes>} */
FilterTypes.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_FilterTypes_;


/** @public {number} @const */
FilterTypes.$ordinal$f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes = 0;


/** @public {number} @const */
FilterTypes.$ordinal$f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes = 1;


/** @public {number} @const */
FilterTypes.$ordinal$f_LONG__org_dominokit_domino_ui_datatable_model_FilterTypes = 2;


/** @public {number} @const */
FilterTypes.$ordinal$f_DOUBLE__org_dominokit_domino_ui_datatable_model_FilterTypes = 3;


/** @public {number} @const */
FilterTypes.$ordinal$f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes = 4;


/** @public {number} @const */
FilterTypes.$ordinal$f_FLOAT__org_dominokit_domino_ui_datatable_model_FilterTypes = 5;


/** @public {number} @const */
FilterTypes.$ordinal$f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes = 6;


/** @public {number} @const */
FilterTypes.$ordinal$f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes = 7;


/** @public {number} @const */
FilterTypes.$ordinal$f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes = 8;


/** @public {number} @const */
FilterTypes.$ordinal$f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes = 9;




exports = FilterTypes; 
//# sourceMappingURL=FilterTypes.js.map