/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.ColumnConfig$CellStyler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_CellStyler_T
 */
class CellStyler {
  /**
   * @abstract
   * @param {HTMLTableCellElement} element
   * @return {void}
   * @public
   */
  m_styleCell__elemental2_dom_HTMLTableCellElement(element) {
  }
  
  /**
   * @template C_CellStyler_T
   * @param {?function(HTMLTableCellElement):void} fn
   * @return {CellStyler<C_CellStyler_T>}
   * @public
   */
  static $adapt(fn) {
    CellStyler.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CellStyler.$clinit = (() =>{
    });
    CellStyler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CellStyler, $Util.$makeClassName('org.dominokit.domino.ui.datatable.ColumnConfig$CellStyler'));


CellStyler.$markImplementor(/** @type {Function} */ (CellStyler));


exports = CellStyler; 
//# sourceMappingURL=ColumnConfig$CellStyler.js.map