/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin$DoublClickHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.DoublClickHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DoublClickHandler = goog.require('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.DoublClickHandler$impl');

let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @template C_DoublClickHandler_T
 * @implements {DoublClickHandler<C_DoublClickHandler_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(TableRow<C_DoublClickHandler_T>):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(TableRow<C_DoublClickHandler_T>):void} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler_$LambdaAdaptor__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler_$JsFunction(fn);
  }
  
  /**
   * @param {?function(TableRow<C_DoublClickHandler_T>):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler_$LambdaAdaptor__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {TableRow<C_DoublClickHandler_T>} arg0
   * @return {void}
   * @public
   */
  m_onDoubleClick__org_dominokit_domino_ui_datatable_TableRow(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin$DoublClickHandler$$LambdaAdaptor'));


DoublClickHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DoubleClickPlugin$DoublClickHandler$$LambdaAdaptor.js.map