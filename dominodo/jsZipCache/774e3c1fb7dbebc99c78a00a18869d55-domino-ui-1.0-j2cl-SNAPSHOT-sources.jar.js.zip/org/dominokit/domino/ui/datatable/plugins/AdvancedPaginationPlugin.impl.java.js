/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.AdvancedPaginationPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.AdvancedPaginationPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let TablePageChangeEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent$impl');
let AdvancedPagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.AdvancedPagination$impl');
let PageChangedCallBack = goog.forwardDeclare('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class AdvancedPaginationPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {AdvancedPagination} */
    this.f_pagination__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin_;
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedPaginationPlugin()'.
   * @template C_T
   * @return {!AdvancedPaginationPlugin<C_T>}
   * @public
   */
  static $create__() {
    AdvancedPaginationPlugin.$clinit();
    let $instance = new AdvancedPaginationPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedPaginationPlugin()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin__() {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin__int(10);
  }
  
  /**
   * Factory method corresponding to constructor 'AdvancedPaginationPlugin(int)'.
   * @template C_T
   * @param {number} pageSize
   * @return {!AdvancedPaginationPlugin<C_T>}
   * @public
   */
  static $create__int(pageSize) {
    AdvancedPaginationPlugin.$clinit();
    let $instance = new AdvancedPaginationPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin__int(pageSize);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'AdvancedPaginationPlugin(int)'.
   * @param {number} pageSize
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin__int(pageSize) {
    this.$ctor__java_lang_Object__();
    this.f_pagination__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin_ = AdvancedPagination.m_create__int__int(0, pageSize);
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    dataTable.m_asElement__().appendChild(this.f_pagination__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin_.m_asElement__());
    this.f_pagination__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin_.m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      dataTable.m_fireTableEvent__org_dominokit_domino_ui_datatable_events_TableEvent(TablePageChangeEvent.$create__int__org_dominokit_domino_ui_pagination_HasPagination(pageNumber, this.f_pagination__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin_));
    })));
  }
  
  /**
   * @return {AdvancedPagination}
   * @public
   */
  m_getPagination__() {
    return this.f_pagination__org_dominokit_domino_ui_datatable_plugins_AdvancedPaginationPlugin_;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    DataTablePlugin.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AdvancedPaginationPlugin.$clinit = (() =>{
    });
    AdvancedPaginationPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AdvancedPaginationPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AdvancedPaginationPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    TablePageChangeEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent$impl');
    AdvancedPagination = goog.module.get('org.dominokit.domino.ui.pagination.AdvancedPagination$impl');
    PageChangedCallBack = goog.module.get('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack$impl');
  }
  
  
};

$Util.$setClassMetadata(AdvancedPaginationPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.AdvancedPaginationPlugin'));


DataTablePlugin.$markImplementor(AdvancedPaginationPlugin);


exports = AdvancedPaginationPlugin; 
//# sourceMappingURL=AdvancedPaginationPlugin.js.map