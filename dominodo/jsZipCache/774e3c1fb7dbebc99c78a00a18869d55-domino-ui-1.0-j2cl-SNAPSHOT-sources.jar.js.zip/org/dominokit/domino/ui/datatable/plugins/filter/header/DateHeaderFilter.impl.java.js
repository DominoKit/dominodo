/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.DateHeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.DateHeaderFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let SearchContext = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.SearchContext$impl');
let DateBox = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox$impl');
let PickerStyle = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
let DateDayClickedHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {HeaderFilter<C_T>}
  */
class DateHeaderFilter extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DateBox} */
    this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_;
  }
  
  /**
   * @template M_T
   * @return {DateHeaderFilter<M_T>}
   * @public
   */
  static m_create__() {
    DateHeaderFilter.$clinit();
    return /**@type {!DateHeaderFilter<*>} */ (DateHeaderFilter.$create__());
  }
  
  /**
   * @template C_T
   * @return {!DateHeaderFilter<C_T>}
   * @public
   */
  static $create__() {
    DateHeaderFilter.$clinit();
    let $instance = new DateHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter__() {
    this.$ctor__java_lang_Object__();
    this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_ = /**@type {DateBox} */ ($Casts.$to(/**@type {DateBox} */ ($Casts.$to(DateBox.m_create__().m_setPlaceholder__java_lang_String("Search").m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** DateBox */ element) =>{
      element.m_getDatePicker__().m_hideHeaderPanel__();
      element.m_getDatePicker__().m_addDateDayClickHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler(DateDayClickedHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
        element.m_close__();
      })));
    }))), DateBox)).m_setPickerStyle__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle(PickerStyle.f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle).m_setPopoverPosition__org_dominokit_domino_ui_popover_PopupPosition(PopupPosition.f_TOP_DOWN__org_dominokit_domino_ui_popover_PopupPosition).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, DateBox> */ style) =>{
      style.m_setMarginBottom__java_lang_String("0px");
    }))), DateBox));
  }
  
  /**
   * @return {DateBox}
   * @public
   */
  m_getDateBox__() {
    return this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_;
  }
  
  /**
   * @override
   * @param {SearchContext<C_T>} searchContext
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_ColumnConfig(searchContext, columnConfig) {
    this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** Date */ value) =>{
      if (this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_.m_isEmpty__()) {
        searchContext.m_remove__java_lang_String__org_dominokit_domino_ui_datatable_model_Category(columnConfig.m_getName__(), Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category);
        searchContext.m_fireSearchEvent__();
      } else {
        searchContext.m_add__org_dominokit_domino_ui_datatable_model_Filter(Filter.m_create__java_lang_String__java_lang_String__org_dominokit_domino_ui_datatable_model_Category__org_dominokit_domino_ui_datatable_model_FilterTypes(columnConfig.m_getName__(), this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_.m_getValue__().m_getTime__() + "", Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category, FilterTypes.f_DATE__org_dominokit_domino_ui_datatable_model_FilterTypes));
        searchContext.m_fireSearchEvent__();
      }
    })));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_.m_pauseChangeHandlers__();
    this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_.m_clear__();
    this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_.m_resumeChangeHandlers__();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_dateBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DateHeaderFilter_.m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateHeaderFilter.$clinit = (() =>{
    });
    DateHeaderFilter.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateHeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateHeaderFilter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Category = goog.module.get('org.dominokit.domino.ui.datatable.model.Category$impl');
    Filter = goog.module.get('org.dominokit.domino.ui.datatable.model.Filter$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    DateBox = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox$impl');
    PickerStyle = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
    DateDayClickedHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(DateHeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.DateHeaderFilter'));


HeaderFilter.$markImplementor(DateHeaderFilter);


exports = DateHeaderFilter; 
//# sourceMappingURL=DateHeaderFilter.js.map