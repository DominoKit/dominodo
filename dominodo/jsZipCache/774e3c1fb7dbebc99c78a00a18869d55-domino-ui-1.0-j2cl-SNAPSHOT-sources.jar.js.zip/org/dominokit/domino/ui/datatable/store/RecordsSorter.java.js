/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.RecordsSorter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.store.RecordsSorter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Comparator = goog.require('java.util.Comparator');
const _SortDirection = goog.require('org.dominokit.domino.ui.datatable.plugins.SortDirection');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.store.RecordsSorter.$LambdaAdaptor');


// Re-exports the implementation.
var RecordsSorter = goog.require('org.dominokit.domino.ui.datatable.store.RecordsSorter$impl');
exports = RecordsSorter;
 