/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.RowCell.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.RowCell');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLTableCellElement.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');


// Re-exports the implementation.
var RowCell = goog.require('org.dominokit.domino.ui.datatable.RowCell$impl');
exports = RowCell;
 