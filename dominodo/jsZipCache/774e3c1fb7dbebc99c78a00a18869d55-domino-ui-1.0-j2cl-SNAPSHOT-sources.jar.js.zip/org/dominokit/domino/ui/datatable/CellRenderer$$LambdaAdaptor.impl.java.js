/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.CellRenderer$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.CellRenderer.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CellRenderer = goog.require('org.dominokit.domino.ui.datatable.CellRenderer$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');


/**
 * @template C_T
 * @implements {CellRenderer<C_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(CellInfo<C_T>):Node} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(CellInfo<C_T>):Node} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_CellRenderer_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_CellRenderer_$LambdaAdaptor__org_dominokit_domino_ui_datatable_CellRenderer_$JsFunction(fn);
  }
  
  /**
   * @param {?function(CellInfo<C_T>):Node} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_CellRenderer_$LambdaAdaptor__org_dominokit_domino_ui_datatable_CellRenderer_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_CellRenderer_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {CellInfo<C_T>} arg0
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(arg0) {
    let /** ?function(CellInfo<C_T>):Node */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_datatable_CellRenderer_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.CellRenderer$$LambdaAdaptor'));


CellRenderer.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=CellRenderer$$LambdaAdaptor.js.map