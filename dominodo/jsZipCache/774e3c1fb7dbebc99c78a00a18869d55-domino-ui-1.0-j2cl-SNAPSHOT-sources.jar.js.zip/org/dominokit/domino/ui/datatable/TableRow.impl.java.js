/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.TableRow.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.TableRow$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableRowElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let RowCell = goog.forwardDeclare('org.dominokit.domino.ui.datatable.RowCell$impl');
let RowListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow.RowListener$impl');
let RowMetaObject = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Selectable.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseDominoElement<HTMLTableRowElement, TableRow<C_T>>}
 * @implements {Selectable<C_T>}
  */
class TableRow extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {C_T} */
    this.f_record__org_dominokit_domino_ui_datatable_TableRow_;
    /** @public {boolean} */
    this.f_selected__org_dominokit_domino_ui_datatable_TableRow_ = false;
    /** @public {number} */
    this.f_index__org_dominokit_domino_ui_datatable_TableRow_ = 0;
    /** @public {Map<?string, RowCell<C_T>>} */
    this.f_rowCells__org_dominokit_domino_ui_datatable_TableRow_;
    /** @public {Map<?string, ?string>} */
    this.f_flags__org_dominokit_domino_ui_datatable_TableRow_;
    /** @public {Map<?string, RowMetaObject>} */
    this.f_metaObjects__org_dominokit_domino_ui_datatable_TableRow_;
    /** @public {HTMLTableRowElement} */
    this.f_element__org_dominokit_domino_ui_datatable_TableRow_;
    /** @public {List<SelectionHandler<C_T>>} */
    this.f_selectionHandlers__org_dominokit_domino_ui_datatable_TableRow_;
    /** @public {List<RowListener<C_T>>} */
    this.f_listeners__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @template C_T
   * @param {C_T} record
   * @param {number} index
   * @return {!TableRow<C_T>}
   * @public
   */
  static $create__java_lang_Object__int(record, index) {
    TableRow.$clinit();
    let $instance = new TableRow();
    $instance.$ctor__org_dominokit_domino_ui_datatable_TableRow__java_lang_Object__int(record, index);
    return $instance;
  }
  
  /**
   * @param {C_T} record
   * @param {number} index
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_TableRow__java_lang_Object__int(record, index) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_datatable_TableRow();
    this.f_record__org_dominokit_domino_ui_datatable_TableRow_ = record;
    this.f_index__org_dominokit_domino_ui_datatable_TableRow_ = index;
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_select__() {
    if (!this.m_hasFalg__java_lang_String("data-table-row-filtered")) {
      this.f_selected__org_dominokit_domino_ui_datatable_TableRow_ = true;
      this.f_selectionHandlers__org_dominokit_domino_ui_datatable_TableRow_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectionHandler<*> */ selectionHandler) =>{
        selectionHandler.m_onSelectionChanged__org_dominokit_domino_ui_utils_Selectable(this);
      })));
    }
    return this.f_record__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_deselect__() {
    this.f_selected__org_dominokit_domino_ui_datatable_TableRow_ = false;
    this.f_selectionHandlers__org_dominokit_domino_ui_datatable_TableRow_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectionHandler<*> */ selectionHandler) =>{
      selectionHandler.m_onSelectionChanged__org_dominokit_domino_ui_utils_Selectable(this);
    })));
    return this.f_record__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {C_T}
   * @public
   */
  m_select__boolean(silent) {
    this.f_selected__org_dominokit_domino_ui_datatable_TableRow_ = true;
    return this.f_record__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @override
   * @param {boolean} silent
   * @return {C_T}
   * @public
   */
  m_deselect__boolean(silent) {
    this.f_selected__org_dominokit_domino_ui_datatable_TableRow_ = false;
    return this.f_record__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSelected__() {
    return this.f_selected__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @return {C_T}
   * @public
   */
  m_getRecord__() {
    return this.f_record__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @override
   * @param {SelectionHandler<C_T>} selectionHandler
   * @return {void}
   * @public
   */
  m_addSelectionHandler__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(selectionHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_datatable_TableRow_.add(selectionHandler);
  }
  
  /**
   * @param {RowListener<C_T>} listener
   * @return {void}
   * @public
   */
  m_addRowListener__org_dominokit_domino_ui_datatable_TableRow_RowListener(listener) {
    this.f_listeners__org_dominokit_domino_ui_datatable_TableRow_.add(listener);
  }
  
  /**
   * @param {RowListener<C_T>} listener
   * @return {void}
   * @public
   */
  m_removeListener__org_dominokit_domino_ui_datatable_TableRow_RowListener(listener) {
    this.f_listeners__org_dominokit_domino_ui_datatable_TableRow_.remove(listener);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_fireUpdate__() {
    this.f_listeners__org_dominokit_domino_ui_datatable_TableRow_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** RowListener<*> */ listener) =>{
      listener.m_onChange__org_dominokit_domino_ui_datatable_TableRow(this);
    })));
  }
  
  /**
   * @override
   * @return {HTMLTableRowElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @return {void}
   * @public
   */
  m_setFlag__java_lang_String__java_lang_String(name, value) {
    this.f_flags__org_dominokit_domino_ui_datatable_TableRow_.put(name, value);
  }
  
  /**
   * @param {?string} name
   * @return {?string}
   * @public
   */
  m_getFlag__java_lang_String(name) {
    return /**@type {?string} */ ($Casts.$to(this.f_flags__org_dominokit_domino_ui_datatable_TableRow_.get(name), j_l_String));
  }
  
  /**
   * @param {RowMetaObject} metaObject
   * @return {void}
   * @public
   */
  m_addMetaObject__org_dominokit_domino_ui_datatable_TableRow_RowMetaObject(metaObject) {
    this.f_metaObjects__org_dominokit_domino_ui_datatable_TableRow_.put(metaObject.m_getKey__(), metaObject);
  }
  
  /**
   * @template M_E
   * @param {?string} key
   * @return {M_E}
   * @public
   */
  m_getMetaObject__java_lang_String(key) {
    return /**@type {RowMetaObject} */ ($Casts.$to(this.f_metaObjects__org_dominokit_domino_ui_datatable_TableRow_.get(key), RowMetaObject));
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  m_removeFlag__java_lang_String(name) {
    this.f_flags__org_dominokit_domino_ui_datatable_TableRow_.remove(name);
  }
  
  /**
   * @param {?string} name
   * @return {boolean}
   * @public
   */
  m_hasFalg__java_lang_String(name) {
    return this.f_flags__org_dominokit_domino_ui_datatable_TableRow_.containsKey(name);
  }
  
  /**
   * @param {RowCell<C_T>} rowCell
   * @return {void}
   * @public
   */
  m_addCell__org_dominokit_domino_ui_datatable_RowCell(rowCell) {
    this.f_rowCells__org_dominokit_domino_ui_datatable_TableRow_.put(rowCell.m_getColumnConfig__().m_getName__(), rowCell);
  }
  
  /**
   * @param {?string} name
   * @return {RowCell<C_T>}
   * @public
   */
  m_getCell__java_lang_String(name) {
    return /**@type {RowCell<C_T>} */ ($Casts.$to(this.f_rowCells__org_dominokit_domino_ui_datatable_TableRow_.get(name), RowCell));
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getIndex__() {
    return this.f_index__org_dominokit_domino_ui_datatable_TableRow_;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updateRow__() {
    this.f_rowCells__org_dominokit_domino_ui_datatable_TableRow_.values().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** RowCell<*> */ arg0) =>{
      arg0.m_updateCell__();
    })));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_TableRow() {
    this.f_selected__org_dominokit_domino_ui_datatable_TableRow_ = false;
    this.f_rowCells__org_dominokit_domino_ui_datatable_TableRow_ = /**@type {!HashMap<?string, RowCell<C_T>>} */ (HashMap.$create__());
    this.f_flags__org_dominokit_domino_ui_datatable_TableRow_ = /**@type {!HashMap<?string, ?string>} */ (HashMap.$create__());
    this.f_metaObjects__org_dominokit_domino_ui_datatable_TableRow_ = /**@type {!HashMap<?string, RowMetaObject>} */ (HashMap.$create__());
    this.f_element__org_dominokit_domino_ui_datatable_TableRow_ = /**@type {HTMLTableRowElement} */ ($Casts.$to(Elements.m_tr__().m_asElement__(), $Overlay));
    this.f_selectionHandlers__org_dominokit_domino_ui_datatable_TableRow_ = /**@type {!ArrayList<SelectionHandler<C_T>>} */ (ArrayList.$create__());
    this.f_listeners__org_dominokit_domino_ui_datatable_TableRow_ = /**@type {!ArrayList<RowListener<C_T>>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TableRow.$clinit = (() =>{
    });
    TableRow.$loadModules();
    BaseDominoElement.$clinit();
    Selectable.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TableRow;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TableRow);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLTableRowElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    RowCell = goog.module.get('org.dominokit.domino.ui.datatable.RowCell$impl');
    RowMetaObject = goog.module.get('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TableRow, $Util.$makeClassName('org.dominokit.domino.ui.datatable.TableRow'));


Selectable.$markImplementor(TableRow);


exports = TableRow; 
//# sourceMappingURL=TableRow.js.map