/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasSelectionSupport = goog.require('org.dominokit.domino.ui.utils.HasSelectionSupport');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLTableElement_$Overlay = goog.require('elemental2.dom.HTMLTableElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLTableSectionElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collection = goog.require('java.util.Collection');
const _HashMap = goog.require('java.util.HashMap');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _j_u_function_Function = goog.require('java.util.function.Function');
const _Predicate = goog.require('java.util.function.Predicate');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _Stream = goog.require('java.util.stream.Stream');
const _LocalRowFilter = goog.require('org.dominokit.domino.ui.datatable.DataTable.LocalRowFilter');
const _SelectionChangeListener = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener');
const _TableConfig = goog.require('org.dominokit.domino.ui.datatable.TableConfig');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableDataUpdatedEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener');
const _SearchContext = goog.require('org.dominokit.domino.ui.datatable.model.SearchContext');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _DataChangedEvent = goog.require('org.dominokit.domino.ui.datatable.store.DataChangedEvent');
const _DataStore = goog.require('org.dominokit.domino.ui.datatable.store.DataStore');
const _StoreDataChangeListener = goog.require('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable$impl');
exports = DataTable;
 