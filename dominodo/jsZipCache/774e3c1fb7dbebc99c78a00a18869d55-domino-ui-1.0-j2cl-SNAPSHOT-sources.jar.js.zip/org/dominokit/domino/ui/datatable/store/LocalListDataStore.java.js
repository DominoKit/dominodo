/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.LocalListDataStore.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.store.LocalListDataStore');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataStore = goog.require('org.dominokit.domino.ui.datatable.store.DataStore');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collection = goog.require('java.util.Collection');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _Predicate = goog.require('java.util.function.Predicate');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _SearchEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchEvent');
const _SortEvent = goog.require('org.dominokit.domino.ui.datatable.events.SortEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _TablePageChangeEvent = goog.require('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent');
const _SortDirection = goog.require('org.dominokit.domino.ui.datatable.plugins.SortDirection');
const _DataChangedEvent = goog.require('org.dominokit.domino.ui.datatable.store.DataChangedEvent');
const _RecordsSorter = goog.require('org.dominokit.domino.ui.datatable.store.RecordsSorter');
const _SearchFilter = goog.require('org.dominokit.domino.ui.datatable.store.SearchFilter');
const _StoreDataChangeListener = goog.require('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener');
const _HasPagination = goog.require('org.dominokit.domino.ui.pagination.HasPagination');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var LocalListDataStore = goog.require('org.dominokit.domino.ui.datatable.store.LocalListDataStore$impl');
exports = LocalListDataStore;
 