/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor$20 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.$LambdaAdaptor$20$impl');
let DoublClickHandler = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.DoublClickHandler$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class DoubleClickPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DoublClickHandler} */
    this.f_handler__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_;
  }
  
  /**
   * @template C_T
   * @param {DoublClickHandler} handler
   * @return {!DoubleClickPlugin<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler(handler) {
    DoubleClickPlugin.$clinit();
    let $instance = new DoubleClickPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler(handler);
    return $instance;
  }
  
  /**
   * @param {DoublClickHandler} handler
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler(handler) {
    this.$ctor__java_lang_Object__();
    this.f_handler__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_ = handler;
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @param {TableRow<C_T>} tableRow
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(dataTable, tableRow) {
    tableRow.m_asElement__().addEventListener(EventType.f_dblclick__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$20(((/** Event */ evt) =>{
      this.f_handler__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_.m_onDoubleClick__org_dominokit_domino_ui_datatable_TableRow(tableRow);
    })));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    DataTablePlugin.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DoubleClickPlugin.$clinit = (() =>{
    });
    DoubleClickPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DoubleClickPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DoubleClickPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor$20 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.$LambdaAdaptor$20$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
  }
  
  
};

$Util.$setClassMetadata(DoubleClickPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin'));


DataTablePlugin.$markImplementor(DoubleClickPlugin);


exports = DoubleClickPlugin; 
//# sourceMappingURL=DoubleClickPlugin.js.map