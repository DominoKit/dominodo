/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable$LocalRowFilter$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable.LocalRowFilter.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LocalRowFilter = goog.require('org.dominokit.domino.ui.datatable.DataTable.LocalRowFilter$impl');

let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @template C_LocalRowFilter_T
 * @implements {LocalRowFilter<C_LocalRowFilter_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(TableRow<C_LocalRowFilter_T>):boolean} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(TableRow<C_LocalRowFilter_T>):boolean} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter_$LambdaAdaptor__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter_$JsFunction(fn);
  }
  
  /**
   * @param {?function(TableRow<C_LocalRowFilter_T>):boolean} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter_$LambdaAdaptor__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {TableRow<C_LocalRowFilter_T>} arg0
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_ui_datatable_TableRow(arg0) {
    let /** ?function(TableRow<C_LocalRowFilter_T>):boolean */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.DataTable$LocalRowFilter$$LambdaAdaptor'));


LocalRowFilter.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DataTable$LocalRowFilter$$LambdaAdaptor.js.map