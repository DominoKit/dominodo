/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$SearchTableAction.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _KeyboardEvent_$Overlay = goog.require('elemental2.dom.KeyboardEvent.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _SearchClearedEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchClearedEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _$1 = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$1');
const _$LambdaAdaptor$26 = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$26');
const _$LambdaAdaptor$27 = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$27');
const _$LambdaAdaptor$28 = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$28');
const _$LambdaAdaptor$29 = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$29');
const _TextBox = goog.require('org.dominokit.domino.ui.forms.TextBox');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _Timer = goog.require('org.gwtproject.timer.client.Timer');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SearchTableAction = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction$impl');
exports = SearchTableAction;
 