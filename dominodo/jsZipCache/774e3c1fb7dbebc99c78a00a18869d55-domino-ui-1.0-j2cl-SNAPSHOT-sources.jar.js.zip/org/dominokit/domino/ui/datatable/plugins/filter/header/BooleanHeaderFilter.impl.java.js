/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.BooleanHeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.BooleanHeaderFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let SearchContext = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.SearchContext$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {HeaderFilter<C_T>}
  */
class BooleanHeaderFilter extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Select<?string>} */
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter_;
  }
  
  /**
   * @template M_T
   * @return {BooleanHeaderFilter<M_T>}
   * @public
   */
  static m_create__() {
    BooleanHeaderFilter.$clinit();
    return /**@type {!BooleanHeaderFilter<*>} */ (BooleanHeaderFilter.$create__());
  }
  
  /**
   * @template M_T
   * @param {?string} trueLabel
   * @param {?string} falseLabel
   * @param {?string} bothLabel
   * @return {BooleanHeaderFilter<M_T>}
   * @public
   */
  static m_create__java_lang_String__java_lang_String__java_lang_String(trueLabel, falseLabel, bothLabel) {
    BooleanHeaderFilter.$clinit();
    return /**@type {!BooleanHeaderFilter<*>} */ (BooleanHeaderFilter.$create__java_lang_String__java_lang_String__java_lang_String(trueLabel, falseLabel, bothLabel));
  }
  
  /**
   * Factory method corresponding to constructor 'BooleanHeaderFilter()'.
   * @template C_T
   * @return {!BooleanHeaderFilter<C_T>}
   * @public
   */
  static $create__() {
    BooleanHeaderFilter.$clinit();
    let $instance = new BooleanHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BooleanHeaderFilter()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter__() {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter__java_lang_String__java_lang_String__java_lang_String("Yes", "No", "ALL");
  }
  
  /**
   * Factory method corresponding to constructor 'BooleanHeaderFilter(String, String, String)'.
   * @template C_T
   * @param {?string} trueLabel
   * @param {?string} falseLabel
   * @param {?string} bothLabel
   * @return {!BooleanHeaderFilter<C_T>}
   * @public
   */
  static $create__java_lang_String__java_lang_String__java_lang_String(trueLabel, falseLabel, bothLabel) {
    BooleanHeaderFilter.$clinit();
    let $instance = new BooleanHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter__java_lang_String__java_lang_String__java_lang_String(trueLabel, falseLabel, bothLabel);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BooleanHeaderFilter(String, String, String)'.
   * @param {?string} trueLabel
   * @param {?string} falseLabel
   * @param {?string} bothLabel
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter__java_lang_String__java_lang_String__java_lang_String(trueLabel, falseLabel, bothLabel) {
    this.$ctor__java_lang_Object__();
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter_ = /**@type {Select<?string>} */ (Select.m_create__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("", bothLabel))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(Boolean.m_toString__java_lang_Boolean(Boolean.f_TRUE__java_lang_Boolean), trueLabel))).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(Boolean.m_toString__java_lang_Boolean(Boolean.f_FALSE__java_lang_Boolean), falseLabel))).m_setSearchable__boolean(false).m_selectAt__int(0);
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter_.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Select<?string>> */ style) =>{
      style.m_setMarginBottom__java_lang_String("0px");
    })));
  }
  
  /**
   * @override
   * @param {SearchContext<C_T>} searchContext
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_ColumnConfig(searchContext, columnConfig) {
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option) =>{
      if (this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter_.m_getSelectedIndex__() > 0) {
        searchContext.m_add__org_dominokit_domino_ui_datatable_model_Filter(Filter.m_create__java_lang_String__java_lang_String__org_dominokit_domino_ui_datatable_model_Category__org_dominokit_domino_ui_datatable_model_FilterTypes(columnConfig.m_getName__(), /**@type {?string} */ ($Casts.$to(option.m_getValue__(), j_l_String)), Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category, FilterTypes.f_BOOLEAN__org_dominokit_domino_ui_datatable_model_FilterTypes));
        searchContext.m_fireSearchEvent__();
      } else {
        searchContext.m_remove__java_lang_String__org_dominokit_domino_ui_datatable_model_Category(columnConfig.m_getName__(), Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category);
        searchContext.m_fireSearchEvent__();
      }
    })));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter_.m_selectAt__int__boolean(0, true);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_BooleanHeaderFilter_.m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    BooleanHeaderFilter.$clinit = (() =>{
    });
    BooleanHeaderFilter.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BooleanHeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BooleanHeaderFilter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Boolean = goog.module.get('java.lang.Boolean$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Category = goog.module.get('org.dominokit.domino.ui.datatable.model.Category$impl');
    Filter = goog.module.get('org.dominokit.domino.ui.datatable.model.Filter$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(BooleanHeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.BooleanHeaderFilter'));


HeaderFilter.$markImplementor(BooleanHeaderFilter);


exports = BooleanHeaderFilter; 
//# sourceMappingURL=BooleanHeaderFilter.js.map