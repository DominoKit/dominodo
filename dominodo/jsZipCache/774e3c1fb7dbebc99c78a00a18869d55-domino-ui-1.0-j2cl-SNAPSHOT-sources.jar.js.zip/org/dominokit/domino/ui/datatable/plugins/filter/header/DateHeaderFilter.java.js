/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.DateHeaderFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.DateHeaderFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Date = goog.require('java.util.Date');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _FilterTypes = goog.require('org.dominokit.domino.ui.datatable.model.FilterTypes');
const _SearchContext = goog.require('org.dominokit.domino.ui.datatable.model.SearchContext');
const _DateBox = goog.require('org.dominokit.domino.ui.datepicker.DateBox');
const _PickerStyle = goog.require('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle');
const _DateDayClickedHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler');
const _PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DateHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DateHeaderFilter$impl');
exports = DateHeaderFilter;
 