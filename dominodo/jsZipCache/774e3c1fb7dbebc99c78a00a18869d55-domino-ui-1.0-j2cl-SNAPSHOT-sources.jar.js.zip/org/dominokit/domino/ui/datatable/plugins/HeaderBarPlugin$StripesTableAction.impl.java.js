/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$StripesTableAction.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.StripesTableAction$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor$22 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.StripesTableAction.$LambdaAdaptor$22$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_StripesTableAction_T
 * @implements {HeaderActionElement<C_StripesTableAction_T>}
  */
class StripesTableAction extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @template C_StripesTableAction_T
   * @return {!StripesTableAction<C_StripesTableAction_T>}
   * @public
   */
  static $create__() {
    StripesTableAction.$clinit();
    let $instance = new StripesTableAction();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_StripesTableAction__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_StripesTableAction__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {DataTable<C_StripesTableAction_T>} dataTable
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    let stripesIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_format_line_spacing__().m_clickable__(), Icon)).m_setToggleIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_power_input__()), Icon)).m_setTooltip__java_lang_String("No Stripes"), Icon)).m_toggleOnClick__boolean(true), Icon)).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Icon */ icon) =>{
      icon.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$22(((/** Event */ evt) =>{
        if (dataTable.m_isStriped__()) {
          dataTable.m_noStripes__();
          icon.m_setTooltip__java_lang_String("Stripped");
        } else {
          dataTable.m_striped__();
          icon.m_setTooltip__java_lang_String("No Stripes");
        }
      })));
    }))), Icon));
    return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(stripesIcon), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    HeaderActionElement.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    StripesTableAction.$clinit = (() =>{
    });
    StripesTableAction.$loadModules();
    j_l_Object.$clinit();
    HeaderActionElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof StripesTableAction;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, StripesTableAction);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor$22 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.StripesTableAction.$LambdaAdaptor$22$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(StripesTableAction, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$StripesTableAction'));


HeaderActionElement.$markImplementor(StripesTableAction);


exports = StripesTableAction; 
//# sourceMappingURL=HeaderBarPlugin$StripesTableAction.js.map