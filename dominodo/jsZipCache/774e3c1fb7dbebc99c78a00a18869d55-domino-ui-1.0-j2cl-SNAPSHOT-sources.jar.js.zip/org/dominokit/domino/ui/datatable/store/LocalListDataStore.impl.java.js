/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.LocalListDataStore.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.LocalListDataStore$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataStore = goog.require('org.dominokit.domino.ui.datatable.store.DataStore$impl');

let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let SearchEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
let SortEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SortEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let TablePageChangeEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent$impl');
let SortDirection = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');
let DataChangedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');
let RecordsSorter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.RecordsSorter$impl');
let SearchFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.SearchFilter$impl');
let StoreDataChangeListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');
let HasPagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.HasPagination$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {DataStore<C_T>}
  */
class LocalListDataStore extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<StoreDataChangeListener<C_T>>} */
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {List<C_T>} */
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {List<C_T>} */
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {HasPagination} */
    this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {SearchFilter<C_T>} */
    this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {RecordsSorter<C_T>} */
    this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {SortEvent<C_T>} */
    this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {boolean} */
    this.f_autoSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = false;
    /** @public {?string} */
    this.f_autoSortBy__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
    /** @public {SortDirection} */
    this.f_autoSortDirection__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
  }
  
  /**
   * Factory method corresponding to constructor 'LocalListDataStore()'.
   * @template C_T
   * @return {!LocalListDataStore<C_T>}
   * @public
   */
  static $create__() {
    LocalListDataStore.$clinit();
    let $instance = new LocalListDataStore();
    $instance.$ctor__org_dominokit_domino_ui_datatable_store_LocalListDataStore__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LocalListDataStore()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_LocalListDataStore__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
  }
  
  /**
   * Factory method corresponding to constructor 'LocalListDataStore(List)'.
   * @template C_T
   * @param {List<C_T>} data
   * @return {!LocalListDataStore<C_T>}
   * @public
   */
  static $create__java_util_List(data) {
    LocalListDataStore.$clinit();
    let $instance = new LocalListDataStore();
    $instance.$ctor__org_dominokit_domino_ui_datatable_store_LocalListDataStore__java_util_List(data);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LocalListDataStore(List)'.
   * @param {List<C_T>} data
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_LocalListDataStore__java_util_List(data) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = data;
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__java_util_Collection(data));
  }
  
  /**
   * @param {List<C_T>} data
   * @return {void}
   * @public
   */
  m_setData__java_util_List(data) {
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.clear();
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.addAll(data);
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.clear();
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.addAll(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_);
  }
  
  /**
   * @return {SearchFilter<C_T>}
   * @public
   */
  m_getSearchFilter__() {
    return this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
  }
  
  /**
   * @param {SearchFilter<C_T>} searchFilter
   * @return {LocalListDataStore<C_T>}
   * @public
   */
  m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(searchFilter) {
    this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = searchFilter;
    return this;
  }
  
  /**
   * @param {boolean} autoSort
   * @return {LocalListDataStore<C_T>}
   * @public
   */
  m_setAutoSort__boolean(autoSort) {
    this.f_autoSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = autoSort;
    return this;
  }
  
  /**
   * @param {?string} autoSortBy
   * @return {LocalListDataStore<C_T>}
   * @public
   */
  m_setAutoSortBy__java_lang_String(autoSortBy) {
    this.f_autoSortBy__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = autoSortBy;
    return this;
  }
  
  /**
   * @param {SortDirection} autoSortDirection
   * @return {LocalListDataStore<C_T>}
   * @public
   */
  m_setAutoSortDirection__org_dominokit_domino_ui_datatable_plugins_SortDirection(autoSortDirection) {
    this.f_autoSortDirection__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = autoSortDirection;
    return this;
  }
  
  /**
   * @return {HasPagination}
   * @public
   */
  m_getPagination__() {
    return this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
  }
  
  /**
   * @param {HasPagination} pagination
   * @return {LocalListDataStore<C_T>}
   * @public
   */
  m_setPagination__org_dominokit_domino_ui_pagination_HasPagination(pagination) {
    this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = pagination;
    return this;
  }
  
  /**
   * @return {RecordsSorter<C_T>}
   * @public
   */
  m_getRecordsSorter__() {
    return this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_;
  }
  
  /**
   * @param {RecordsSorter<C_T>} recordsSorter
   * @return {LocalListDataStore<C_T>}
   * @public
   */
  m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(recordsSorter) {
    this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = recordsSorter;
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updatePagination___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore() {
    if (Objects.m_nonNull__java_lang_Object(this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_) && Objects.m_nonNull__java_lang_Object(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_)) {
      this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_updatePagesByTotalCount__int(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.size());
    }
  }
  
  /**
   * @override
   * @param {StoreDataChangeListener<C_T>} dataChangeListener
   * @return {void}
   * @public
   */
  m_onDataChanged__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener(dataChangeListener) {
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.add(dataChangeListener);
  }
  
  /**
   * @override
   * @param {StoreDataChangeListener<C_T>} dataChangeListener
   * @return {void}
   * @public
   */
  m_removeDataChangeListener__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener(dataChangeListener) {
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.remove(dataChangeListener);
  }
  
  /**
   * @override
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
    switch ($InternalPreconditions.m_checkNotNull__java_lang_Object(event.m_getType__())) {
      case SearchEvent.f_SEARCH_EVENT__org_dominokit_domino_ui_datatable_events_SearchEvent: 
        this.m_onSearchChanged__org_dominokit_domino_ui_datatable_events_SearchEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore(/**@type {SearchEvent} */ ($Casts.$to(event, SearchEvent)));
        break;
      case SortEvent.f_SORT_EVENT__org_dominokit_domino_ui_datatable_events_SortEvent: 
        this.m_onSortChanged__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore(/**@type {SortEvent} */ ($Casts.$to(event, SortEvent)));
        break;
      case TablePageChangeEvent.f_PAGINATION_EVENT__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent: 
        this.m_onPageChanged___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
        break;
    }
  }
  
  /**
   * @param {SearchEvent} event
   * @return {void}
   * @public
   */
  m_onSearchChanged__org_dominokit_domino_ui_datatable_events_SearchEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore(event) {
    if (Objects.m_nonNull__java_lang_Object(this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_)) {
      this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = /**@type {List<C_T>} */ ($Casts.$to(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** * */ record) =>{
        return this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_filterRecord__org_dominokit_domino_ui_datatable_events_SearchEvent__java_lang_Object(event, record);
      }))).m_collect__java_util_stream_Collector(/**@type {Collector<C_T, ?, List<C_T>>} */ (Collectors.m_toList__())), List));
      if (Objects.m_nonNull__java_lang_Object(this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_)) {
        this.m_sort__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore(this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_);
      }
      this.m_loadFirstPage___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    }
  }
  
  /**
   * @param {SortEvent<C_T>} event
   * @return {void}
   * @public
   */
  m_onSortChanged__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore(event) {
    if (Objects.m_nonNull__java_lang_Object(this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_)) {
      this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = event;
      this.m_sort__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore(event);
      this.m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    }
  }
  
  /**
   * @param {SortEvent<C_T>} event
   * @return {void}
   * @public
   */
  m_sort__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore(event) {
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_sort__java_util_Comparator(this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_onSortChange__java_lang_String__org_dominokit_domino_ui_datatable_plugins_SortDirection(event.m_getColumnConfig__().m_getName__(), event.m_getSortDirection__()));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_loadFirstPage___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore() {
    if (Objects.m_nonNull__java_lang_Object(this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_)) {
      this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_updatePagesByTotalCount__int(this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.size());
      this.m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    } else {
      this.m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onPageChanged___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore() {
    this.m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_load__() {
    this.m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    this.m_updatePagination___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore() {
    let updateRecords = this.m_getUpdateRecords___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    if (this.f_autoSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ && Objects.m_nonNull__java_lang_Object(this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_)) {
      updateRecords.m_sort__java_util_Comparator(this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_onSortChange__java_lang_String__org_dominokit_domino_ui_datatable_plugins_SortDirection(this.f_autoSortBy__org_dominokit_domino_ui_datatable_store_LocalListDataStore_, this.f_autoSortDirection__org_dominokit_domino_ui_datatable_store_LocalListDataStore_));
    }
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** StoreDataChangeListener<*> */ dataChangeListener) =>{
      dataChangeListener.m_onDataChanged__org_dominokit_domino_ui_datatable_store_DataChangedEvent(/**@type {!DataChangedEvent<*>} */ (DataChangedEvent.$create__java_util_List__int(updateRecords, this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.size())));
    })));
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_getUpdateRecords___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore() {
    if (Objects.m_nonNull__java_lang_Object(this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_)) {
      let fromIndex = this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_getPageSize__() * (this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_activePage__() - 1);
      let toIndex = Math.min(fromIndex + this.f_pagination__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.m_getPageSize__(), this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.size());
      return /**@type {!ArrayList<C_T>} */ (ArrayList.$create__java_util_Collection(this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.subList(fromIndex, toIndex)));
    } else {
      return /**@type {!ArrayList<C_T>} */ (ArrayList.$create__java_util_Collection(this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_));
    }
  }
  
  /**
   * @param {C_T} record
   * @return {void}
   * @public
   */
  m_addRecord__java_lang_Object(record) {
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.add(record);
    let newData = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__java_util_Collection(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_));
    this.m_setData__java_util_List(newData);
    this.m_load__();
  }
  
  /**
   * @param {C_T} record
   * @return {void}
   * @public
   */
  m_removeRecord__java_lang_Object(record) {
    if (this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.contains(record)) {
      this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.remove(record);
      this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.remove(record);
      this.m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
    }
  }
  
  /**
   * @param {Collection<C_T>} records
   * @return {void}
   * @public
   */
  m_addRecords__java_util_Collection(records) {
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.addAll(records);
    let newData = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__java_util_Collection(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_));
    this.m_setData__java_util_List(newData);
    this.m_load__();
  }
  
  /**
   * @param {Collection<C_T>} records
   * @return {void}
   * @public
   */
  m_removeRecord__java_util_Collection(records) {
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.removeAll(records);
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListDataStore_.removeAll(records);
    this.m_fireUpdate___$p_org_dominokit_domino_ui_datatable_store_LocalListDataStore();
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_getRecords__() {
    return /**@type {!ArrayList<C_T>} */ (ArrayList.$create__java_util_Collection(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListDataStore_));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_store_LocalListDataStore() {
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = /**@type {!ArrayList<StoreDataChangeListener<C_T>>} */ (ArrayList.$create__());
    this.f_autoSort__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = false;
    this.f_autoSortBy__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = "*";
    this.f_autoSortDirection__org_dominokit_domino_ui_datatable_store_LocalListDataStore_ = SortDirection.f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    LocalListDataStore.$clinit = (() =>{
    });
    LocalListDataStore.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LocalListDataStore;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LocalListDataStore);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    List = goog.module.get('java.util.List$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    SearchEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
    SortEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SortEvent$impl');
    TablePageChangeEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent$impl');
    SortDirection = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');
    DataChangedEvent = goog.module.get('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(LocalListDataStore, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.LocalListDataStore'));


DataStore.$markImplementor(LocalListDataStore);


exports = LocalListDataStore; 
//# sourceMappingURL=LocalListDataStore.js.map