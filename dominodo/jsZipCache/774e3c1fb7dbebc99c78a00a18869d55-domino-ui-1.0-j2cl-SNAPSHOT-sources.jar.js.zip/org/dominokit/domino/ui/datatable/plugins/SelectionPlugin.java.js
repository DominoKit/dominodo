/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.SelectionPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _$Overlay = goog.require('elemental2.dom.Document.$Overlay');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLTableRowElement_$Overlay = goog.require('elemental2.dom.HTMLTableRowElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Boolean = goog.require('java.lang.Boolean');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Js = goog.require('jsinterop.base.Js');
const _CellRenderer = goog.require('org.dominokit.domino.ui.datatable.CellRenderer');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _SelectionChangeListener = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener');
const _HeaderElement = goog.require('org.dominokit.domino.ui.datatable.HeaderElement');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _$LambdaAdaptor$31 = goog.require('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin.$LambdaAdaptor$31');
const _CheckBox = goog.require('org.dominokit.domino.ui.forms.CheckBox');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _ChangeHandler = goog.require('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler');
const _Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.Selectable.SelectionHandler');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SelectionPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin$impl');
exports = SelectionPlugin;
 