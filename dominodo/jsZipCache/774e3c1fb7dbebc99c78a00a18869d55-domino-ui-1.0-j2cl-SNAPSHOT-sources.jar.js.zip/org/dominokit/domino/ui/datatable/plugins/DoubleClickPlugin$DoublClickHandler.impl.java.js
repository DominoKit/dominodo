/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin$DoublClickHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.DoublClickHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.DoublClickHandler.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_DoublClickHandler_T
 */
class DoublClickHandler {
  /**
   * @abstract
   * @param {TableRow<C_DoublClickHandler_T>} tableRow
   * @return {void}
   * @public
   */
  m_onDoubleClick__org_dominokit_domino_ui_datatable_TableRow(tableRow) {
  }
  
  /**
   * @template C_DoublClickHandler_T
   * @param {?function(TableRow<C_DoublClickHandler_T>):void} fn
   * @return {DoublClickHandler<C_DoublClickHandler_T>}
   * @public
   */
  static $adapt(fn) {
    DoublClickHandler.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DoublClickHandler.$clinit = (() =>{
    });
    DoublClickHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_DoubleClickPlugin_DoublClickHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.DoublClickHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(DoublClickHandler, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin$DoublClickHandler'));


DoublClickHandler.$markImplementor(/** @type {Function} */ (DoublClickHandler));


exports = DoublClickHandler; 
//# sourceMappingURL=DoubleClickPlugin$DoublClickHandler.js.map