/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.Filter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.model.Filter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _FilterTypes = goog.require('org.dominokit.domino.ui.datatable.model.FilterTypes');
const _Operator = goog.require('org.dominokit.domino.ui.datatable.model.Operator');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter$impl');
exports = Filter;
 