/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.ColumnConfig.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.ColumnConfig$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let CellRenderer = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let CellStyler = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');
let HeaderElement = goog.forwardDeclare('org.dominokit.domino.ui.datatable.HeaderElement$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');


/**
 * @template C_T
  */
class ColumnConfig extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_name__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {?string} */
    this.f_title__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {HTMLTableCellElement} */
    this.f_headElement__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {HTMLDivElement} */
    this.f_contextMenu__org_dominokit_domino_ui_datatable_ColumnConfig;
    /** @public {boolean} */
    this.f_header__org_dominokit_domino_ui_datatable_ColumnConfig_ = false;
    /** @public {?string} */
    this.f_minWidth__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {?string} */
    this.f_maxWidth__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {?string} */
    this.f_textAlign__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {CellRenderer<C_T>} */
    this.f_cellRenderer__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {HeaderElement} */
    this.f_headerElement__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {CellStyler<C_T>} */
    this.f_headerStyler__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {CellStyler<C_T>} */
    this.f_cellStyler__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {boolean} */
    this.f_sortable__org_dominokit_domino_ui_datatable_ColumnConfig_ = false;
    /** @public {?string} */
    this.f_width__org_dominokit_domino_ui_datatable_ColumnConfig_;
    /** @public {boolean} */
    this.f_fixed__org_dominokit_domino_ui_datatable_ColumnConfig_ = false;
    /** @public {Node} */
    this.f_tooltipNode__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @template M_T
   * @param {?string} name
   * @return {ColumnConfig<M_T>}
   * @public
   */
  static m_create__java_lang_String(name) {
    ColumnConfig.$clinit();
    return /**@type {!ColumnConfig<*>} */ (ColumnConfig.$create__java_lang_String(name));
  }
  
  /**
   * @template M_T
   * @param {?string} name
   * @param {?string} title
   * @return {ColumnConfig<M_T>}
   * @public
   */
  static m_create__java_lang_String__java_lang_String(name, title) {
    ColumnConfig.$clinit();
    return /**@type {!ColumnConfig<*>} */ (ColumnConfig.$create__java_lang_String__java_lang_String(name, title));
  }
  
  /**
   * Factory method corresponding to constructor 'ColumnConfig(String, String)'.
   * @template C_T
   * @param {?string} name
   * @param {?string} title
   * @return {!ColumnConfig<C_T>}
   * @public
   */
  static $create__java_lang_String__java_lang_String(name, title) {
    ColumnConfig.$clinit();
    let $instance = new ColumnConfig();
    $instance.$ctor__org_dominokit_domino_ui_datatable_ColumnConfig__java_lang_String__java_lang_String(name, title);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColumnConfig(String, String)'.
   * @param {?string} name
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_ColumnConfig__java_lang_String__java_lang_String(name, title) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_ColumnConfig();
    this.f_name__org_dominokit_domino_ui_datatable_ColumnConfig_ = name;
    this.f_title__org_dominokit_domino_ui_datatable_ColumnConfig_ = title;
  }
  
  /**
   * Factory method corresponding to constructor 'ColumnConfig(String)'.
   * @template C_T
   * @param {?string} name
   * @return {!ColumnConfig<C_T>}
   * @public
   */
  static $create__java_lang_String(name) {
    ColumnConfig.$clinit();
    let $instance = new ColumnConfig();
    $instance.$ctor__org_dominokit_domino_ui_datatable_ColumnConfig__java_lang_String(name);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ColumnConfig(String)'.
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_ColumnConfig__java_lang_String(name) {
    this.$ctor__org_dominokit_domino_ui_datatable_ColumnConfig__java_lang_String__java_lang_String(name, "");
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getTitle__() {
    return this.f_title__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_asHeader__() {
    this.f_header__org_dominokit_domino_ui_datatable_ColumnConfig_ = true;
    return this;
  }
  
  /**
   * @param {?string} minWidth
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_minWidth__java_lang_String(minWidth) {
    this.f_minWidth__org_dominokit_domino_ui_datatable_ColumnConfig_ = minWidth;
    return this;
  }
  
  /**
   * @param {?string} maxWidth
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_maxWidth__java_lang_String(maxWidth) {
    this.f_maxWidth__org_dominokit_domino_ui_datatable_ColumnConfig_ = maxWidth;
    return this;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getWidth__() {
    return this.f_width__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @param {?string} width
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setWidth__java_lang_String(width) {
    this.f_width__org_dominokit_domino_ui_datatable_ColumnConfig_ = width;
    return this;
  }
  
  /**
   * @param {?string} textAlign
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_textAlign__java_lang_String(textAlign) {
    this.f_textAlign__org_dominokit_domino_ui_datatable_ColumnConfig_ = textAlign;
    return this;
  }
  
  /**
   * @return {HeaderElement}
   * @public
   */
  m_getHeaderElement__() {
    return this.f_headerElement__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @param {HeaderElement} headerElement
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setHeaderElement__org_dominokit_domino_ui_datatable_HeaderElement(headerElement) {
    this.f_headerElement__org_dominokit_domino_ui_datatable_ColumnConfig_ = headerElement;
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isHeader__() {
    return this.f_header__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getMinWidth__() {
    return this.f_minWidth__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getMaxWidth__() {
    return this.f_maxWidth__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getTextAlign__() {
    return this.f_textAlign__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isFixed__() {
    return this.f_fixed__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @param {boolean} fixed
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setFixed__boolean(fixed) {
    this.f_fixed__org_dominokit_domino_ui_datatable_ColumnConfig_ = fixed;
    return this;
  }
  
  /**
   * @param {?string} title
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setTitle__java_lang_String(title) {
    this.f_title__org_dominokit_domino_ui_datatable_ColumnConfig_ = title;
    return this;
  }
  
  /**
   * @return {DominoElement<HTMLTableCellElement>}
   * @public
   */
  m_getHeadElement__() {
    return /**@type {DominoElement<HTMLTableCellElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_headElement__org_dominokit_domino_ui_datatable_ColumnConfig_));
  }
  
  /**
   * @param {HTMLTableCellElement} headElement
   * @return {void}
   * @public
   */
  m_setHeadElement__elemental2_dom_HTMLTableCellElement(headElement) {
    this.f_headElement__org_dominokit_domino_ui_datatable_ColumnConfig_ = headElement;
  }
  
  /**
   * @return {CellRenderer<C_T>}
   * @public
   */
  m_getCellRenderer__() {
    return this.f_cellRenderer__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @param {CellRenderer<C_T>} cellRenderer
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(cellRenderer) {
    this.f_cellRenderer__org_dominokit_domino_ui_datatable_ColumnConfig_ = cellRenderer;
    return this;
  }
  
  /**
   * @param {CellStyler<C_T>} headerStyler
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_styleHeader__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(headerStyler) {
    this.f_headerStyler__org_dominokit_domino_ui_datatable_ColumnConfig_ = headerStyler;
    return this;
  }
  
  /**
   * @param {CellStyler<C_T>} cellStyler
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_styleCell__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(cellStyler) {
    this.f_cellStyler__org_dominokit_domino_ui_datatable_ColumnConfig_ = cellStyler;
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isSortable__() {
    return this.f_sortable__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @param {boolean} sortable
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setSortable__boolean(sortable) {
    this.f_sortable__org_dominokit_domino_ui_datatable_ColumnConfig_ = sortable;
    return this;
  }
  
  /**
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_sortable__() {
    this.f_sortable__org_dominokit_domino_ui_datatable_ColumnConfig_ = true;
    return this;
  }
  
  /**
   * @return {Node}
   * @public
   */
  m_getTooltipNode__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_tooltipNode__org_dominokit_domino_ui_datatable_ColumnConfig_)) {
      return this.f_tooltipNode__org_dominokit_domino_ui_datatable_ColumnConfig_;
    } else {
      return this.m_getHeaderElement__().m_asElement__java_lang_String(this.f_title__org_dominokit_domino_ui_datatable_ColumnConfig_);
    }
  }
  
  /**
   * @param {Node} tooltipNode
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setTooltipNode__elemental2_dom_Node(tooltipNode) {
    this.f_tooltipNode__org_dominokit_domino_ui_datatable_ColumnConfig_ = tooltipNode;
    return this;
  }
  
  /**
   * @param {?string} tooltipText
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_setTooltipText__java_lang_String(tooltipText) {
    this.f_tooltipNode__org_dominokit_domino_ui_datatable_ColumnConfig_ = TextNode.m_of__java_lang_String(tooltipText);
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_applyHeaderStyle___$pp_org_dominokit_domino_ui_datatable() {
    this.f_headerStyler__org_dominokit_domino_ui_datatable_ColumnConfig_.m_styleCell__elemental2_dom_HTMLTableCellElement(this.f_headElement__org_dominokit_domino_ui_datatable_ColumnConfig_);
  }
  
  /**
   * @param {HTMLTableCellElement} element
   * @return {void}
   * @public
   */
  m_applyCellStyle__elemental2_dom_HTMLTableCellElement_$pp_org_dominokit_domino_ui_datatable(element) {
    this.f_cellStyler__org_dominokit_domino_ui_datatable_ColumnConfig_.m_styleCell__elemental2_dom_HTMLTableCellElement(element);
  }
  
  /**
   * @return {CellStyler<C_T>}
   * @public
   */
  m_getHeaderStyler__() {
    return this.f_headerStyler__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {CellStyler<C_T>}
   * @public
   */
  m_getCellStyler__() {
    return this.f_cellStyler__org_dominokit_domino_ui_datatable_ColumnConfig_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_ColumnConfig() {
    this.f_header__org_dominokit_domino_ui_datatable_ColumnConfig_ = false;
    this.f_cellRenderer__org_dominokit_domino_ui_datatable_ColumnConfig_ = /**@type {CellRenderer<C_T>} */ (CellRenderer.$adapt(((/** CellInfo<*> */ cell) =>{
      return TextNode.m_of__java_lang_String("");
    })));
    this.f_headerElement__org_dominokit_domino_ui_datatable_ColumnConfig_ = HeaderElement.$adapt(((/** ?string */ arg0) =>{
      return TextNode.m_of__java_lang_String(arg0);
    }));
    this.f_headerStyler__org_dominokit_domino_ui_datatable_ColumnConfig_ = /**@type {CellStyler<C_T>} */ (CellStyler.$adapt(((/** HTMLTableCellElement */ element) =>{
    })));
    this.f_cellStyler__org_dominokit_domino_ui_datatable_ColumnConfig_ = /**@type {CellStyler<C_T>} */ (CellStyler.$adapt(((/** HTMLTableCellElement */ element$1$) =>{
    })));
    this.f_sortable__org_dominokit_domino_ui_datatable_ColumnConfig_ = false;
    this.f_fixed__org_dominokit_domino_ui_datatable_ColumnConfig_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ColumnConfig.$clinit = (() =>{
    });
    ColumnConfig.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColumnConfig;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColumnConfig);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Objects = goog.module.get('java.util.Objects$impl');
    CellRenderer = goog.module.get('org.dominokit.domino.ui.datatable.CellRenderer$impl');
    CellStyler = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');
    HeaderElement = goog.module.get('org.dominokit.domino.ui.datatable.HeaderElement$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
  }
  
  
};

$Util.$setClassMetadata(ColumnConfig, $Util.$makeClassName('org.dominokit.domino.ui.datatable.ColumnConfig'));




exports = ColumnConfig; 
//# sourceMappingURL=ColumnConfig.js.map