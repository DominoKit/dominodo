/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.DataTablePlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener$impl');

let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');


/**
 * @interface
 * @template C_T
 * @extends {TableEventListener}
 */
class DataTablePlugin {
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @param {ColumnConfig<C_T>} column
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(dataTable, column) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @param {TableRow<C_T>} tableRow
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(dataTable, tableRow) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @param {TableRow<C_T>} tableRow
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(dataTable, tableRow) {
  }
  
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  static m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable($thisArg, dataTable) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  static m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable($thisArg, dataTable) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  static m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable($thisArg, dataTable) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  static m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable($thisArg, dataTable) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @param {ColumnConfig<C_T>} column
   * @return {void}
   * @public
   */
  static m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig($thisArg, dataTable, column) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  static m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable($thisArg, dataTable) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  static m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable($thisArg, dataTable) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @param {TableRow<C_T>} tableRow
   * @return {void}
   * @public
   */
  static m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow($thisArg, dataTable, tableRow) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @param {TableRow<C_T>} tableRow
   * @return {void}
   * @public
   */
  static m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow($thisArg, dataTable, tableRow) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  static m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable($thisArg, dataTable) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @template C_T
   * @param {DataTablePlugin<C_T>} $thisArg
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  static m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent($thisArg, event) {
    DataTablePlugin.$clinit();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DataTablePlugin.$clinit = (() =>{
    });
    DataTablePlugin.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    TableEventListener.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(DataTablePlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin'));


DataTablePlugin.$markImplementor(/** @type {Function} */ (DataTablePlugin));


exports = DataTablePlugin; 
//# sourceMappingURL=DataTablePlugin.js.map