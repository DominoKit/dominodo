/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.RecordsSorter$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.RecordsSorter.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RecordsSorter = goog.require('org.dominokit.domino.ui.datatable.store.RecordsSorter$impl');

let Comparator = goog.forwardDeclare('java.util.Comparator$impl');
let SortDirection = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');


/**
 * @template C_T
 * @implements {RecordsSorter<C_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(?string, SortDirection):Comparator<C_T>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string, SortDirection):Comparator<C_T>} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_store_RecordsSorter_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_store_RecordsSorter_$LambdaAdaptor__org_dominokit_domino_ui_datatable_store_RecordsSorter_$JsFunction(fn);
  }
  
  /**
   * @param {?function(?string, SortDirection):Comparator<C_T>} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_RecordsSorter_$LambdaAdaptor__org_dominokit_domino_ui_datatable_store_RecordsSorter_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_store_RecordsSorter_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @param {SortDirection} arg1
   * @return {Comparator<C_T>}
   * @public
   */
  m_onSortChange__java_lang_String__org_dominokit_domino_ui_datatable_plugins_SortDirection(arg0, arg1) {
    let /** ?function(?string, SortDirection):Comparator<C_T> */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_datatable_store_RecordsSorter_$LambdaAdaptor, $function(arg0, arg1));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.RecordsSorter$$LambdaAdaptor'));


RecordsSorter.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=RecordsSorter$$LambdaAdaptor.js.map