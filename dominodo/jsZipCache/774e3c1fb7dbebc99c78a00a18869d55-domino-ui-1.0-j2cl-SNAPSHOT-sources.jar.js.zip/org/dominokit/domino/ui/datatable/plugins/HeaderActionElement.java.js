/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener');
const _$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.$LambdaAdaptor');


// Re-exports the implementation.
var HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');
exports = HeaderActionElement;
 