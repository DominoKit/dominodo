/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.RecordsSorter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.RecordsSorter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Comparator = goog.forwardDeclare('java.util.Comparator$impl');
let SortDirection = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.RecordsSorter.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 */
class RecordsSorter {
  /**
   * @abstract
   * @param {?string} sortBy
   * @param {SortDirection} sortDirection
   * @return {Comparator<C_T>}
   * @public
   */
  m_onSortChange__java_lang_String__org_dominokit_domino_ui_datatable_plugins_SortDirection(sortBy, sortDirection) {
  }
  
  /**
   * @template C_T
   * @param {?function(?string, SortDirection):Comparator<C_T>} fn
   * @return {RecordsSorter<C_T>}
   * @public
   */
  static $adapt(fn) {
    RecordsSorter.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RecordsSorter.$clinit = (() =>{
    });
    RecordsSorter.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_RecordsSorter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_store_RecordsSorter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_RecordsSorter;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.store.RecordsSorter.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RecordsSorter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.RecordsSorter'));


RecordsSorter.$markImplementor(/** @type {Function} */ (RecordsSorter));


exports = RecordsSorter; 
//# sourceMappingURL=RecordsSorter.js.map