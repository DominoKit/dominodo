/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.DataTablePlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');


// Re-exports the implementation.
var DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');
exports = DataTablePlugin;
 