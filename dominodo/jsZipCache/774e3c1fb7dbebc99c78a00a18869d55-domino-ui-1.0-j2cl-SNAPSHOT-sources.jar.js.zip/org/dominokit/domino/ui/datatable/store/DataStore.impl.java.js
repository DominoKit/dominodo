/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.DataStore.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.DataStore$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener$impl');

let StoreDataChangeListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');


/**
 * @interface
 * @template C_T
 * @extends {TableEventListener}
 */
class DataStore {
  /**
   * @abstract
   * @param {StoreDataChangeListener<C_T>} dataChangeListener
   * @return {void}
   * @public
   */
  m_onDataChanged__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener(dataChangeListener) {
  }
  
  /**
   * @abstract
   * @param {StoreDataChangeListener<C_T>} dataChangeListener
   * @return {void}
   * @public
   */
  m_removeDataChangeListener__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener(dataChangeListener) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_load__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DataStore.$clinit = (() =>{
    });
    DataStore.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    TableEventListener.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_DataStore = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_store_DataStore;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_DataStore;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(DataStore, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.DataStore'));


DataStore.$markImplementor(/** @type {Function} */ (DataStore));


exports = DataStore; 
//# sourceMappingURL=DataStore.js.map