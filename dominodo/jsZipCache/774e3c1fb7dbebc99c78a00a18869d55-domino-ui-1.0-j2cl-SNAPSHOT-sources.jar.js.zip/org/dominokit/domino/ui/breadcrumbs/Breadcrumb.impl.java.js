/**
 * @fileoverview transpiled from org.dominokit.domino.ui.breadcrumbs.Breadcrumb.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.breadcrumbs.Breadcrumb$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLOListElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $LambdaAdaptor$3 = goog.forwardDeclare('org.dominokit.domino.ui.breadcrumbs.Breadcrumb.$LambdaAdaptor$3$impl');
let BreadcrumbItem = goog.forwardDeclare('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLOListElement, Breadcrumb>}
 * @implements {HasBackground<Breadcrumb>}
  */
class Breadcrumb extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLOListElement>} */
    this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_;
    /** @public {List<BreadcrumbItem>} */
    this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_;
    /** @public {BreadcrumbItem} */
    this.f_activeItem__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_;
    /** @public {boolean} */
    this.f_removeTail__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = false;
    /** @public {Color} */
    this.f_activeColor__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_;
    /** @public {Color} */
    this.f_activeBackground__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_;
  }
  
  /**
   * @return {!Breadcrumb}
   * @public
   */
  static $create__() {
    Breadcrumb.$clinit();
    let $instance = new Breadcrumb();
    $instance.$ctor__org_dominokit_domino_ui_breadcrumbs_Breadcrumb__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_breadcrumbs_Breadcrumb__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_breadcrumbs_Breadcrumb();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {Breadcrumb}
   * @public
   */
  static m_create__() {
    Breadcrumb.$clinit();
    return Breadcrumb.$create__();
  }
  
  /**
   * @param {?string} text
   * @param {EventListener} onClick
   * @return {Breadcrumb}
   * @public
   * @deprecated
   */
  m_addItem__java_lang_String__elemental2_dom_EventListener(text, onClick) {
    return this.m_appendChild__java_lang_String__elemental2_dom_EventListener(text, onClick);
  }
  
  /**
   * @param {?string} text
   * @param {EventListener} onClick
   * @return {Breadcrumb}
   * @public
   */
  m_appendChild__java_lang_String__elemental2_dom_EventListener(text, onClick) {
    let item = BreadcrumbItem.m_create__java_lang_String(text);
    this.m_addNewItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item);
    item.m_addClickListener__elemental2_dom_EventListener(onClick);
    return this;
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @param {?string} text
   * @param {EventListener} onClick
   * @return {Breadcrumb}
   * @public
   * @deprecated
   */
  m_addItem__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(icon, text, onClick) {
    return this.m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(icon, text, onClick);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @param {?string} text
   * @param {EventListener} onClick
   * @return {Breadcrumb}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String__elemental2_dom_EventListener(icon, text, onClick) {
    let item = BreadcrumbItem.m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(icon, text);
    this.m_addNewItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item);
    item.m_addClickListener__elemental2_dom_EventListener(onClick);
    return this;
  }
  
  /**
   * @param {BreadcrumbItem} item
   * @return {Breadcrumb}
   * @public
   * @deprecated
   */
  m_addItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem(item) {
    this.m_addNewItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item);
    return this;
  }
  
  /**
   * @param {BreadcrumbItem} item
   * @return {Breadcrumb}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem(item) {
    this.m_addNewItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item);
    return this;
  }
  
  /**
   * @param {BreadcrumbItem} item
   * @return {void}
   * @public
   */
  m_addNewItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item) {
    this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.add(item);
    this.m_setActiveItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item);
    this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(item);
    /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(item.m_getClickableElement__())).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$3(((/** Event */ e) =>{
      this.m_setActiveItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item);
    })));
  }
  
  /**
   * @param {BreadcrumbItem} item
   * @return {Breadcrumb}
   * @public
   */
  m_setActiveItem__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_$p_org_dominokit_domino_ui_breadcrumbs_Breadcrumb(item) {
    if (Objects.m_nonNull__java_lang_Object(this.f_activeItem__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_)) {
      this.f_activeItem__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.m_deActivate__();
    }
    item.m_activate__();
    this.f_activeItem__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = item;
    item.m_activate__();
    if (this.f_removeTail__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_) {
      let index = this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.indexOf(item) + 1;
      while (this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.size() > index) {
        /**@type {BreadcrumbItem} */ ($Casts.$to(this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.getAtIndex(this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.size() - 1), BreadcrumbItem)).m_asElement__().remove();
        this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.removeAtIndex(this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.size() - 1);
      }
    }
    return this;
  }
  
  /**
   * @param {boolean} removeTail
   * @return {Breadcrumb}
   * @public
   */
  m_setRemoveActiveTailItem__boolean(removeTail) {
    this.f_removeTail__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = removeTail;
    return this;
  }
  
  /**
   * @param {Color} color
   * @return {Breadcrumb}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_activeColor__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_)) {
      this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.m_style__().m_remove__java_lang_String(color.m_getStyle__());
    }
    this.f_activeColor__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = color;
    this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.m_style__().m_add__java_lang_String(color.m_getStyle__());
    return this;
  }
  
  /**
   * @return {Breadcrumb}
   * @public
   */
  m_alignCenter__() {
    this.m_style__().m_alignCenter__();
    return this;
  }
  
  /**
   * @return {Breadcrumb}
   * @public
   */
  m_alignRight__() {
    this.m_style__().m_alignRight__();
    return this;
  }
  
  /**
   * @override
   * @return {HTMLOListElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLOListElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {Breadcrumb}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_activeBackground__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_)) {
      this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.m_style__().m_remove__java_lang_String(background.m_getBackground__());
    }
    this.f_activeBackground__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = background;
    this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_.m_style__().m_add__java_lang_String(background.m_getBackground__());
    return this;
  }
  
  /**
   * @return {BreadcrumbItem}
   * @public
   */
  m_getActiveItem__() {
    return this.f_activeItem__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_;
  }
  
  /**
   * @return {List<BreadcrumbItem>}
   * @public
   */
  m_getItems__() {
    return this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_breadcrumbs_Breadcrumb() {
    this.f_element__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = /**@type {DominoElement<HTMLOListElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_ol__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["breadcrumb"], j_l_String)))));
    this.f_items__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = /**@type {!LinkedList<BreadcrumbItem>} */ (LinkedList.$create__());
    this.f_removeTail__org_dominokit_domino_ui_breadcrumbs_Breadcrumb_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Breadcrumb.$clinit = (() =>{
    });
    Breadcrumb.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Breadcrumb;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Breadcrumb);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLOListElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $LambdaAdaptor$3 = goog.module.get('org.dominokit.domino.ui.breadcrumbs.Breadcrumb.$LambdaAdaptor$3$impl');
    BreadcrumbItem = goog.module.get('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Breadcrumb, $Util.$makeClassName('org.dominokit.domino.ui.breadcrumbs.Breadcrumb'));


HasBackground.$markImplementor(Breadcrumb);


exports = Breadcrumb; 
//# sourceMappingURL=Breadcrumb.js.map