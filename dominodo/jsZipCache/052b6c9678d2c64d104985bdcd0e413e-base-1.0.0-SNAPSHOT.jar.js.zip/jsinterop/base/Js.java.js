/**
 * @fileoverview transpiled from jsinterop.base.Js.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('jsinterop.base.Js');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Any_$Overlay = goog.require('jsinterop.base.Any.$Overlay');
const _InternalJsUtil = goog.require('jsinterop.base.InternalJsUtil');
const _InternalPreconditions = goog.require('jsinterop.base.InternalPreconditions');
const _$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _JsConstructorFn_$Overlay = goog.require('jsinterop.base.JsConstructorFn.$Overlay');
const _JsPropertyMap_$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Long = goog.require('nativebootstrap.Long');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var Js = goog.require('jsinterop.base.Js$impl');
exports = Js;
 