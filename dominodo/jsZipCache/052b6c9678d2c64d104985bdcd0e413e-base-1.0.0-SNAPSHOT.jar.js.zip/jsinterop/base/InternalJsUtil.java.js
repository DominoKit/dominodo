/**
 * @fileoverview transpiled from jsinterop.base.InternalJsUtil.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('jsinterop.base.InternalJsUtil');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _JsConstructorFn_$Overlay = goog.require('jsinterop.base.JsConstructorFn.$Overlay');
const _$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$Long = goog.require('nativebootstrap.Long');


// Re-exports the implementation.
var InternalJsUtil = goog.require('jsinterop.base.InternalJsUtil$impl');
exports = InternalJsUtil;
 