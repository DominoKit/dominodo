/**
 * @fileoverview transpiled from jsinterop.base.JsPropertyMap$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('jsinterop.base.JsPropertyMap.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.Any.$Overlay$impl');
let InternalJsUtil = goog.forwardDeclare('jsinterop.base.InternalJsUtil$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class JsPropertyMap_$Overlay {
  /**
   * @return {Object<string, *>}
   * @public
   */
  static m_of__() {
    JsPropertyMap_$Overlay.$clinit();
    return InternalJsUtil.emptyObjectLiteral();
  }
  
  /**
   * @param {?string} k
   * @param {*} v
   * @return {Object<string, *>}
   * @public
   */
  static m_of__java_lang_String__java_lang_Object(k, v) {
    JsPropertyMap_$Overlay.$clinit();
    let map = JsPropertyMap_$Overlay.m_of__();
    JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, k, v);
    return map;
  }
  
  /**
   * @param {?string} k1
   * @param {*} v1
   * @param {?string} k2
   * @param {*} v2
   * @return {Object<string, *>}
   * @public
   */
  static m_of__java_lang_String__java_lang_Object__java_lang_String__java_lang_Object(k1, v1, k2, v2) {
    JsPropertyMap_$Overlay.$clinit();
    let map = JsPropertyMap_$Overlay.m_of__();
    JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, k1, v1);
    JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, k2, v2);
    return map;
  }
  
  /**
   * @param {?string} k1
   * @param {*} v1
   * @param {?string} k2
   * @param {*} v2
   * @param {?string} k3
   * @param {*} v3
   * @return {Object<string, *>}
   * @public
   */
  static m_of__java_lang_String__java_lang_Object__java_lang_String__java_lang_Object__java_lang_String__java_lang_Object(k1, v1, k2, v2, k3, v3) {
    JsPropertyMap_$Overlay.$clinit();
    let map = JsPropertyMap_$Overlay.m_of__();
    JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, k1, v1);
    JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, k2, v2);
    JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(map, k3, v3);
    return map;
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?string} propertyName
   * @return {C_T}
   * @public
   */
  static m_get__jsinterop_base_JsPropertyMap__java_lang_String($thisArg, propertyName) {
    JsPropertyMap_$Overlay.$clinit();
    return /**@type {*} */ ($Casts.$to(InternalJsUtil.getIndexed($thisArg, propertyName), j_l_Object));
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?string} qualifiedName
   * @return {*}
   * @public
   */
  static m_nestedGet__jsinterop_base_JsPropertyMap__java_lang_String($thisArg, qualifiedName) {
    JsPropertyMap_$Overlay.$clinit();
    return goog.getObjectByName(qualifiedName, $thisArg);
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?string} propertyName
   * @return {*}
   * @public
   */
  static m_getAny__jsinterop_base_JsPropertyMap__java_lang_String($thisArg, propertyName) {
    JsPropertyMap_$Overlay.$clinit();
    return /**@type {*} */ ($Casts.$to(InternalJsUtil.getIndexed($thisArg, propertyName), $Overlay));
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?string} qualifiedName
   * @return {*}
   * @public
   */
  static m_nestedGetAny__jsinterop_base_JsPropertyMap__java_lang_String($thisArg, qualifiedName) {
    JsPropertyMap_$Overlay.$clinit();
    return /**@type {*} */ ($Casts.$to(goog.getObjectByName(qualifiedName, $thisArg), $Overlay));
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?string} propertyName
   * @return {boolean}
   * @public
   */
  static m_has__jsinterop_base_JsPropertyMap__java_lang_String($thisArg, propertyName) {
    JsPropertyMap_$Overlay.$clinit();
    return InternalJsUtil.hasIndexed($thisArg, propertyName);
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?string} propertyName
   * @return {void}
   * @public
   */
  static m_delete__jsinterop_base_JsPropertyMap__java_lang_String($thisArg, propertyName) {
    JsPropertyMap_$Overlay.$clinit();
    InternalJsUtil.deleteIndexed($thisArg, propertyName);
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?string} propertyName
   * @param {C_T} value
   * @return {void}
   * @public
   */
  static m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object($thisArg, propertyName, value) {
    JsPropertyMap_$Overlay.$clinit();
    InternalJsUtil.setIndexed($thisArg, propertyName, value);
  }
  
  /**
   * @template C_T
   * @param {Object<string, C_T>} $thisArg
   * @param {?function(?string):void} cb
   * @return {void}
   * @public
   */
  static m_forEach__jsinterop_base_JsPropertyMap__jsinterop_base_JsForEachCallbackFn($thisArg, cb) {
    JsPropertyMap_$Overlay.$clinit();
    InternalJsUtil.forEach($thisArg, cb);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    JsPropertyMap_$Overlay.$clinit = (() =>{
    });
    JsPropertyMap_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_Object = goog.module.get('java.lang.Object$impl');
    $Overlay = goog.module.get('jsinterop.base.Any.$Overlay$impl');
    InternalJsUtil = goog.module.get('jsinterop.base.InternalJsUtil$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = JsPropertyMap_$Overlay; 
//# sourceMappingURL=JsPropertyMap$$Overlay.js.map