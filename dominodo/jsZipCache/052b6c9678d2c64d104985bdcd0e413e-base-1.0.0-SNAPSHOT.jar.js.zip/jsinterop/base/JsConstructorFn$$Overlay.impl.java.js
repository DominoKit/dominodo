/**
 * @fileoverview transpiled from jsinterop.base.JsConstructorFn$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('jsinterop.base.JsConstructorFn.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class');
let j_l_Class = goog.forwardDeclare('java.lang.Class$impl');
let InternalPreconditions = goog.forwardDeclare('jsinterop.base.InternalPreconditions$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');


class $Overlay {
  /**
   * @template C_T
   * @param {?function(...*):void} $thisArg
   * @param {Array<*>} args
   * @return {C_T}
   * @public
   */
  static m_construct__jsinterop_base_JsConstructorFn__arrayOf_java_lang_Object($thisArg, args) {
    $Overlay.$clinit();
    return Reflect.construct($thisArg, args);
  }
  
  /**
   * @template C_T
   * @param {?function(...*):void} $thisArg
   * @return {j_l_Class<C_T>}
   * @public
   */
  static m_asClass__jsinterop_base_JsConstructorFn($thisArg) {
    $Overlay.$clinit();
    let clazz = /**@type {j_l_Class<*>} */ (Class.$get($thisArg));
    InternalPreconditions.m_checkType__boolean(!$Equality.$same(clazz, null));
    return clazz;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Class = goog.module.get('java.lang.Class');
    InternalPreconditions = goog.module.get('jsinterop.base.InternalPreconditions$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
  }
  
  
};



exports = $Overlay; 
//# sourceMappingURL=JsConstructorFn$$Overlay.js.map