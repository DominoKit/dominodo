/**
 * @fileoverview transpiled from jsinterop.base.JsConstructorFn$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('jsinterop.base.JsConstructorFn.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _InternalPreconditions = goog.require('jsinterop.base.InternalPreconditions');
const _$Equality = goog.require('nativebootstrap.Equality');


// Re-exports the implementation.
var $Overlay = goog.require('jsinterop.base.JsConstructorFn.$Overlay$impl');
exports = $Overlay;
 