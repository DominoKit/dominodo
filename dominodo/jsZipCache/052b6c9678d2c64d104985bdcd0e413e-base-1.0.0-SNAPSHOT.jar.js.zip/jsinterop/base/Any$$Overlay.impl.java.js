/**
 * @fileoverview transpiled from jsinterop.base.Any$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('jsinterop.base.Any.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');
let $Long = goog.forwardDeclare('nativebootstrap.Long$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Any_$Overlay {
  /**
   * @param {*} $thisArg
   * @return {Object<string, *>}
   * @public
   */
  static m_asPropertyMap__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asPropertyMap__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {IArrayLike<*>}
   * @public
   */
  static m_asArrayLike__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asArrayLike__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {Array<*>}
   * @public
   */
  static m_asArray__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asArray__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {?string}
   * @public
   */
  static m_asString__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asString__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {boolean}
   * @public
   */
  static m_asBoolean__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asBoolean__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {number}
   * @public
   */
  static m_asDouble__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asDouble__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {number}
   * @public
   */
  static m_asFloat__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asFloat__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {!$Long}
   * @public
   */
  static m_asLong__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asLong__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {number}
   * @public
   */
  static m_asInt__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asInt__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {number}
   * @public
   */
  static m_asShort__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asShort__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {number}
   * @public
   */
  static m_asChar__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asChar__java_lang_Object($thisArg);
  }
  
  /**
   * @param {*} $thisArg
   * @return {number}
   * @public
   */
  static m_asByte__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return Js.m_asByte__java_lang_Object($thisArg);
  }
  
  /**
   * @template M_T
   * @param {*} $thisArg
   * @return {M_T}
   * @public
   */
  static m_cast__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return /**@type {*} */ ($Casts.$to($thisArg, j_l_Object));
  }
  
  /**
   * @template M_T
   * @param {*} $thisArg
   * @return {M_T}
   * @public
   */
  static m_uncheckedCast__jsinterop_base_Any($thisArg) {
    Any_$Overlay.$clinit();
    return /**@type {*} */ ($Casts.$to($thisArg, j_l_Object));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Any_$Overlay.$clinit = (() =>{
    });
    Any_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = Any_$Overlay; 
//# sourceMappingURL=Any$$Overlay.js.map