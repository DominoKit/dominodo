/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_af.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_af$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


class DateTimeFormatInfoImpl__af extends DateTimeFormatInfoImpl {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!DateTimeFormatInfoImpl__af}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__af.$clinit();
    let $instance = new DateTimeFormatInfoImpl__af();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_af__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_af__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__();
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_ampms__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["vm.", "nm."], j_l_String));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatFull__() {
    return "EEEE, dd MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatLong__() {
    return "dd MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatMedium__() {
    return "dd MMM y";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["voor Christus", "na Christus"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["v.C.", "n.C."], j_l_String));
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_firstDayOfTheWeek__() {
    return 0;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthAbbrevDay__() {
    return "d MMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullDay__() {
    return "d MMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullWeekdayDay__() {
    return "EEEE d MMMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthNumDay__() {
    return "dd-MM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrev__() {
    return "MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrevDay__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFull__() {
    return "MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFullDay__() {
    return "d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNum__() {
    return "MM-y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNumDay__() {
    return "y-MM-dd";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthWeekdayDay__() {
    return "EEE, d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterFull__() {
    return "QQQQ y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterShort__() {
    return "Q y";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Januarie", "Februarie", "Maart", "April", "Mei", "Junie", "Julie", "Augustus", "September", "Oktober", "November", "Desember"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Jan.", "Feb.", "Mrt.", "Apr.", "Mei", "Jun.", "Jul.", "Aug.", "Sep.", "Okt.", "Nov.", "Des."], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["1ste kwartaal", "2de kwartaal", "3de kwartaal", "4de kwartaal"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["K1", "K2", "K3", "K4"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Sondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrydag", "Saterdag"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["S", "M", "D", "W", "D", "V", "S"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["So.", "Ma.", "Di.", "Wo.", "Do.", "Vr.", "Sa."], j_l_String));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__af.$clinit = (() =>{
    });
    DateTimeFormatInfoImpl__af.$loadModules();
    DateTimeFormatInfoImpl.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__af;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__af);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__af, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_af'));




exports = DateTimeFormatInfoImpl__af; 
//# sourceMappingURL=DateTimeFormatInfoImpl_af.js.map