package elemental2.svg;

import elemental2.dom.Document;
import elemental2.dom.Event;
import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGDocument extends Document {
  public SVGSVGElement rootElement;

  public native Event createEvent();

  public native Event createEvent(String eventType);
}
