/**
 * @fileoverview transpiled from elemental2.svg.SVGFETurbulenceElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFETurbulenceElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_STITCHTYPE_NOSTITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_STITCHTYPE_NOSTITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_STITCHTYPE_NOSTITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_STITCHTYPE_NOSTITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_STITCHTYPE_STITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_STITCHTYPE_STITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_STITCHTYPE_STITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_STITCHTYPE_STITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_STITCHTYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_STITCHTYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_STITCHTYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_STITCHTYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_TURBULENCE_TYPE_FRACTALNOISE__elemental2_svg_SVGFETurbulenceElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_TURBULENCE_TYPE_FRACTALNOISE__elemental2_svg_SVGFETurbulenceElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_TURBULENCE_TYPE_FRACTALNOISE__elemental2_svg_SVGFETurbulenceElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_TURBULENCE_TYPE_FRACTALNOISE__elemental2_svg_SVGFETurbulenceElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_TURBULENCE_TYPE_TURBULENCE__elemental2_svg_SVGFETurbulenceElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_TURBULENCE_TYPE_TURBULENCE__elemental2_svg_SVGFETurbulenceElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_TURBULENCE_TYPE_TURBULENCE__elemental2_svg_SVGFETurbulenceElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_TURBULENCE_TYPE_TURBULENCE__elemental2_svg_SVGFETurbulenceElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_TURBULENCE_TYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_TURBULENCE_TYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_TURBULENCE_TYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_TURBULENCE_TYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_STITCHTYPE_NOSTITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay = SVGFETurbulenceElement.SVG_STITCHTYPE_NOSTITCH;
    $Overlay.$f_SVG_STITCHTYPE_STITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay = SVGFETurbulenceElement.SVG_STITCHTYPE_STITCH;
    $Overlay.$f_SVG_STITCHTYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay = SVGFETurbulenceElement.SVG_STITCHTYPE_UNKNOWN;
    $Overlay.$f_SVG_TURBULENCE_TYPE_FRACTALNOISE__elemental2_svg_SVGFETurbulenceElement_$Overlay = SVGFETurbulenceElement.SVG_TURBULENCE_TYPE_FRACTALNOISE;
    $Overlay.$f_SVG_TURBULENCE_TYPE_TURBULENCE__elemental2_svg_SVGFETurbulenceElement_$Overlay = SVGFETurbulenceElement.SVG_TURBULENCE_TYPE_TURBULENCE;
    $Overlay.$f_SVG_TURBULENCE_TYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay = SVGFETurbulenceElement.SVG_TURBULENCE_TYPE_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFETurbulenceElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFETurbulenceElement'));


/** @private {number} */
$Overlay.$f_SVG_STITCHTYPE_NOSTITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_STITCHTYPE_STITCH__elemental2_svg_SVGFETurbulenceElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_STITCHTYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_TURBULENCE_TYPE_FRACTALNOISE__elemental2_svg_SVGFETurbulenceElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_TURBULENCE_TYPE_TURBULENCE__elemental2_svg_SVGFETurbulenceElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_TURBULENCE_TYPE_UNKNOWN__elemental2_svg_SVGFETurbulenceElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGFETurbulenceElement$$Overlay.js.map