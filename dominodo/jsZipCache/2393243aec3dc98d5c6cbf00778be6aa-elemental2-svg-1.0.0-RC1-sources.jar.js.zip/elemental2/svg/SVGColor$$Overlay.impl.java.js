/**
 * @fileoverview transpiled from elemental2.svg.SVGColor$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGColor.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_COLORTYPE_CURRENTCOLOR__elemental2_svg_SVGColor_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_CURRENTCOLOR__elemental2_svg_SVGColor_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_COLORTYPE_CURRENTCOLOR__elemental2_svg_SVGColor_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_CURRENTCOLOR__elemental2_svg_SVGColor_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_COLORTYPE_RGBCOLOR__elemental2_svg_SVGColor_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_RGBCOLOR__elemental2_svg_SVGColor_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_COLORTYPE_RGBCOLOR__elemental2_svg_SVGColor_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_RGBCOLOR__elemental2_svg_SVGColor_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_COLORTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGColor_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGColor_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_COLORTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGColor_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGColor_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_COLORTYPE_UNKNOWN__elemental2_svg_SVGColor_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_UNKNOWN__elemental2_svg_SVGColor_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_COLORTYPE_UNKNOWN__elemental2_svg_SVGColor_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_COLORTYPE_UNKNOWN__elemental2_svg_SVGColor_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_COLORTYPE_CURRENTCOLOR__elemental2_svg_SVGColor_$Overlay = SVGColor.SVG_COLORTYPE_CURRENTCOLOR;
    $Overlay.$f_SVG_COLORTYPE_RGBCOLOR__elemental2_svg_SVGColor_$Overlay = SVGColor.SVG_COLORTYPE_RGBCOLOR;
    $Overlay.$f_SVG_COLORTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGColor_$Overlay = SVGColor.SVG_COLORTYPE_RGBCOLOR_ICCCOLOR;
    $Overlay.$f_SVG_COLORTYPE_UNKNOWN__elemental2_svg_SVGColor_$Overlay = SVGColor.SVG_COLORTYPE_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGColor;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGColor'));


/** @private {number} */
$Overlay.$f_SVG_COLORTYPE_CURRENTCOLOR__elemental2_svg_SVGColor_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_COLORTYPE_RGBCOLOR__elemental2_svg_SVGColor_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_COLORTYPE_RGBCOLOR_ICCCOLOR__elemental2_svg_SVGColor_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_COLORTYPE_UNKNOWN__elemental2_svg_SVGColor_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGColor$$Overlay.js.map