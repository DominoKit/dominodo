package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsProperty;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGMPathElement extends SVGElement
    implements SVGExternalResourcesRequired, SVGURIReference {
  public SVGAnimatedBoolean externalResourcesRequired;
  public SVGAnimatedString href;

  @JsProperty
  public native SVGAnimatedBoolean getExternalResourcesRequired();

  @JsProperty
  public native SVGAnimatedString getHref();

  @JsProperty
  public native void setExternalResourcesRequired(SVGAnimatedBoolean externalResourcesRequired);

  @JsProperty
  public native void setHref(SVGAnimatedString href);
}
