/**
 * @fileoverview transpiled from elemental2.svg.SVGComponentTransferFunctionElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGComponentTransferFunctionElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPONENTTRANSFER_TYPE_GAMMA__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_GAMMA__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPONENTTRANSFER_TYPE_GAMMA__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_GAMMA__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPONENTTRANSFER_TYPE_LINEAR__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_LINEAR__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPONENTTRANSFER_TYPE_LINEAR__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_LINEAR__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPONENTTRANSFER_TYPE_TABLE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_TABLE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPONENTTRANSFER_TYPE_TABLE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_TABLE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = SVGComponentTransferFunctionElement.SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE;
    $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_GAMMA__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = SVGComponentTransferFunctionElement.SVG_FECOMPONENTTRANSFER_TYPE_GAMMA;
    $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = SVGComponentTransferFunctionElement.SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY;
    $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_LINEAR__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = SVGComponentTransferFunctionElement.SVG_FECOMPONENTTRANSFER_TYPE_LINEAR;
    $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_TABLE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = SVGComponentTransferFunctionElement.SVG_FECOMPONENTTRANSFER_TYPE_TABLE;
    $Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = SVGComponentTransferFunctionElement.SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGComponentTransferFunctionElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGComponentTransferFunctionElement'));


/** @private {number} */
$Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_DISCRETE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_GAMMA__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_IDENTITY__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_LINEAR__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_TABLE__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPONENTTRANSFER_TYPE_UNKNOWN__elemental2_svg_SVGComponentTransferFunctionElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGComponentTransferFunctionElement$$Overlay.js.map