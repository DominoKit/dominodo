/**
 * @fileoverview transpiled from org.gwtproject.timer.client.Timer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.timer.client.Timer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Double = goog.require('java.lang.Double');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var Timer = goog.require('org.gwtproject.timer.client.Timer$impl');
exports = Timer;
 