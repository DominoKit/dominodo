/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.group.JustifiedGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.group.JustifiedGroup$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const IsGroup = goog.require('org.dominokit.domino.ui.button.group.IsGroup$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');


/**
 * @extends {BaseDominoElement<HTMLElement, JustifiedGroup>}
 * @implements {IsGroup<HTMLElement>}
 * @implements {Sizable<JustifiedGroup>}
  */
class JustifiedGroup extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {ButtonsGroup} */
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_;
  }
  
  /**
   * @return {JustifiedGroup}
   * @public
   */
  static m_create__() {
    JustifiedGroup.$clinit();
    return JustifiedGroup.$create__();
  }
  
  /**
   * @return {!JustifiedGroup}
   * @public
   */
  static $create__() {
    JustifiedGroup.$clinit();
    let $instance = new JustifiedGroup();
    $instance.$ctor__org_dominokit_domino_ui_button_group_JustifiedGroup__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_group_JustifiedGroup__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_button_group_JustifiedGroup();
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_style__().m_add__java_lang_String(j_l_String.m_valueOf__java_lang_Object(ButtonsGroup.f_BTN_GROUP__org_dominokit_domino_ui_button_group_ButtonsGroup) + "-justified");
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @override
   * @param {Button} button
   * @return {HTMLElement}
   * @public
   * @deprecated
   */
  m_addButton__org_dominokit_domino_ui_button_Button(button) {
    return this.m_appendChild__org_dominokit_domino_ui_button_Button(button);
  }
  
  /**
   * @override
   * @param {DropdownButton} dropDown
   * @return {HTMLElement}
   * @public
   */
  m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(dropDown) {
    return this.m_appendChild__org_dominokit_domino_ui_button_DropdownButton(dropDown);
  }
  
  /**
   * @override
   * @param {Button} button
   * @return {HTMLElement}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_button_Button(button) {
    let justify = button.m_asElement__();
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_appendChild__elemental2_dom_Node(justify);
    return justify;
  }
  
  /**
   * @override
   * @param {DropdownButton} dropDown
   * @return {HTMLElement}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_button_DropdownButton(dropDown) {
    let justify = dropDown.m_asElement__();
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_appendChild__elemental2_dom_Node(justify);
    return justify;
  }
  
  /**
   * @override
   * @return {IsGroup<HTMLElement>}
   * @public
   */
  m_verticalAlign__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_verticalAlign__();
    return this;
  }
  
  /**
   * @override
   * @return {IsGroup<HTMLElement>}
   * @public
   */
  m_horizontalAlign__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_horizontalAlign__();
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_asElement__();
  }
  
  /**
   * @override
   * @return {JustifiedGroup}
   * @public
   */
  m_large__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_large__();
    return this;
  }
  
  /**
   * @override
   * @return {JustifiedGroup}
   * @public
   */
  m_small__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_small__();
    return this;
  }
  
  /**
   * @override
   * @return {JustifiedGroup}
   * @public
   */
  m_xSmall__() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_.m_xSmall__();
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_group_JustifiedGroup() {
    this.f_group__org_dominokit_domino_ui_button_group_JustifiedGroup_ = ButtonsGroup.m_create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    JustifiedGroup.$clinit = (() =>{
    });
    JustifiedGroup.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof JustifiedGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, JustifiedGroup);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    ButtonsGroup = goog.module.get('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
  }
  
  
};

$Util.$setClassMetadata(JustifiedGroup, $Util.$makeClassName('org.dominokit.domino.ui.button.group.JustifiedGroup'));


IsGroup.$markImplementor(JustifiedGroup);
Sizable.$markImplementor(JustifiedGroup);


exports = JustifiedGroup; 
//# sourceMappingURL=JustifiedGroup.js.map