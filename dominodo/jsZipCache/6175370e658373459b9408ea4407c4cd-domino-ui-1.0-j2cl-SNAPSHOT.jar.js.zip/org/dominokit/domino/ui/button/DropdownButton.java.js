/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.DropdownButton.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.DropdownButton');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseButton = goog.require('org.dominokit.domino.ui.button.BaseButton');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _$LambdaAdaptor$4 = goog.require('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$4');
const _ButtonsGroup = goog.require('org.dominokit.domino.ui.button.group.ButtonsGroup');
const _DropDownMenu = goog.require('org.dominokit.domino.ui.dropdown.DropDownMenu');
const _DropDownPosition = goog.require('org.dominokit.domino.ui.dropdown.DropDownPosition');
const _DropdownAction = goog.require('org.dominokit.domino.ui.dropdown.DropdownAction');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton$impl');
exports = DropdownButton;
 