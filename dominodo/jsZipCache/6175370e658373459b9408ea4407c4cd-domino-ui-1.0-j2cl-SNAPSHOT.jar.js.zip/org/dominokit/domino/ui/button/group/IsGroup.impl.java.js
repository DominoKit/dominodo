/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.group.IsGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.group.IsGroup$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');


/**
 * @interface
 * @template C_T
 */
class IsGroup {
  /**
   * @abstract
   * @param {Button} button
   * @return {C_T}
   * @public
   * @deprecated
   */
  m_addButton__org_dominokit_domino_ui_button_Button(button) {
  }
  
  /**
   * @abstract
   * @param {Button} button
   * @return {C_T}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_button_Button(button) {
  }
  
  /**
   * @abstract
   * @param {DropdownButton} dropDown
   * @return {C_T}
   * @public
   * @deprecated
   */
  m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(dropDown) {
  }
  
  /**
   * @abstract
   * @param {DropdownButton} dropDown
   * @return {C_T}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_button_DropdownButton(dropDown) {
  }
  
  /**
   * @abstract
   * @return {IsGroup<C_T>}
   * @public
   */
  m_verticalAlign__() {
  }
  
  /**
   * @abstract
   * @return {IsGroup<C_T>}
   * @public
   */
  m_horizontalAlign__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    IsGroup.$clinit = (() =>{
    });
    IsGroup.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_button_group_IsGroup = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_button_group_IsGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_button_group_IsGroup;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(IsGroup, $Util.$makeClassName('org.dominokit.domino.ui.button.group.IsGroup'));


IsGroup.$markImplementor(/** @type {Function} */ (IsGroup));


exports = IsGroup; 
//# sourceMappingURL=IsGroup.js.map