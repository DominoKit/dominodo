/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Collapsible$ExpandCompletedHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ExpandCompletedHandler = goog.require('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler$impl');


/**
 * @implements {ExpandCompletedHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function():void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():void} */
    this.f_$$fn__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$LambdaAdaptor__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$JsFunction(fn);
  }
  
  /**
   * @param {?function():void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$LambdaAdaptor__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onExpanded__() {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$LambdaAdaptor;
      $function();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.Collapsible$ExpandCompletedHandler$$LambdaAdaptor'));


ExpandCompletedHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Collapsible$ExpandCompletedHandler$$LambdaAdaptor.js.map