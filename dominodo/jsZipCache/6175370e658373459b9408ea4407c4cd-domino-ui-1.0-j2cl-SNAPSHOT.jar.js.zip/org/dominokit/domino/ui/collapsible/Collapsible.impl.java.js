/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Collapsible.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.Collapsible$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let CollapseCompletedHandler = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler$impl');
let ExpandCompletedHandler = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');


/**
 * @implements {IsElement<HTMLElement>}
 * @implements {IsCollapsible<Collapsible>}
  */
class Collapsible extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_;
    /** @public {Style<HTMLElement, IsElement<HTMLElement>>} */
    this.f_style__org_dominokit_domino_ui_collapsible_Collapsible_;
    /** @public {boolean} */
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = false;
    /** @public {CollapseCompletedHandler} */
    this.f_onCollapsed__org_dominokit_domino_ui_collapsible_Collapsible_;
    /** @public {ExpandCompletedHandler} */
    this.f_onExpanded__org_dominokit_domino_ui_collapsible_Collapsible_;
    /** @public {List<CollapseCompletedHandler>} */
    this.f_collapseHandlers__org_dominokit_domino_ui_collapsible_Collapsible_;
    /** @public {List<ExpandCompletedHandler>} */
    this.f_expandHandlers__org_dominokit_domino_ui_collapsible_Collapsible_;
  }
  
  /**
   * @param {HTMLElement} element
   * @return {!Collapsible}
   * @public
   */
  static $create__elemental2_dom_HTMLElement(element) {
    Collapsible.$clinit();
    let $instance = new Collapsible();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_Collapsible__elemental2_dom_HTMLElement(element);
    return $instance;
  }
  
  /**
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_Collapsible__elemental2_dom_HTMLElement(element) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_collapsible_Collapsible();
    this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_ = element;
    this.f_style__org_dominokit_domino_ui_collapsible_Collapsible_ = /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element));
  }
  
  /**
   * @param {HTMLElement} element
   * @return {Collapsible}
   * @public
   */
  static m_create__elemental2_dom_HTMLElement(element) {
    Collapsible.$clinit();
    return Collapsible.$create__elemental2_dom_HTMLElement(element);
  }
  
  /**
   * @param {IsElement} isElement
   * @return {Collapsible}
   * @public
   */
  static m_create__org_jboss_gwt_elemento_core_IsElement(isElement) {
    Collapsible.$clinit();
    return Collapsible.m_create__elemental2_dom_HTMLElement(isElement.m_asElement__());
  }
  
  /**
   * @override
   * @return {Collapsible}
   * @public
   */
  m_collapse__() {
    this.f_style__org_dominokit_domino_ui_collapsible_Collapsible_.m_setDisplay__java_lang_String("none");
    this.m_onCollapseCompleted___$p_org_dominokit_domino_ui_collapsible_Collapsible();
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = true;
    return this;
  }
  
  /**
   * @override
   * @return {Collapsible}
   * @public
   */
  m_expand__() {
    this.m_onExpandCompleted___$p_org_dominokit_domino_ui_collapsible_Collapsible();
    this.f_style__org_dominokit_domino_ui_collapsible_Collapsible_.m_removeProperty__java_lang_String("display");
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = false;
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onCollapseCompleted___$p_org_dominokit_domino_ui_collapsible_Collapsible() {
    this.f_onCollapsed__org_dominokit_domino_ui_collapsible_Collapsible_.m_onCollapsed__();
    this.f_collapseHandlers__org_dominokit_domino_ui_collapsible_Collapsible_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** CollapseCompletedHandler */ arg0) =>{
      arg0.m_onCollapsed__();
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_onExpandCompleted___$p_org_dominokit_domino_ui_collapsible_Collapsible() {
    this.f_onExpanded__org_dominokit_domino_ui_collapsible_Collapsible_.m_onExpanded__();
    this.f_expandHandlers__org_dominokit_domino_ui_collapsible_Collapsible_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ExpandCompletedHandler */ arg0) =>{
      arg0.m_onExpanded__();
    })));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isCollapsed__() {
    return this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_;
  }
  
  /**
   * @override
   * @return {Collapsible}
   * @public
   */
  m_toggleDisplay__() {
    if (this.m_isCollapsed__()) {
      this.m_expand__();
    } else {
      this.m_collapse__();
    }
    return this;
  }
  
  /**
   * @override
   * @param {boolean} state
   * @return {Collapsible}
   * @public
   */
  m_toggleDisplay__boolean(state) {
    if (state) {
      this.m_expand__();
    } else {
      this.m_collapse__();
    }
    return this;
  }
  
  /**
   * @param {CollapseCompletedHandler} onCollapsed
   * @return {void}
   * @public
   */
  m_setOnCollapsed__org_dominokit_domino_ui_collapsible_Collapsible_CollapseCompletedHandler_$pp_org_dominokit_domino_ui_collapsible(onCollapsed) {
    this.f_onCollapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = onCollapsed;
  }
  
  /**
   * @param {ExpandCompletedHandler} onExpanded
   * @return {void}
   * @public
   */
  m_setOnExpanded__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler_$pp_org_dominokit_domino_ui_collapsible(onExpanded) {
    this.f_onExpanded__org_dominokit_domino_ui_collapsible_Collapsible_ = onExpanded;
  }
  
  /**
   * @param {CollapseCompletedHandler} handler
   * @return {Collapsible}
   * @public
   */
  m_addCollapseHandler__org_dominokit_domino_ui_collapsible_Collapsible_CollapseCompletedHandler(handler) {
    this.f_collapseHandlers__org_dominokit_domino_ui_collapsible_Collapsible_.add(handler);
    return this;
  }
  
  /**
   * @param {CollapseCompletedHandler} handler
   * @return {void}
   * @public
   */
  m_removeCollapseHandler__org_dominokit_domino_ui_collapsible_Collapsible_CollapseCompletedHandler(handler) {
    this.f_collapseHandlers__org_dominokit_domino_ui_collapsible_Collapsible_.remove(handler);
  }
  
  /**
   * @param {ExpandCompletedHandler} handler
   * @return {Collapsible}
   * @public
   */
  m_addExpandHandler__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler(handler) {
    this.f_expandHandlers__org_dominokit_domino_ui_collapsible_Collapsible_.add(handler);
    return this;
  }
  
  /**
   * @param {ExpandCompletedHandler} handler
   * @return {void}
   * @public
   */
  m_removeExpandHandlr__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler(handler) {
    this.f_expandHandlers__org_dominokit_domino_ui_collapsible_Collapsible_.remove(handler);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_collapsible_Collapsible_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_collapsible_Collapsible() {
    this.f_collapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = false;
    this.f_onCollapsed__org_dominokit_domino_ui_collapsible_Collapsible_ = CollapseCompletedHandler.$adapt((() =>{
    }));
    this.f_onExpanded__org_dominokit_domino_ui_collapsible_Collapsible_ = ExpandCompletedHandler.$adapt((() =>{
    }));
    this.f_collapseHandlers__org_dominokit_domino_ui_collapsible_Collapsible_ = /**@type {!ArrayList<CollapseCompletedHandler>} */ (ArrayList.$create__());
    this.f_expandHandlers__org_dominokit_domino_ui_collapsible_Collapsible_ = /**@type {!ArrayList<ExpandCompletedHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Collapsible.$clinit = (() =>{
    });
    Collapsible.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Collapsible;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Collapsible);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    CollapseCompletedHandler = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler$impl');
    ExpandCompletedHandler = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
  }
  
  
};

$Util.$setClassMetadata(Collapsible, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.Collapsible'));


IsElement.$markImplementor(Collapsible);
IsCollapsible.$markImplementor(Collapsible);


exports = Collapsible; 
//# sourceMappingURL=Collapsible.js.map