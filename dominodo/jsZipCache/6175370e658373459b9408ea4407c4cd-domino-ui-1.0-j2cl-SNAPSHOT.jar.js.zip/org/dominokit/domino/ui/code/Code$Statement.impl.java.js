/**
 * @fileoverview transpiled from org.dominokit.domino.ui.code.Code$Statement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.code.Code.Statement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


/**
 * @implements {IsElement<HTMLElement>}
  */
class Statement extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_code_Code_Statement_;
  }
  
  /**
   * @param {HTMLElement} element
   * @return {!Statement}
   * @public
   */
  static $create__elemental2_dom_HTMLElement(element) {
    Statement.$clinit();
    let $instance = new Statement();
    $instance.$ctor__org_dominokit_domino_ui_code_Code_Statement__elemental2_dom_HTMLElement(element);
    return $instance;
  }
  
  /**
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_code_Code_Statement__elemental2_dom_HTMLElement(element) {
    this.$ctor__java_lang_Object__();
    this.f_element__org_dominokit_domino_ui_code_Code_Statement_ = element;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_code_Code_Statement_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Statement.$clinit = (() =>{
    });
    Statement.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Statement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Statement);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(Statement, $Util.$makeClassName('org.dominokit.domino.ui.code.Code$Statement'));


IsElement.$markImplementor(Statement);


exports = Statement; 
//# sourceMappingURL=Code$Statement.js.map