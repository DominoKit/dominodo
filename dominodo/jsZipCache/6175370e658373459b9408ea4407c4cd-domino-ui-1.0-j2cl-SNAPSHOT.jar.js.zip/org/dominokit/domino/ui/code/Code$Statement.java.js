/**
 * @fileoverview transpiled from org.dominokit.domino.ui.code.Code$Statement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.code.Code.Statement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');


// Re-exports the implementation.
var Statement = goog.require('org.dominokit.domino.ui.code.Code.Statement$impl');
exports = Statement;
 