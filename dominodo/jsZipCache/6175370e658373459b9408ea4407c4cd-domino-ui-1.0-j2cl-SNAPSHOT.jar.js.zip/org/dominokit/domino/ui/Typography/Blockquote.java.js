/**
 * @fileoverview transpiled from org.dominokit.domino.ui.Typography.Blockquote.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.Typography.Blockquote');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLQuoteElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Paragraph = goog.require('org.dominokit.domino.ui.Typography.Paragraph');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _TextNode = goog.require('org.dominokit.domino.ui.utils.TextNode');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Blockquote = goog.require('org.dominokit.domino.ui.Typography.Blockquote$impl');
exports = Blockquote;
 