/**
 * @fileoverview transpiled from org.dominokit.domino.ui.Typography.Strong.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.Typography.Strong');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');


// Re-exports the implementation.
var Strong = goog.require('org.dominokit.domino.ui.Typography.Strong$impl');
exports = Strong;
 