/**
 * @fileoverview transpiled from org.dominokit.domino.ui.alerts.AlertLink.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.alerts.AlertLink');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');


// Re-exports the implementation.
var AlertLink = goog.require('org.dominokit.domino.ui.alerts.AlertLink$impl');
exports = AlertLink;
 