/**
 * @fileoverview transpiled from org.dominokit.domino.ui.alerts.Alert.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.alerts.Alert$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLButtonElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLButtonElement.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Strong = goog.forwardDeclare('org.dominokit.domino.ui.Typography.Strong$impl');
let $LambdaAdaptor$1 = goog.forwardDeclare('org.dominokit.domino.ui.alerts.Alert.$LambdaAdaptor$1$impl');
let AlertType = goog.forwardDeclare('org.dominokit.domino.ui.alerts.Alert.AlertType$impl');
let AlertLink = goog.forwardDeclare('org.dominokit.domino.ui.alerts.AlertLink$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, Alert>}
 * @implements {HasBackground<Alert>}
  */
class Alert extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_alerts_Alert_;
    /** @public {boolean} */
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = false;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_element__org_dominokit_domino_ui_alerts_Alert_;
    /** @public {HTMLButtonElement} */
    this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_;
  }
  
  /**
   * @return {!Alert}
   * @public
   */
  static $create__() {
    Alert.$clinit();
    let $instance = new Alert();
    $instance.$ctor__org_dominokit_domino_ui_alerts_Alert__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_alerts_Alert__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_alerts_Alert();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {?string} style
   * @return {Alert}
   * @public
   */
  static m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(style) {
    Alert.$clinit();
    let alert = Alert.m_create__();
    alert.f_element__org_dominokit_domino_ui_alerts_Alert_.m_style__().m_add__java_lang_String(style);
    alert.f_style__org_dominokit_domino_ui_alerts_Alert_ = style;
    return alert;
  }
  
  /**
   * @param {Color} background
   * @return {Alert}
   * @public
   */
  static m_create__org_dominokit_domino_ui_style_Color(background) {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(background.m_getBackground__());
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_create__() {
    Alert.$clinit();
    let alert = Alert.$create__();
    alert.f_closeButton__org_dominokit_domino_ui_alerts_Alert_.addEventListener("click", new $LambdaAdaptor$1(((/** Event */ e) =>{
      alert.m_asElement__().remove();
    })));
    return alert;
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_success__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_SUCCESS__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_info__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_INFO__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_warning__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_WARNING__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @return {Alert}
   * @public
   */
  static m_error__() {
    Alert.$clinit();
    return Alert.m_create__java_lang_String_$p_org_dominokit_domino_ui_alerts_Alert(AlertType.f_ERROR__org_dominokit_domino_ui_alerts_Alert_AlertType.f_typeStyle__org_dominokit_domino_ui_alerts_Alert_AlertType_);
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {Alert}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_style__org_dominokit_domino_ui_alerts_Alert_)) {
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_style__().m_remove__java_lang_String(this.f_style__org_dominokit_domino_ui_alerts_Alert_);
    }
    this.f_style__org_dominokit_domino_ui_alerts_Alert_ = background.m_getBackground__();
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_style__().m_add__java_lang_String(this.f_style__org_dominokit_domino_ui_alerts_Alert_);
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {Alert}
   * @public
   * @deprecated
   */
  m_appendStrong__java_lang_String(text) {
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_appendChild__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_strong__().m_textContent__java_lang_String(text), HtmlContentBuilder)).m_asElement__());
    return this;
  }
  
  /**
   * @param {Strong} strong
   * @return {Alert}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_Typography_Strong(strong) {
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_appendChild__elemental2_dom_Node(strong.m_asElement__());
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {Alert}
   * @public
   * @deprecated
   */
  m_appendText__java_lang_String(text) {
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(text));
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {Alert}
   * @public
   */
  m_appendChild__java_lang_String(text) {
    this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_appendChild__elemental2_dom_Node(TextNode.m_of__java_lang_String(text));
    return this;
  }
  
  /**
   * @param {HTMLAnchorElement} anchorElement
   * @return {Alert}
   * @public
   * @deprecated
   */
  m_appendLink__elemental2_dom_HTMLAnchorElement(anchorElement) {
    return this.m_appendChild__elemental2_dom_HTMLAnchorElement(anchorElement);
  }
  
  /**
   * @param {HTMLAnchorElement} anchorElement
   * @return {Alert}
   * @public
   */
  m_appendChild__elemental2_dom_HTMLAnchorElement(anchorElement) {
    if (Objects.m_nonNull__java_lang_Object(anchorElement)) {
      /**@type {Style<HTMLAnchorElement, IsElement<HTMLAnchorElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(anchorElement)).m_add__java_lang_String(Styles.f_alert_link__org_dominokit_domino_ui_style_Styles);
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_appendChild__elemental2_dom_Node(anchorElement);
    }
    return this;
  }
  
  /**
   * @param {IsElement<HTMLAnchorElement>} anchorElement
   * @return {Alert}
   * @public
   * @deprecated
   */
  m_appendLink__org_jboss_gwt_elemento_core_IsElement(anchorElement) {
    return this.m_appendChild__elemental2_dom_HTMLAnchorElement(/**@type {HTMLAnchorElement} */ ($Casts.$to(anchorElement.m_asElement__(), $Overlay)));
  }
  
  /**
   * @param {AlertLink} alertLink
   * @return {Alert}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_alerts_AlertLink(alertLink) {
    return this.m_appendChild__elemental2_dom_HTMLAnchorElement(alertLink.m_asElement__());
  }
  
  /**
   * @param {boolean} dismissible
   * @return {Alert}
   * @public
   */
  m_setDissmissible__boolean(dismissible) {
    if (dismissible) {
      return this.m_dismissible__();
    } else {
      return this.m_unDismissible__();
    }
  }
  
  /**
   * @return {Alert}
   * @public
   */
  m_dismissible__() {
    if (!this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_) {
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_style__().m_add__java_lang_String("alert-dismissible");
      if (this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_getChildElementCount__() > 0) {
        this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_insertFirst__elemental2_dom_Node(this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_);
      } else {
        this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_appendChild__elemental2_dom_Node(this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_);
      }
    }
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = true;
    return this;
  }
  
  /**
   * @return {Alert}
   * @public
   */
  m_unDismissible__() {
    if (this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_) {
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_style__().m_remove__java_lang_String("alert-dismissible");
      this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_removeChild__elemental2_dom_Node(this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_);
    }
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = false;
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isDismissible__() {
    return this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_alerts_Alert_.m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_alerts_Alert() {
    this.f_dismissible__org_dominokit_domino_ui_alerts_Alert_ = false;
    this.f_element__org_dominokit_domino_ui_alerts_Alert_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["alert"], j_l_String)))));
    this.f_closeButton__org_dominokit_domino_ui_alerts_Alert_ = /**@type {HTMLButtonElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLButtonElement>} */ ($Casts.$to(Elements.m_button__().m_attr__java_lang_String__java_lang_String("type", "button"), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["close"], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("aria-label", "Close"), HtmlContentBuilder)).m_add__elemental2_dom_Node(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_attr__java_lang_String__java_lang_String("aria-hidden", "true"), HtmlContentBuilder)).m_textContent__java_lang_String("\u00D7"), HtmlContentBuilder)).m_asElement__()), HtmlContentBuilder)).m_asElement__(), HTMLButtonElement_$Overlay));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Alert.$clinit = (() =>{
    });
    Alert.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Alert;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Alert);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    HTMLButtonElement_$Overlay = goog.module.get('elemental2.dom.HTMLButtonElement.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $LambdaAdaptor$1 = goog.module.get('org.dominokit.domino.ui.alerts.Alert.$LambdaAdaptor$1$impl');
    AlertType = goog.module.get('org.dominokit.domino.ui.alerts.Alert.AlertType$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Alert, $Util.$makeClassName('org.dominokit.domino.ui.alerts.Alert'));


HasBackground.$markImplementor(Alert);


exports = Alert; 
//# sourceMappingURL=Alert.js.map