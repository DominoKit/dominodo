/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Animation$StartHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.animations.Animation.StartHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.animations.Animation.StartHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class StartHandler {
  /**
   * @abstract
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  m_beforeStart__elemental2_dom_HTMLElement(element) {
  }
  
  /**
   * @param {?function(HTMLElement):void} fn
   * @return {StartHandler}
   * @public
   */
  static $adapt(fn) {
    StartHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    StartHandler.$clinit = (() =>{
    });
    StartHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_animations_Animation_StartHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_animations_Animation_StartHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_animations_Animation_StartHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.animations.Animation.StartHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(StartHandler, $Util.$makeClassName('org.dominokit.domino.ui.animations.Animation$StartHandler'));


StartHandler.$markImplementor(/** @type {Function} */ (StartHandler));


exports = StartHandler; 
//# sourceMappingURL=Animation$StartHandler.js.map