/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Animation$StartHandler.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.animations.Animation.StartHandler');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.animations.Animation.StartHandler.$LambdaAdaptor');


// Re-exports the implementation.
var StartHandler = goog.require('org.dominokit.domino.ui.animations.Animation.StartHandler$impl');
exports = StartHandler;
 