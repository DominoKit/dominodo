/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DateBox.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DateBox$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ValueBox = goog.require('org.dominokit.domino.ui.forms.ValueBox$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLInputElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.KeyboardEvent.$Overlay$impl');
let MutationRecord_$Overlay = goog.forwardDeclare('elemental2.dom.MutationRecord.$Overlay$impl');
let IllegalArgumentException = goog.forwardDeclare('java.lang.IllegalArgumentException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Date = goog.forwardDeclare('java.util.Date$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $LambdaAdaptor$33 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$33$impl');
let $LambdaAdaptor$34 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$34$impl');
let $LambdaAdaptor$35 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$35$impl');
let $LambdaAdaptor$36 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$36$impl');
let Formatter = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.Formatter$impl');
let Pattern = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.Pattern$impl');
let PickerStyle = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
let DatePicker = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker$impl');
let BackgroundHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let ValidationResult = goog.forwardDeclare('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
let CloseHandler = goog.forwardDeclare('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
let ModalDialog = goog.forwardDeclare('org.dominokit.domino.ui.modals.ModalDialog$impl');
let PickerHandler = goog.forwardDeclare('org.dominokit.domino.ui.pickers.PickerHandler$impl');
let Popover = goog.forwardDeclare('org.dominokit.domino.ui.popover.Popover$impl');
let PopupPosition = goog.forwardDeclare('org.dominokit.domino.ui.popover.PopupPosition$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Validator = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let ObserverCallback = goog.forwardDeclare('org.jboss.gwt.elemento.core.ObserverCallback$impl');
let InputBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @extends {ValueBox<DateBox, HTMLInputElement, Date>}
  */
class DateBox extends ValueBox {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DatePicker} */
    this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {?string} */
    this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {Popover} */
    this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {ModalDialog} */
    this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {EventListener} */
    this.f_modalListener__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {PopupPosition} */
    this.f_popupPosition__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {PickerStyle} */
    this.f_pickerStyle__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {Date} */
    this.f_value__org_dominokit_domino_ui_datepicker_DateBox_;
    /** @public {?string} */
    this.f_invalidFormatMessage__org_dominokit_domino_ui_datepicker_DateBox_;
  }
  
  /**
   * Factory method corresponding to constructor 'DateBox()'.
   * @return {!DateBox}
   * @public
   */
  static $create__() {
    DateBox.$clinit();
    let $instance = new DateBox();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DateBox__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateBox()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DateBox__() {
    this.$ctor__org_dominokit_domino_ui_datepicker_DateBox__java_util_Date(Date.$create__());
  }
  
  /**
   * Factory method corresponding to constructor 'DateBox(String)'.
   * @param {?string} label
   * @return {!DateBox}
   * @public
   */
  static $create__java_lang_String(label) {
    DateBox.$clinit();
    let $instance = new DateBox();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String(label);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateBox(String)'.
   * @param {?string} label
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String(label) {
    this.$ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String__java_util_Date(label, Date.$create__());
  }
  
  /**
   * Factory method corresponding to constructor 'DateBox(Date)'.
   * @param {Date} date
   * @return {!DateBox}
   * @public
   */
  static $create__java_util_Date(date) {
    DateBox.$clinit();
    let $instance = new DateBox();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DateBox__java_util_Date(date);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateBox(Date)'.
   * @param {Date} date
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DateBox__java_util_Date(date) {
    this.$ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String__java_util_Date("", date);
  }
  
  /**
   * Factory method corresponding to constructor 'DateBox(String, Date)'.
   * @param {?string} label
   * @param {Date} date
   * @return {!DateBox}
   * @public
   */
  static $create__java_lang_String__java_util_Date(label, date) {
    DateBox.$clinit();
    let $instance = new DateBox();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String__java_util_Date(label, date);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateBox(String, Date)'.
   * @param {?string} label
   * @param {Date} date
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String__java_util_Date(label, date) {
    this.$ctor__org_dominokit_domino_ui_forms_ValueBox__java_lang_String__java_lang_String("text", label);
    this.$init__org_dominokit_domino_ui_datepicker_DateBox();
    this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_ = DatePicker.m_create__java_util_Date(date);
    this.m_initDateBox___$p_org_dominokit_domino_ui_datepicker_DateBox();
  }
  
  /**
   * Factory method corresponding to constructor 'DateBox(String, Date, DateTimeFormatInfo)'.
   * @param {?string} label
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {!DateBox}
   * @public
   */
  static $create__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(label, date, dateTimeFormatInfo) {
    DateBox.$clinit();
    let $instance = new DateBox();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(label, date, dateTimeFormatInfo);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DateBox(String, Date, DateTimeFormatInfo)'.
   * @param {?string} label
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DateBox__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(label, date, dateTimeFormatInfo) {
    this.$ctor__org_dominokit_domino_ui_forms_ValueBox__java_lang_String__java_lang_String("text", label);
    this.$init__org_dominokit_domino_ui_datepicker_DateBox();
    this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_ = DatePicker.m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo);
    this.m_initDateBox___$p_org_dominokit_domino_ui_datepicker_DateBox();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDateBox___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_ = this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__().m_dateFormatFull__();
    this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(DateSelectionHandler.$adapt(((/** Date */ date, /** DateTimeFormatInfo */ dateTimeFormatInfo) =>{
      this.m_setStringValue__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo_$p_org_dominokit_domino_ui_datepicker_DateBox(date, dateTimeFormatInfo);
      this.m_changeLabelFloating__();
      this.m_autoValidate__();
    })));
    this.f_modalListener__org_dominokit_domino_ui_datepicker_DateBox_ = new $LambdaAdaptor$33(((/** Event */ evt) =>{
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_open__();
    }));
    ElementUtil.m_onDetach__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback(this.m_asElement__(), ObserverCallback.$adapt(((/** MutationRecord */ mutationRecord) =>{
      this.m_removeBox___$p_org_dominokit_domino_ui_datepicker_DateBox();
    })));
    this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      this.m_close__();
    })));
    this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(PickerHandler.$adapt((() =>{
      this.m_value__java_lang_Object(null);
    })));
    this.m_setPickerStyle__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle(PickerStyle.f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle);
    this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_setBackgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$pp_org_dominokit_domino_ui_datepicker(BackgroundHandler.$adapt(((/** ColorScheme */ oldBackground, /** ColorScheme */ newBackground) =>{
      if (Objects.m_nonNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_)) {
        this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeaderContainerElement__().m_style__().m_remove__java_lang_String(oldBackground.m_color__().m_getStyle__());
        this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeaderContainerElement__().m_style__().m_add__java_lang_String(newBackground.m_color__().m_getStyle__());
      }
      if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
        this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeadingElement__().m_style__().m_remove__java_lang_String(oldBackground.m_color__().m_getStyle__());
        this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeadingElement__().m_style__().m_add__java_lang_String(newBackground.m_color__().m_getStyle__());
      }
    })));
    this.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_keypress__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$34(((/** Event */ evt$1$) =>{
      let keyboardEvent = /**@type {KeyboardEvent} */ ($Casts.$to(Js.m_cast__java_lang_Object(evt$1$), $Overlay));
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(keyboardEvent) || ElementUtil.m_isSpaceKey__elemental2_dom_KeyboardEvent(keyboardEvent)) {
        this.m_open__();
      }
    })));
    this.m_addValidator__org_dominokit_domino_ui_utils_HasValidation_Validator(Validator.$adapt((() =>{
      try {
        if (this.m_isEmpty__()) {
          return ValidationResult.m_valid__();
        }
        this.m_getFormattedValue__java_lang_String_$p_org_dominokit_domino_ui_datepicker_DateBox(/**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__().m_asElement__(), HTMLInputElement_$Overlay)).value);
        return ValidationResult.m_valid__();
      } catch (__$exc) {
        __$exc = $Exceptions.toJava(__$exc);
        if (IllegalArgumentException.$isInstance(__$exc)) {
          let e = /**@type {IllegalArgumentException} */ (__$exc);
          return ValidationResult.m_invalid__java_lang_String(this.f_invalidFormatMessage__org_dominokit_domino_ui_datepicker_DateBox_);
        } else {
          throw $Exceptions.toJs(__$exc);
        }
      }
    })));
    this.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener("change", new $LambdaAdaptor$35(((/** Event */ evt$2$) =>{
      let value = /**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__().m_asElement__(), HTMLInputElement_$Overlay)).value;
      if (j_l_String.m_isEmpty__java_lang_String(value)) {
        this.m_clear__();
      } else {
        try {
          this.m_value__java_lang_Object(this.m_getFormattedValue__java_lang_String_$p_org_dominokit_domino_ui_datepicker_DateBox(value));
        } catch (__$exc$1$) {
          __$exc$1$ = $Exceptions.toJava(__$exc$1$);
          if (IllegalArgumentException.$isInstance(__$exc$1$)) {
            let ignored = /**@type {IllegalArgumentException} */ (__$exc$1$);
            window.console.warn("Unable to parse date value " + j_l_String.m_valueOf__java_lang_Object(value));
          } else {
            throw $Exceptions.toJs(__$exc$1$);
          }
        }
      }
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_removeBox___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_close__();
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_asElement__().remove();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_close__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_close__();
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_) && this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_isOpen__()) {
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_close__();
    }
  }
  
  /**
   * @param {?string} value
   * @return {Date}
   * @public
   */
  m_getFormattedValue__java_lang_String_$p_org_dominokit_domino_ui_datepicker_DateBox(value) {
    let dateTimeFormatInfo = this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__();
    return Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_, dateTimeFormatInfo).m_parse__java_lang_String(value);
  }
  
  /**
   * @return {DateBox}
   * @public
   */
  static m_create__() {
    DateBox.$clinit();
    return DateBox.$create__();
  }
  
  /**
   * @param {?string} label
   * @return {DateBox}
   * @public
   */
  static m_create__java_lang_String(label) {
    DateBox.$clinit();
    return DateBox.$create__java_lang_String(label);
  }
  
  /**
   * @param {Date} date
   * @return {DateBox}
   * @public
   */
  static m_create__java_util_Date(date) {
    DateBox.$clinit();
    return DateBox.$create__java_util_Date(date);
  }
  
  /**
   * @param {?string} label
   * @param {Date} date
   * @return {DateBox}
   * @public
   */
  static m_create__java_lang_String__java_util_Date(label, date) {
    DateBox.$clinit();
    return DateBox.$create__java_lang_String__java_util_Date(label, date);
  }
  
  /**
   * @param {?string} label
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {DateBox}
   * @public
   */
  static m_create__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(label, date, dateTimeFormatInfo) {
    DateBox.$clinit();
    return DateBox.$create__java_lang_String__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(label, date, dateTimeFormatInfo);
  }
  
  /**
   * @param {Pattern} pattern
   * @return {DateBox}
   * @public
   */
  m_setPattern__org_dominokit_domino_ui_datepicker_DateBox_Pattern(pattern) {
    switch (pattern.ordinal()) {
      case Pattern.$ordinal$f_FULL__org_dominokit_domino_ui_datepicker_DateBox_Pattern: 
        this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_ = this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__().m_dateFormatFull__();
        return this;
      case Pattern.$ordinal$f_LONG__org_dominokit_domino_ui_datepicker_DateBox_Pattern: 
        this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_ = this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__().m_dateFormatLong__();
        return this;
      case Pattern.$ordinal$f_MEDIUM__org_dominokit_domino_ui_datepicker_DateBox_Pattern: 
        this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_ = this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__().m_dateFormatMedium__();
        return this;
      case Pattern.$ordinal$f_SHORT__org_dominokit_domino_ui_datepicker_DateBox_Pattern: 
        this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_ = this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__().m_dateFormatShort__();
        return this;
      default: 
        return this;
    }
  }
  
  /**
   * @param {?string} pattern
   * @return {DateBox}
   * @public
   */
  m_setPattern__java_lang_String(pattern) {
    this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_ = pattern;
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return Objects.m_isNull__java_lang_Object(this.f_value__org_dominokit_domino_ui_datepicker_DateBox_) && j_l_String.m_isEmpty__java_lang_String(/**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__().m_asElement__(), HTMLInputElement_$Overlay)).value);
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clearValue__() {
    this.m_value__java_lang_Object(null);
  }
  
  /**
   * @param {Date} value
   * @return {void}
   * @public
   */
  m_doSetValue__java_util_Date(value) {
    if (Objects.m_nonNull__java_lang_Object(value)) {
      this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_setDate__java_util_Date(value);
    }
    this.m_setStringValue__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo_$p_org_dominokit_domino_ui_datepicker_DateBox(value, this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__());
    this.f_value__org_dominokit_domino_ui_datepicker_DateBox_ = value;
  }
  
  /**
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {void}
   * @public
   */
  m_setStringValue__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo_$p_org_dominokit_domino_ui_datepicker_DateBox(date, dateTimeFormatInfo) {
    if (Objects.m_nonNull__java_lang_Object(date)) {
      /**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__().m_asElement__(), HTMLInputElement_$Overlay)).value = this.m_getFormatted__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo_$p_org_dominokit_domino_ui_datepicker_DateBox(date, dateTimeFormatInfo);
    } else {
      /**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__().m_asElement__(), HTMLInputElement_$Overlay)).value = "";
    }
    this.f_value__org_dominokit_domino_ui_datepicker_DateBox_ = date;
  }
  
  /**
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {?string}
   * @public
   */
  m_getFormatted__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo_$p_org_dominokit_domino_ui_datepicker_DateBox(date, dateTimeFormatInfo) {
    return Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_, dateTimeFormatInfo).m_format__java_util_Date(date);
  }
  
  /**
   * @override
   * @return {Date}
   * @public
   */
  m_getValue__() {
    return this.f_value__org_dominokit_domino_ui_datepicker_DateBox_;
  }
  
  /**
   * @override
   * @param {?string} type
   * @return {HTMLInputElement}
   * @public
   */
  m_createInputElement__java_lang_String(type) {
    return /**@type {HTMLInputElement} */ ($Casts.$to(/**@type {InputBuilder<HTMLInputElement>} */ ($Casts.$to(Elements.m_input__java_lang_String("text").m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["form-control"], j_l_String))), InputBuilder)).m_asElement__(), HTMLInputElement_$Overlay));
  }
  
  /**
   * @override
   * @param {?string} placeholder
   * @return {DateBox}
   * @public
   */
  m_setPlaceholder__java_lang_String(placeholder) {
    super.m_setPlaceholder__java_lang_String(placeholder);
    if (Objects.m_nonNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_setTitle__java_lang_String(placeholder);
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeaderContainerElement__().m_style__().m_add__java_lang_String(this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getColorScheme__().m_color__().m_getStyle__());
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeaderText__().textContent = placeholder;
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeadingElement__().m_style__().m_add__java_lang_String(this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getColorScheme__().m_color__().m_getStyle__());
    }
    return this;
  }
  
  /**
   * @param {PickerStyle} pickerStyle
   * @return {DateBox}
   * @public
   */
  m_setPickerStyle__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle(pickerStyle) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(PickerStyle.f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle, pickerStyle)) {
      this.m_showInModal___$p_org_dominokit_domino_ui_datepicker_DateBox();
    } else {
      this.m_showInPopOver___$p_org_dominokit_domino_ui_datepicker_DateBox();
    }
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_showInPopOver___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    if (!$Objects.m_equals__java_lang_Object__java_lang_Object(PickerStyle.f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle, this.f_pickerStyle__org_dominokit_domino_ui_datepicker_DateBox_)) {
      if (Objects.m_nonNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_)) {
        this.m_asElement__().removeEventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), this.f_modalListener__org_dominokit_domino_ui_datepicker_DateBox_);
        this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_close__();
        this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_asElement__().remove();
      }
      if (Objects.m_isNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
        this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_ = /**@type {Popover} */ ($Casts.$to(Popover.m_createPicker__org_jboss_gwt_elemento_core_IsElement__org_jboss_gwt_elemento_core_IsElement(this, this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_).m_position__org_dominokit_domino_ui_popover_PopupPosition(this.f_popupPosition__org_dominokit_domino_ui_datepicker_DateBox_).m_style__().m_setMaxWidth__java_lang_String("300px").m_setMaxWidth__java_lang_String__boolean("none", true).m_get__(), Popover));
        this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_getContentElement__().m_style__().m_setPadding__java_lang_String__boolean("0px", true).m_setWidth__java_lang_String__boolean("300px", true).m_setMaxWidth__java_lang_String__boolean("300px", true);
        this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_getHeadingElement__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_align_center__org_dominokit_domino_ui_style_Styles, this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getColorScheme__().m_color__().m_getStyle__()], j_l_String)));
      }
    }
    this.f_pickerStyle__org_dominokit_domino_ui_datepicker_DateBox_ = PickerStyle.f_POPOVER__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_showInModal___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    if (!$Objects.m_equals__java_lang_Object__java_lang_Object(PickerStyle.f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle, this.f_pickerStyle__org_dominokit_domino_ui_datepicker_DateBox_)) {
      if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
        this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_discard__();
      }
      if (Objects.m_isNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_)) {
        this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_ = ModalDialog.m_createPickerModal__java_lang_String__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_Node(this.m_getPlaceholder__(), this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getColorScheme__(), this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_asElement__());
        this.m_asElement__().addEventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), this.f_modalListener__org_dominokit_domino_ui_datepicker_DateBox_);
      }
    }
    this.f_pickerStyle__org_dominokit_domino_ui_datepicker_DateBox_ = PickerStyle.f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_getDatePicker__() {
    return this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_;
  }
  
  /**
   * @param {PopupPosition} popoverPosition
   * @return {DateBox}
   * @public
   */
  m_setPopoverPosition__org_dominokit_domino_ui_popover_PopupPosition(popoverPosition) {
    this.f_popupPosition__org_dominokit_domino_ui_datepicker_DateBox_ = popoverPosition;
    if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_position__org_dominokit_domino_ui_popover_PopupPosition(this.f_popupPosition__org_dominokit_domino_ui_datepicker_DateBox_);
    }
    return this;
  }
  
  /**
   * @return {DateBox}
   * @public
   */
  m_openOnFocus__() {
    let focusListener = new $LambdaAdaptor$36(((/** Event */ evt) =>{
      this.m_open__();
    }));
    this.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_focus__org_jboss_gwt_elemento_core_EventType.m_getName__(), focusListener);
    this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_onClose__org_dominokit_domino_ui_modals_IsModalDialog_CloseHandler(CloseHandler.$adapt((() =>{
      this.m_getInputElement__().m_removeEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_focus__org_jboss_gwt_elemento_core_EventType.m_getName__(), focusListener);
      /**@type {HTMLInputElement} */ ($Casts.$to(this.m_getInputElement__().m_asElement__(), HTMLInputElement_$Overlay)).focus();
      this.m_getInputElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_focus__org_jboss_gwt_elemento_core_EventType.m_getName__(), focusListener);
    })));
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_open__() {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(PickerStyle.f_MODAL__org_dominokit_domino_ui_datepicker_DateBox_PickerStyle, this.f_pickerStyle__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_open__();
    } else {
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_show__();
    }
  }
  
  /**
   * @override
   * @return {DateBox}
   * @public
   */
  m_disable__() {
    this.m_disableModal___$p_org_dominokit_domino_ui_datepicker_DateBox();
    this.m_disablePopover___$p_org_dominokit_domino_ui_datepicker_DateBox();
    return /**@type {DateBox} */ ($Casts.$to(super.m_disable__(), DateBox));
  }
  
  /**
   * @override
   * @param {boolean} readOnly
   * @return {DateBox}
   * @public
   */
  m_setReadOnly__boolean(readOnly) {
    super.m_setReadOnly__boolean(readOnly);
    if (readOnly) {
      this.m_getInputElement__().m_style__().m_add__java_lang_String("readonly");
      this.m_disableModal___$p_org_dominokit_domino_ui_datepicker_DateBox();
      this.m_disablePopover___$p_org_dominokit_domino_ui_datepicker_DateBox();
    } else if (this.m_isEnabled__()) {
      this.m_enableModal___$p_org_dominokit_domino_ui_datepicker_DateBox();
      this.m_enablePopover___$p_org_dominokit_domino_ui_datepicker_DateBox();
    }
    return this;
  }
  
  /**
   * @override
   * @return {DateBox}
   * @public
   */
  m_enable__() {
    this.m_enableModal___$p_org_dominokit_domino_ui_datepicker_DateBox();
    this.m_enablePopover___$p_org_dominokit_domino_ui_datepicker_DateBox();
    return /**@type {DateBox} */ ($Casts.$to(super.m_enable__(), DateBox));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getStringValue__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_value__org_dominokit_domino_ui_datepicker_DateBox_)) {
      return Formatter.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.f_pattern__org_dominokit_domino_ui_datepicker_DateBox_, this.f_datePicker__org_dominokit_domino_ui_datepicker_DateBox_.m_getDateTimeFormatInfo__()).m_format__java_util_Date(this.f_value__org_dominokit_domino_ui_datepicker_DateBox_);
    }
    return null;
  }
  
  /**
   * @param {?string} invalidFormatMessage
   * @return {DateBox}
   * @public
   */
  m_setInvalidFormatMessage__java_lang_String(invalidFormatMessage) {
    this.f_invalidFormatMessage__org_dominokit_domino_ui_datepicker_DateBox_ = invalidFormatMessage;
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_disablePopover___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_disable__();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_disableModal___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    if (Objects.m_nonNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_disable__();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_enablePopover___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    if (Objects.m_nonNull__java_lang_Object(this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_popover__org_dominokit_domino_ui_datepicker_DateBox_.m_enable__();
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_enableModal___$p_org_dominokit_domino_ui_datepicker_DateBox() {
    if (Objects.m_nonNull__java_lang_Object(this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_)) {
      this.f_modal__org_dominokit_domino_ui_datepicker_DateBox_.m_enable__();
    }
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_doSetValue__java_lang_Object(arg0) {
    this.m_doSetValue__java_util_Date(/**@type {Date} */ ($Casts.$to(arg0, Date)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datepicker_DateBox() {
    this.f_popupPosition__org_dominokit_domino_ui_datepicker_DateBox_ = PopupPosition.f_BOTTOM__org_dominokit_domino_ui_popover_PopupPosition;
    this.f_invalidFormatMessage__org_dominokit_domino_ui_datepicker_DateBox_ = "Invalid date format";
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_counter__org_dominokit_domino_ui_datepicker_DateBox_() {
    return (DateBox.$clinit(), DateBox.$f_counter__org_dominokit_domino_ui_datepicker_DateBox_);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_counter__org_dominokit_domino_ui_datepicker_DateBox_(value) {
    (DateBox.$clinit(), DateBox.$f_counter__org_dominokit_domino_ui_datepicker_DateBox_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateBox.$clinit = (() =>{
    });
    DateBox.$loadModules();
    ValueBox.$clinit();
    DateBox.$f_counter__org_dominokit_domino_ui_datepicker_DateBox_ = 0;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateBox;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateBox);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HTMLInputElement_$Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.KeyboardEvent.$Overlay$impl');
    IllegalArgumentException = goog.module.get('java.lang.IllegalArgumentException$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Date = goog.module.get('java.util.Date$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $LambdaAdaptor$33 = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$33$impl');
    $LambdaAdaptor$34 = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$34$impl');
    $LambdaAdaptor$35 = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$35$impl');
    $LambdaAdaptor$36 = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$36$impl');
    Formatter = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.Formatter$impl');
    Pattern = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.Pattern$impl');
    PickerStyle = goog.module.get('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle$impl');
    DatePicker = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker$impl');
    BackgroundHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    ValidationResult = goog.module.get('org.dominokit.domino.ui.forms.validations.ValidationResult$impl');
    CloseHandler = goog.module.get('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler$impl');
    ModalDialog = goog.module.get('org.dominokit.domino.ui.modals.ModalDialog$impl');
    PickerHandler = goog.module.get('org.dominokit.domino.ui.pickers.PickerHandler$impl');
    Popover = goog.module.get('org.dominokit.domino.ui.popover.Popover$impl');
    PopupPosition = goog.module.get('org.dominokit.domino.ui.popover.PopupPosition$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Validator = goog.module.get('org.dominokit.domino.ui.utils.HasValidation.Validator$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    ObserverCallback = goog.module.get('org.jboss.gwt.elemento.core.ObserverCallback$impl');
    InputBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(DateBox, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DateBox'));


/** @private {number} */
DateBox.$f_counter__org_dominokit_domino_ui_datepicker_DateBox_ = 0;




exports = DateBox; 
//# sourceMappingURL=DateBox.js.map