/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const InternalHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth.InternalHandler$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue$impl');
const IsEditor = goog.require('org.gwtproject.editor.client.IsEditor$impl');
const LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor$impl');

let JsDate_$Overlay = goog.forwardDeclare('elemental2.core.JsDate.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let j_u_Date = goog.forwardDeclare('java.util.Date$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let $LambdaAdaptor$37 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$37$impl');
let $LambdaAdaptor$38 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$38$impl');
let $LambdaAdaptor$39 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$39$impl');
let $LambdaAdaptor$40 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$40$impl');
let $LambdaAdaptor$41 = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$41$impl');
let BackgroundHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');
let DateDayClickedHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
let DateSelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
let DatePickerElement = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerElement$impl');
let DatePickerMonth = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePickerMonth$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ModalDialog = goog.forwardDeclare('org.dominokit.domino.ui.modals.ModalDialog$impl');
let PickerHandler = goog.forwardDeclare('org.dominokit.domino.ui.pickers.PickerHandler$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let WavesSupport = goog.forwardDeclare('org.dominokit.domino.ui.style.WavesSupport$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let DateTimeFormatInfo__factory = goog.forwardDeclare('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfo_factory$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Primitives = goog.forwardDeclare('vmbootstrap.Primitives$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, DatePicker>}
 * @implements {HasValue<DatePicker, j_u_Date>}
 * @implements {InternalHandler}
 * @implements {LeafValueEditor<j_u_Date>}
 * @implements {IsEditor<LeafValueEditor<j_u_Date>>}
  */
class DatePicker extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Date} */
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLAnchorElement>} */
    this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DominoElement<HTMLAnchorElement>} */
    this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Select<Integer>} */
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Select<Integer>} */
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Button} */
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Button} */
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Button} */
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {ColorScheme} */
    this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DatePickerMonth} */
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {DatePickerElement} */
    this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {List<PickerHandler>} */
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {List<PickerHandler>} */
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {BackgroundHandler} */
    this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Column} */
    this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Date} */
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {Date} */
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {List<DateSelectionHandler>} */
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
    /** @public {List<DateDayClickedHandler>} */
    this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * Factory method corresponding to constructor 'DatePicker(Date, DateTimeFormatInfo)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {!DatePicker}
   * @public
   */
  static $create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo) {
    DatePicker.$clinit();
    let $instance = new DatePicker();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePicker(Date, DateTimeFormatInfo)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_.setFullYear(this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear() - 50);
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_.setFullYear(this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear() + 50);
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_ = DatePickerMonth.m_create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_InternalHandler(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_, dateTimeFormatInfo, this);
    this.m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePicker(Date, DateTimeFormatInfo, Date, Date)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {j_u_Date} minDate
   * @param {j_u_Date} maxDate
   * @return {!DatePicker}
   * @public
   */
  static $create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate) {
    DatePicker.$clinit();
    let $instance = new DatePicker();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePicker(Date, DateTimeFormatInfo, Date, Date)'.
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {j_u_Date} minDate
   * @param {j_u_Date} maxDate
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(date.m_getTime__()));
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(minDate.m_getTime__()));
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_ = new Date($Primitives.$widenLongToDouble(maxDate.m_getTime__()));
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_ = DatePickerMonth.m_create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_InternalHandler(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_, dateTimeFormatInfo, this);
    this.m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * Factory method corresponding to constructor 'DatePicker(JsDate, DateTimeFormatInfo, JsDate, JsDate)'.
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {Date} minDate
   * @param {Date} maxDate
   * @return {!DatePicker}
   * @public
   */
  static $create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__elemental2_core_JsDate__elemental2_core_JsDate(date, dateTimeFormatInfo, minDate, maxDate) {
    DatePicker.$clinit();
    let $instance = new DatePicker();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__elemental2_core_JsDate__elemental2_core_JsDate(date, dateTimeFormatInfo, minDate, maxDate);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DatePicker(JsDate, DateTimeFormatInfo, JsDate, JsDate)'.
   * @param {Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {Date} minDate
   * @param {Date} maxDate
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__elemental2_core_JsDate__elemental2_core_JsDate(date, dateTimeFormatInfo, minDate, maxDate) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_ = date;
    this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_ = minDate;
    this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_ = maxDate;
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_ = DatePickerMonth.m_create__elemental2_core_JsDate__org_gwtproject_i18n_shared_DateTimeFormatInfo__org_dominokit_domino_ui_datepicker_DatePickerMonth_InternalHandler(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_, dateTimeFormatInfo, this);
    this.m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_build___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_add__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getBackground__());
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_add__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_darker_2__().m_getBackground__());
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.m_initSelectors___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.m_initFooter___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_init__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initFooter___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("CLEAR").m_setColor__org_dominokit_domino_ui_style_Color(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__()), Button));
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_add__java_lang_String("clear-button");
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$37(((/** Event */ evt) =>{
      this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** PickerHandler */ arg0) =>{
        arg0.m_handle__();
      })));
    })));
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("TODAY").m_setColor__org_dominokit_domino_ui_style_Color(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__()), Button));
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$38(((/** Event */ evt$1$) =>{
      this.m_setDate__java_util_Date(j_u_Date.$create__());
    })));
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {Button} */ ($Casts.$to(Button.m_create__java_lang_String("CLOSE").m_setColor__org_dominokit_domino_ui_style_Color(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__()), Button));
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_add__java_lang_String("close-button");
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$39(((/** Event */ evt$2$) =>{
      this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** PickerHandler */ arg0$1$) =>{
        arg0$1$.m_handle__();
      })));
    })));
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_linkify__());
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_linkify__());
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_linkify__());
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initSelectors___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    let year = this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear();
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {Select<Integer>} */ (Select.m_create__());
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setMarginBottom__java_lang_String__boolean("0px", true);
    for (let i = this.f_minDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear(); i <= this.f_maxDate__org_dominokit_domino_ui_datepicker_DatePicker_.getFullYear(); i++) {
      let yearOption = /**@type {SelectOption<Integer>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(Integer.m_valueOf__int(i), i + ""));
      this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(yearOption);
      if (i == year) {
        this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_select__org_dominokit_domino_ui_forms_SelectOption(yearOption);
      }
    }
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Integer> */ option) =>{
      let selectedYear = /**@type {Integer} */ ($Casts.$to(option.m_getValue__(), Integer)).m_intValue__();
      this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.setYear(selectedYear);
      this.m_setDate__elemental2_core_JsDate(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_);
    })));
    let month = this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.getMonth();
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {Select<Integer>} */ (Select.m_create__());
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setMarginBottom__java_lang_String__boolean("0px", true);
    let months = this.m_getDateTimeFormatInfo__().m_monthsShort__();
    for (let i$1$ = 0; i$1$ < months.length; i$1$++) {
      let monthOption = /**@type {SelectOption<Integer>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(Integer.m_valueOf__int(i$1$), months[i$1$]));
      this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(monthOption);
      if (i$1$ == month) {
        this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_select__org_dominokit_domino_ui_forms_SelectOption(monthOption);
      }
    }
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<Integer> */ option$1$) =>{
      let selectedMonth = /**@type {Integer} */ ($Casts.$to(option$1$.m_getValue__(), Integer)).m_intValue__();
      this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_.setMonth(selectedMonth);
      this.m_setDate__elemental2_core_JsDate(this.f_jsDate__org_dominokit_domino_ui_datepicker_DatePicker_);
    })));
    let yearColumn = /**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_.m_copy__().m_appendChild__elemental2_dom_Node(this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__()), Column));
    yearColumn.m_style__().m_setPaddingLeft__java_lang_String__boolean("0px", true);
    yearColumn.m_style__().m_setPaddingRight__java_lang_String__boolean("3px", true);
    yearColumn.m_style__().m_setMarginBottom__java_lang_String__boolean("5px", true);
    let monthColumn = /**@type {Column} */ ($Casts.$to(this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_.m_copy__().m_appendChild__elemental2_dom_Node(this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__()), Column));
    monthColumn.m_style__().m_setPaddingLeft__java_lang_String__boolean("3px", true);
    monthColumn.m_style__().m_setPaddingRight__java_lang_String__boolean("0px", true);
    monthColumn.m_style__().m_setMarginBottom__java_lang_String__boolean("5px", true);
    let backColumn = Column.m_span__int(2);
    backColumn.m_style__().m_setPadding__java_lang_String__boolean("0px", true);
    backColumn.m_style__().m_setMarginBottom__java_lang_String__boolean("5px", true);
    let forwardColumn = Column.m_span__int(2);
    forwardColumn.m_style__().m_setPadding__java_lang_String__boolean("0px", true);
    forwardColumn.m_style__().m_setTextAlign__java_lang_String__boolean("right", true);
    forwardColumn.m_style__().m_setMarginBottom__java_lang_String__boolean("5px", true);
    let row = Row.m_create__();
    row.m_style__().m_setMarginLeft__java_lang_String__boolean("0px", true);
    row.m_style__().m_setMarginRight__java_lang_String__boolean("0px", true);
    this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navigate"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_navigate_before__()), IsElement))));
    this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement<HTMLAnchorElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["navigate"], j_l_String))), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_navigate_next__()), IsElement))));
    WavesSupport.m_addFor__org_dominokit_domino_ui_utils_HasWavesElement(this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_);
    WavesSupport.m_addFor__org_dominokit_domino_ui_utils_HasWavesElement(this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_);
    this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_.m_addEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$40(((/** Event */ evt) =>{
      let jsDate = this.m_getJsDate__();
      let currentMonth = jsDate.getMonth();
      if (currentMonth == 0) {
        jsDate.setYear(jsDate.getFullYear() - 1);
        jsDate.setMonth(11);
      } else {
        jsDate.setMonth(currentMonth - 1);
      }
      this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_setValue__java_lang_Object__boolean(Integer.m_valueOf__int(jsDate.getFullYear()), true);
      this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_selectAt__int__boolean(jsDate.getMonth(), true);
      this.m_setDate__elemental2_core_JsDate(jsDate);
    })));
    this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_.m_addEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$41(((/** Event */ evt$1$) =>{
      let jsDate$1$ = this.m_getJsDate__();
      let currentMonth$1$ = jsDate$1$.getMonth();
      if (currentMonth$1$ == 11) {
        jsDate$1$.setYear(jsDate$1$.getFullYear() + 1);
        jsDate$1$.setMonth(0);
      } else {
        jsDate$1$.setMonth(currentMonth$1$ + 1);
      }
      this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_setValue__java_lang_Object__boolean(Integer.m_valueOf__int(jsDate$1$.getFullYear()), true);
      this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_selectAt__int__boolean(jsDate$1$.getMonth(), true);
      this.m_setDate__elemental2_core_JsDate(jsDate$1$);
    })));
    this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(row.m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(backColumn.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_), Column))).m_appendChild__org_dominokit_domino_ui_grid_Column(yearColumn).m_appendChild__org_dominokit_domino_ui_grid_Column(monthColumn).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(forwardColumn.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_), Column))));
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  static m_create__() {
    DatePicker.$clinit();
    let dateTimeFormatInfo = DateTimeFormatInfo__factory.m_create__();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(j_u_Date.$create__(), dateTimeFormatInfo);
  }
  
  /**
   * @param {j_u_Date} date
   * @return {DatePicker}
   * @public
   */
  static m_create__java_util_Date(date) {
    DatePicker.$clinit();
    let dateTimeFormatInfo = DateTimeFormatInfo__factory.m_create__();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo);
  }
  
  /**
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {DatePicker}
   * @public
   */
  static m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo) {
    DatePicker.$clinit();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(date, dateTimeFormatInfo);
  }
  
  /**
   * @param {j_u_Date} date
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @param {j_u_Date} minDate
   * @param {j_u_Date} maxDate
   * @return {DatePicker}
   * @public
   */
  static m_create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate) {
    DatePicker.$clinit();
    return DatePicker.$create__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo__java_util_Date__java_util_Date(date, dateTimeFormatInfo, minDate, maxDate);
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__(), $Overlay));
  }
  
  /**
   * @param {j_u_Date} value
   * @return {DatePicker}
   * @public
   */
  m_value__java_util_Date(value) {
    this.m_setValue__java_util_Date(value);
    return this;
  }
  
  /**
   * @override
   * @return {j_u_Date}
   * @public
   */
  m_getValue__() {
    return this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_getValue__();
  }
  
  /**
   * @param {j_u_Date} value
   * @return {void}
   * @public
   */
  m_setValue__java_util_Date(value) {
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_value__java_util_Date(value);
  }
  
  /**
   * @param {j_u_Date} date
   * @return {DatePicker}
   * @public
   */
  m_setDate__java_util_Date(date) {
    this.m_value__java_util_Date(date);
    return this;
  }
  
  /**
   * @return {j_u_Date}
   * @public
   */
  m_getDate__() {
    return this.m_getValue__();
  }
  
  /**
   * @param {Date} jsDate
   * @return {DatePicker}
   * @public
   */
  m_setDate__elemental2_core_JsDate(jsDate) {
    this.m_value__java_util_Date(j_u_Date.$create__long(Double.m_longValue__java_lang_Double(Double.$create__double(jsDate.getTime()))));
    return this;
  }
  
  /**
   * @return {Date}
   * @public
   */
  m_getJsDate__() {
    return new Date($Primitives.$widenLongToDouble(this.m_getValue__().m_getTime__()));
  }
  
  /**
   * @param {DateSelectionHandler} dateSelectionHandler
   * @return {DatePicker}
   * @public
   */
  m_addDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(dateSelectionHandler) {
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.add(dateSelectionHandler);
    return this;
  }
  
  /**
   * @param {DateSelectionHandler} dateSelectionHandler
   * @return {DatePicker}
   * @public
   */
  m_removeDateSelectionHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateSelectionHandler(dateSelectionHandler) {
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.remove(dateSelectionHandler);
    return this;
  }
  
  /**
   * @return {List<DateSelectionHandler>}
   * @public
   */
  m_getDateSelectionHandlers__() {
    return this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_clearDaySelectionHandlers__() {
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.clear();
    return this;
  }
  
  /**
   * @param {DateDayClickedHandler} dateDayClickedHandler
   * @return {DatePicker}
   * @public
   */
  m_addDateDayClickHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler(dateDayClickedHandler) {
    this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.add(dateDayClickedHandler);
    return this;
  }
  
  /**
   * @param {DateDayClickedHandler} dateClickedHandler
   * @return {DatePicker}
   * @public
   */
  m_removeDateDayClickedHandler__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler(dateClickedHandler) {
    this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.remove(dateClickedHandler);
    return this;
  }
  
  /**
   * @return {List<DateDayClickedHandler>}
   * @public
   */
  m_getDateDayClickedHandlers__() {
    return this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_clearDateDayClickedHandlers__() {
    this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.clear();
    return this;
  }
  
  /**
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {DatePicker}
   * @public
   */
  m_setDateTimeFormatInfo__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo) {
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_setDateTimeFormatInfo__org_gwtproject_i18n_shared_DateTimeFormatInfo(dateTimeFormatInfo);
    this.m_updatePicker___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    return this;
  }
  
  /**
   * @return {DateTimeFormatInfo}
   * @public
   */
  m_getDateTimeFormatInfo__() {
    return this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_getDateTimeFormatInfo__();
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showBorder__() {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setBorder__java_lang_String("1px solid " + j_l_String.m_valueOf__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getHex__()));
    return this;
  }
  
  /**
   * @param {ColorScheme} colorScheme
   * @return {DatePicker}
   * @public
   */
  m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(colorScheme) {
    this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_.m_onBackgroundChanged__org_dominokit_domino_ui_style_ColorScheme__org_dominokit_domino_ui_style_ColorScheme(this.m_getColorScheme__(), colorScheme);
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_remove__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getBackground__());
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_remove__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_darker_2__().m_getBackground__());
    this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_ = colorScheme;
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_add__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_color__().m_getBackground__());
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_add__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_.m_darker_2__().m_getBackground__());
    this.f_datePickerMonth__org_dominokit_domino_ui_datepicker_DatePicker_.m_setBackground__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setColor__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setColor__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setColor__org_dominokit_domino_ui_style_Color(colorScheme.m_color__());
    return this;
  }
  
  /**
   * @return {ColorScheme}
   * @public
   */
  m_getColorScheme__() {
    return this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @override
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_onDaySelected__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement) {
    this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_ = datePickerElement;
    this.m_updatePicker___$p_org_dominokit_domino_ui_datepicker_DatePicker();
    this.m_publish___$p_org_dominokit_domino_ui_datepicker_DatePicker();
  }
  
  /**
   * @override
   * @param {DatePickerElement} datePickerElement
   * @return {void}
   * @public
   */
  m_onDayClicked__org_dominokit_domino_ui_datepicker_DatePickerElement(datePickerElement) {
    for (let i = 0; i < this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.size(); i++) {
      /**@type {DateDayClickedHandler} */ ($Casts.$to(this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.getAtIndex(i), DateDayClickedHandler)).m_onDateDayClicked__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.m_getDate__(), this.m_getDateTimeFormatInfo__());
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_publish___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    for (let i = 0; i < this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.size(); i++) {
      /**@type {DateSelectionHandler} */ ($Casts.$to(this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.getAtIndex(i), DateSelectionHandler)).m_onDateSelected__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(this.m_getDate__(), this.m_getDateTimeFormatInfo__());
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updatePicker___$p_org_dominokit_domino_ui_datepicker_DatePicker() {
    let dayNameIndex = this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getWeekDay__() + this.m_getDateTimeFormatInfo__().m_firstDayOfTheWeek__();
    if (dayNameIndex > 6) {
      dayNameIndex = this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getWeekDay__() + this.m_getDateTimeFormatInfo__().m_firstDayOfTheWeek__() - 7;
    }
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_.m_setTextContent__java_lang_String(this.m_getDateTimeFormatInfo__().m_weekdaysFull__()[dayNameIndex]);
    this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_.m_setTextContent__java_lang_String(this.m_getDateTimeFormatInfo__().m_monthsFull__()[this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getMonth__()]);
    this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_.m_setTextContent__java_lang_String(this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getDay__() + "");
    this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_.m_setTextContent__java_lang_String(this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getYear__() + "");
    this.f_monthSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_selectAt__int__boolean(this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getMonth__(), true);
    this.f_yearSelect__org_dominokit_domino_ui_datepicker_DatePicker_.m_setValue__java_lang_Object__boolean(Integer.m_valueOf__int(this.f_selectedPickerElement__org_dominokit_domino_ui_datepicker_DatePicker_.m_getYear__()), true);
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showHeaderPanel__() {
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("block");
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideHeaderPanel__() {
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("none");
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showTodayButton__() {
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("block");
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideTodayButton__() {
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("none");
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showClearButton__() {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("block");
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideClearButton__() {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("none");
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_showCloseButton__() {
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("block");
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_hideCloseButton__() {
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setDisplay__java_lang_String("none");
    return this;
  }
  
  /**
   * @param {PickerHandler} closeHandler
   * @return {DatePicker}
   * @public
   */
  m_addCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(closeHandler) {
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.add(closeHandler);
    return this;
  }
  
  /**
   * @param {PickerHandler} closeHandler
   * @return {DatePicker}
   * @public
   */
  m_removeCloseHandler__org_dominokit_domino_ui_pickers_PickerHandler(closeHandler) {
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.remove(closeHandler);
    return this;
  }
  
  /**
   * @return {List<PickerHandler>}
   * @public
   */
  m_getCloseHandlers__() {
    return this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @param {PickerHandler} clearHandler
   * @return {DatePicker}
   * @public
   */
  m_addClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(clearHandler) {
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.add(clearHandler);
    return this;
  }
  
  /**
   * @param {PickerHandler} clearHandler
   * @return {DatePicker}
   * @public
   */
  m_removeClearHandler__org_dominokit_domino_ui_pickers_PickerHandler(clearHandler) {
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_.remove(clearHandler);
    return this;
  }
  
  /**
   * @return {List<PickerHandler>}
   * @public
   */
  m_getClearHandlers__() {
    return this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_;
  }
  
  /**
   * @param {?string} text
   * @return {DatePicker}
   * @public
   */
  m_todayButtonText__java_lang_String(text) {
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setContent__java_lang_String(text);
    this.f_todayButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().title = text;
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {DatePicker}
   * @public
   */
  m_clearButtonText__java_lang_String(text) {
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setContent__java_lang_String(text);
    this.f_clearButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().title = text;
    return this;
  }
  
  /**
   * @param {?string} text
   * @return {DatePicker}
   * @public
   */
  m_closeButtonText__java_lang_String(text) {
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_setContent__java_lang_String(text);
    this.f_closeButton__org_dominokit_domino_ui_datepicker_DatePicker_.m_asElement__().title = text;
    return this;
  }
  
  /**
   * @return {DatePicker}
   * @public
   */
  m_fixedWidth__() {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setWidth__java_lang_String__boolean("300px", true);
    return this;
  }
  
  /**
   * @param {?string} width
   * @return {DatePicker}
   * @public
   */
  m_fixedWidth__java_lang_String(width) {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_.m_style__().m_setWidth__java_lang_String__boolean(width, true);
    return this;
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getHeaderPanel__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getSelectorsPanel__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getFooterPanel__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getDayNamePanel__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getMonthNamePanel__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getDateNumberPanel__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getYearNumberPanel__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLAnchorElement>}
   * @public
   */
  m_getNavigateBefore__() {
    return /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_navigateBefore__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @return {DominoElement<HTMLAnchorElement>}
   * @public
   */
  m_getNavigateNext__() {
    return /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_navigateNext__org_dominokit_domino_ui_datepicker_DatePicker_));
  }
  
  /**
   * @param {BackgroundHandler} backgroundHandler
   * @return {DatePicker}
   * @public
   */
  m_setBackgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$pp_org_dominokit_domino_ui_datepicker(backgroundHandler) {
    if (Objects.m_nonNull__java_lang_Object(backgroundHandler)) {
      this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_ = backgroundHandler;
    }
    return this;
  }
  
  /**
   * @param {?string} title
   * @return {ModalDialog}
   * @public
   */
  m_createModal__java_lang_String(title) {
    return ModalDialog.m_createPickerModal__java_lang_String__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_Node(title, this.m_getColorScheme__(), this.m_asElement__());
  }
  
  /**
   * @override
   * @return {LeafValueEditor<j_u_Date>}
   * @public
   */
  m_asEditor__() {
    return this;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {DatePicker}
   * @public
   */
  m_value__java_lang_Object(arg0) {
    return this.m_value__java_util_Date(/**@type {j_u_Date} */ ($Casts.$to(arg0, j_u_Date)));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_util_Date(/**@type {j_u_Date} */ ($Casts.$to(arg0, j_u_Date)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datepicker_DatePicker() {
    this.f_element__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["calendar"], j_l_String)))));
    this.f_headerPanel__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["date-panel"], j_l_String)))));
    this.f_selectorsPanel__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["selector-container"], j_l_String)))));
    this.f_footerPanel__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["cal-footer"], j_l_String)))));
    this.f_dayName__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["day-name"], j_l_String)))));
    this.f_monthName__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["month-name"], j_l_String)))));
    this.f_dateNumber__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["day-number"], j_l_String)))));
    this.f_yearNumber__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["year-number"], j_l_String)))));
    this.f_colorScheme__org_dominokit_domino_ui_datepicker_DatePicker_ = ColorScheme.f_LIGHT_BLUE__org_dominokit_domino_ui_style_ColorScheme;
    this.f_closeHandlers__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {!ArrayList<PickerHandler>} */ (ArrayList.$create__());
    this.f_clearHandlers__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {!ArrayList<PickerHandler>} */ (ArrayList.$create__());
    this.f_backgroundHandler__org_dominokit_domino_ui_datepicker_DatePicker_ = BackgroundHandler.$adapt(((/** ColorScheme */ oldBackground, /** ColorScheme */ newBackground) =>{
    }));
    this.f_column__org_dominokit_domino_ui_datepicker_DatePicker_ = Column.m_span__int(4);
    this.f_dateSelectionHandlers__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {!ArrayList<DateSelectionHandler>} */ (ArrayList.$create__());
    this.f_dateDayClickedHandlers__org_dominokit_domino_ui_datepicker_DatePicker_ = /**@type {!ArrayList<DateDayClickedHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DatePicker.$clinit = (() =>{
    });
    DatePicker.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DatePicker;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DatePicker);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    Double = goog.module.get('java.lang.Double$impl');
    Integer = goog.module.get('java.lang.Integer$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    j_u_Date = goog.module.get('java.util.Date$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    $LambdaAdaptor$37 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$37$impl');
    $LambdaAdaptor$38 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$38$impl');
    $LambdaAdaptor$39 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$39$impl');
    $LambdaAdaptor$40 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$40$impl');
    $LambdaAdaptor$41 = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$41$impl');
    BackgroundHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');
    DateDayClickedHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');
    DateSelectionHandler = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler$impl');
    DatePickerMonth = goog.module.get('org.dominokit.domino.ui.datepicker.DatePickerMonth$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ModalDialog = goog.module.get('org.dominokit.domino.ui.modals.ModalDialog$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    WavesSupport = goog.module.get('org.dominokit.domino.ui.style.WavesSupport$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    DateTimeFormatInfo__factory = goog.module.get('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfo_factory$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Primitives = goog.module.get('vmbootstrap.Primitives$impl');
  }
  
  
};

$Util.$setClassMetadata(DatePicker, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker'));


HasValue.$markImplementor(DatePicker);
InternalHandler.$markImplementor(DatePicker);
LeafValueEditor.$markImplementor(DatePicker);
IsEditor.$markImplementor(DatePicker);


exports = DatePicker; 
//# sourceMappingURL=DatePicker.js.map