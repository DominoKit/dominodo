/**
 * @fileoverview transpiled from org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement$impl');

let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLLIElement, BreadcrumbItem>}
 * @implements {HasClickableElement}
  */
class BreadcrumbItem extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLLIElement>} */
    this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {DominoElement<HTMLAnchorElement>} */
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {Text} */
    this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {BaseIcon} */
    this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
    /** @public {boolean} */
    this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbItem(String)'.
   * @param {?string} text
   * @return {!BreadcrumbItem}
   * @public
   */
  static $create__java_lang_String(text) {
    BreadcrumbItem.$clinit();
    let $instance = new BreadcrumbItem();
    $instance.$ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__java_lang_String(text);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbItem(String)'.
   * @param {?string} text
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__java_lang_String(text) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem();
    this.m_init__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon_$p_org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem(text, null);
  }
  
  /**
   * Factory method corresponding to constructor 'BreadcrumbItem(String, BaseIcon)'.
   * @param {?string} text
   * @param {BaseIcon<?>} icon
   * @return {!BreadcrumbItem}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(text, icon) {
    BreadcrumbItem.$clinit();
    let $instance = new BreadcrumbItem();
    $instance.$ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(text, icon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'BreadcrumbItem(String, BaseIcon)'.
   * @param {?string} text
   * @param {BaseIcon<?>} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(text, icon) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem();
    this.m_init__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon_$p_org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem(text, icon);
  }
  
  /**
   * @param {?string} text
   * @param {BaseIcon<?>} icon
   * @return {void}
   * @public
   */
  m_init__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon_$p_org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem(text, icon) {
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = TextNode.m_of__java_lang_String(text);
    if (Objects.m_nonNull__java_lang_Object(icon)) {
      this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = icon;
      this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(icon);
    }
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__elemental2_dom_Node(this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
    this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {?string} text
   * @return {BreadcrumbItem}
   * @public
   */
  static m_create__java_lang_String(text) {
    BreadcrumbItem.$clinit();
    return BreadcrumbItem.$create__java_lang_String(text);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @param {?string} text
   * @return {BreadcrumbItem}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_BaseIcon__java_lang_String(icon, text) {
    BreadcrumbItem.$clinit();
    return BreadcrumbItem.$create__java_lang_String__org_dominokit_domino_ui_icons_BaseIcon(text, icon);
  }
  
  /**
   * @return {BreadcrumbItem}
   * @public
   */
  m_activate__() {
    if (!this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_) {
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_style__().m_add__java_lang_String("active");
      this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.remove();
      this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_remove__();
      if (Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_)) {
        this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_asElement__().remove();
        this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      }
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__elemental2_dom_Node(this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = true;
    }
    return this;
  }
  
  /**
   * @return {BreadcrumbItem}
   * @public
   */
  m_deActivate__() {
    if (this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_) {
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_style__().m_remove__java_lang_String("active");
      this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.remove();
      if (Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_)) {
        this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_remove__();
        this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      }
      this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__elemental2_dom_Node(this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_);
      this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = false;
    }
    return this;
  }
  
  /**
   * @param {boolean} active
   * @return {BreadcrumbItem}
   * @public
   */
  m_setActive__boolean(active) {
    if (active) {
      return this.m_activate__();
    } else {
      return this.m_deActivate__();
    }
  }
  
  /**
   * @override
   * @return {HTMLLIElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLLIElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {HTMLAnchorElement}
   * @public
   */
  m_getClickableElement__() {
    return /**@type {HTMLAnchorElement} */ ($Casts.$to(this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_.m_asElement__(), HTMLAnchorElement_$Overlay));
  }
  
  /**
   * @return {Text}
   * @public
   */
  m_getTextElement__() {
    return this.f_textElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
  }
  
  /**
   * @return {BaseIcon}
   * @public
   */
  m_getIcon__() {
    return this.f_icon__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isActive__() {
    return this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem() {
    this.f_element__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = /**@type {DominoElement<HTMLLIElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(/**@type {HTMLLIElement} */ ($Casts.$to(Elements.m_li__().m_asElement__(), $Overlay))));
    this.f_anchorElement__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_a__()));
    this.f_active__org_dominokit_domino_ui_breadcrumbs_BreadcrumbItem_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    BreadcrumbItem.$clinit = (() =>{
    });
    BreadcrumbItem.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BreadcrumbItem;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BreadcrumbItem);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(BreadcrumbItem, $Util.$makeClassName('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem'));


HasClickableElement.$markImplementor(BreadcrumbItem);


exports = BreadcrumbItem; 
//# sourceMappingURL=BreadcrumbItem.js.map