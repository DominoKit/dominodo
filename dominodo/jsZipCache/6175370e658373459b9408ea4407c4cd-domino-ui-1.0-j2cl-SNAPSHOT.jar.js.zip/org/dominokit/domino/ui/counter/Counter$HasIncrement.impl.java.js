/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasIncrement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasIncrement$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let HasCountHandler = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.HasCountHandler$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.HasIncrement.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasIncrement {
  /**
   * @abstract
   * @param {number} increment
   * @return {HasCountHandler}
   * @public
   */
  m_incrementBy__int(increment) {
  }
  
  /**
   * @param {?function(number):HasCountHandler} fn
   * @return {HasIncrement}
   * @public
   */
  static $adapt(fn) {
    HasIncrement.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasIncrement.$clinit = (() =>{
    });
    HasIncrement.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_HasIncrement = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_counter_Counter_HasIncrement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_counter_Counter_HasIncrement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.counter.Counter.HasIncrement.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasIncrement, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$HasIncrement'));


HasIncrement.$markImplementor(/** @type {Function} */ (HasIncrement));


exports = HasIncrement; 
//# sourceMappingURL=Counter$HasIncrement.js.map