package org.dominokit.domino.ui.cards;

import elemental2.dom.DomGlobal;
import org.jboss.gwt.elemento.template.TemplateUtil;

import javax.annotation.Generated;

/*
 * WARNING! This class is generated. Do not modify.
 */
@Generated("org.jboss.gwt.elemento.processor.TemplatedProcessor")
public final class Templated_Card extends Card {

    private final elemental2.dom.HTMLDivElement templated_card_root_element;

 public Templated_Card() {

        this.templated_card_root_element = (elemental2.dom.HTMLDivElement)DomGlobal.document.createElement("div");
        this.templated_card_root_element.setAttribute("class", "card");
        this.templated_card_root_element.innerHTML = "<div data-element=\"header\" class=\"header\">  <h2 data-element=\"headerTitle\"> <small data-element=\"headerDescription\"></small> </h2>  <ul data-element=\"headerBar\" class=\"header-dropdown m-r--5\">  </ul> </div> <div data-element=\"body\" class=\"body\"> </div>";

        if (this.header == null) {
            this.header = TemplateUtil.<elemental2.dom.HTMLDivElement>resolveElementAs(templated_card_root_element, "header");
        } else {
            TemplateUtil.replaceElement(templated_card_root_element, "header", header);
        }
        if (this.headerTitle == null) {
            this.headerTitle = TemplateUtil.resolveElement(templated_card_root_element, "headerTitle");
        } else {
            TemplateUtil.replaceElement(templated_card_root_element, "headerTitle", headerTitle);
        }
        if (this.headerDescription == null) {
            this.headerDescription = TemplateUtil.resolveElement(templated_card_root_element, "headerDescription");
        } else {
            TemplateUtil.replaceElement(templated_card_root_element, "headerDescription", headerDescription);
        }
        if (this.headerBar == null) {
            this.headerBar = TemplateUtil.<elemental2.dom.HTMLUListElement>resolveElementAs(templated_card_root_element, "headerBar");
        } else {
            TemplateUtil.replaceElement(templated_card_root_element, "headerBar", headerBar);
        }
        if (this.body == null) {
            this.body = TemplateUtil.<elemental2.dom.HTMLDivElement>resolveElementAs(templated_card_root_element, "body");
        } else {
            TemplateUtil.replaceElement(templated_card_root_element, "body", body);
        }
        init();
    }

    @Override
    public elemental2.dom.HTMLDivElement asElement() {
        return templated_card_root_element;
    }
}
