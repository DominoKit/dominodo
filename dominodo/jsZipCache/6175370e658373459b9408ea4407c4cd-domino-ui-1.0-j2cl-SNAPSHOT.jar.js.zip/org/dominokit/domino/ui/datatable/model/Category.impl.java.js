/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.Category.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.model.Category$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Category>}
  */
class Category extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Category}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Category();
    $instance.$ctor__org_dominokit_domino_ui_datatable_model_Category__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_model_Category__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Category}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Category.$clinit();
    if ($Equality.$same(Category.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_, null)) {
      Category.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_ = $Enums.createMapFromValues(Category.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Category.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_);
  }
  
  /**
   * @return {!Array<!Category>}
   * @public
   */
  static m_values__() {
    Category.$clinit();
    return /**@type {!Array<Category>} */ ($Arrays.$init([Category.$f_SEARCH__org_dominokit_domino_ui_datatable_model_Category, Category.$f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category], Category));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Category} */ ($Casts.$to(arg0, Category)));
  }
  
  /**
   * @return {!Category}
   * @public
   */
  static get f_SEARCH__org_dominokit_domino_ui_datatable_model_Category() {
    return (Category.$clinit(), Category.$f_SEARCH__org_dominokit_domino_ui_datatable_model_Category);
  }
  
  /**
   * @param {!Category} value
   * @return {void}
   * @public
   */
  static set f_SEARCH__org_dominokit_domino_ui_datatable_model_Category(value) {
    (Category.$clinit(), Category.$f_SEARCH__org_dominokit_domino_ui_datatable_model_Category = value);
  }
  
  /**
   * @return {!Category}
   * @public
   */
  static get f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category() {
    return (Category.$clinit(), Category.$f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category);
  }
  
  /**
   * @param {!Category} value
   * @return {void}
   * @public
   */
  static set f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category(value) {
    (Category.$clinit(), Category.$f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category = value);
  }
  
  /**
   * @return {Map<?string, !Category>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_() {
    return (Category.$clinit(), Category.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_);
  }
  
  /**
   * @param {Map<?string, !Category>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_(value) {
    (Category.$clinit(), Category.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Category.$clinit = (() =>{
    });
    Category.$loadModules();
    Enum.$clinit();
    Category.$f_SEARCH__org_dominokit_domino_ui_datatable_model_Category = Category.$create__java_lang_String__int($Util.$makeEnumName("SEARCH"), Category.$ordinal$f_SEARCH__org_dominokit_domino_ui_datatable_model_Category);
    Category.$f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category = Category.$create__java_lang_String__int($Util.$makeEnumName("HEADER_FILTER"), Category.$ordinal$f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category);
    Category.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Category;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Category);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(Category, $Util.$makeClassName('org.dominokit.domino.ui.datatable.model.Category'));


/** @private {!Category} */
Category.$f_SEARCH__org_dominokit_domino_ui_datatable_model_Category;


/** @private {!Category} */
Category.$f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category;


/** @private {Map<?string, !Category>} */
Category.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_model_Category_;


/** @public {number} @const */
Category.$ordinal$f_SEARCH__org_dominokit_domino_ui_datatable_model_Category = 0;


/** @public {number} @const */
Category.$ordinal$f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category = 1;




exports = Category; 
//# sourceMappingURL=Category.js.map