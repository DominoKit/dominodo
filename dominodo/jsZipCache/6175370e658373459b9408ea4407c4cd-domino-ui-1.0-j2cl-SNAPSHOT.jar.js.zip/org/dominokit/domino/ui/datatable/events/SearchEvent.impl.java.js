/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.SearchEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @implements {TableEvent}
  */
class SearchEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<Filter>} */
    this.f_filters__org_dominokit_domino_ui_datatable_events_SearchEvent_;
  }
  
  /**
   * @param {List<Filter>} filters
   * @return {!SearchEvent}
   * @public
   */
  static $create__java_util_List(filters) {
    SearchEvent.$clinit();
    let $instance = new SearchEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_events_SearchEvent__java_util_List(filters);
    return $instance;
  }
  
  /**
   * @param {List<Filter>} filters
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_SearchEvent__java_util_List(filters) {
    this.$ctor__java_lang_Object__();
    this.f_filters__org_dominokit_domino_ui_datatable_events_SearchEvent_ = filters;
  }
  
  /**
   * @return {List<Filter>}
   * @public
   */
  m_getFilters__() {
    return this.f_filters__org_dominokit_domino_ui_datatable_events_SearchEvent_;
  }
  
  /**
   * @param {Category} category
   * @return {List<Filter>}
   * @public
   */
  m_getByCategory__org_dominokit_domino_ui_datatable_model_Category(category) {
    return /**@type {List<Filter>} */ ($Casts.$to(this.f_filters__org_dominokit_domino_ui_datatable_events_SearchEvent_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Filter */ f) =>{
      return $Objects.m_equals__java_lang_Object__java_lang_Object(f.m_getCategory__(), category);
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Filter, ?, List<Filter>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getType__() {
    return SearchEvent.f_SEARCH_EVENT__org_dominokit_domino_ui_datatable_events_SearchEvent;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SearchEvent.$clinit = (() =>{
    });
    SearchEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SearchEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SearchEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    List = goog.module.get('java.util.List$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(SearchEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.SearchEvent'));


/** @public {?string} @const */
SearchEvent.f_SEARCH_EVENT__org_dominokit_domino_ui_datatable_events_SearchEvent = "table-search";


TableEvent.$markImplementor(SearchEvent);


exports = SearchEvent; 
//# sourceMappingURL=SearchEvent.js.map