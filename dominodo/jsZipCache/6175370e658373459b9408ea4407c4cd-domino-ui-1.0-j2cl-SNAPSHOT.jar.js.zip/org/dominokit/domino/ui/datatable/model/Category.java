package org.dominokit.domino.ui.datatable.model;

public enum Category {
    SEARCH, HEADER_FILTER
}
