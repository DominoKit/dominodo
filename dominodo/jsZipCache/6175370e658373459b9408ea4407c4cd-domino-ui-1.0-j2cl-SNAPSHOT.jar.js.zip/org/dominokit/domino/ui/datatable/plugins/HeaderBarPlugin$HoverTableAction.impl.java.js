/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$HoverTableAction.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.HoverTableAction$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor$24 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.HoverTableAction.$LambdaAdaptor$24$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_HoverTableAction_T
 * @implements {HeaderActionElement<C_HoverTableAction_T>}
  */
class HoverTableAction extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @template C_HoverTableAction_T
   * @return {!HoverTableAction<C_HoverTableAction_T>}
   * @public
   */
  static $create__() {
    HoverTableAction.$clinit();
    let $instance = new HoverTableAction();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_HoverTableAction__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_HoverTableAction__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {DataTable<C_HoverTableAction_T>} dataTable
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    let hoverIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_blur_off__().m_clickable__(), Icon)).m_setToggleIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_blur_on__()), Icon)).m_toggleOnClick__boolean(true), Icon)).m_setTooltip__java_lang_String("No Hover"), Icon)).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Icon */ icon) =>{
      icon.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$24(((/** Event */ evt) =>{
        if (dataTable.m_isHoverable__()) {
          dataTable.m_noHover__();
          icon.m_setTooltip__java_lang_String("Hover");
        } else {
          dataTable.m_hovered__();
          icon.m_setTooltip__java_lang_String("No Hover");
        }
      })));
    }))), Icon));
    return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(hoverIcon), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    HeaderActionElement.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HoverTableAction.$clinit = (() =>{
    });
    HoverTableAction.$loadModules();
    j_l_Object.$clinit();
    HeaderActionElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HoverTableAction;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HoverTableAction);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor$24 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.HoverTableAction.$LambdaAdaptor$24$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(HoverTableAction, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$HoverTableAction'));


HeaderActionElement.$markImplementor(HoverTableAction);


exports = HoverTableAction; 
//# sourceMappingURL=HeaderBarPlugin$HoverTableAction.js.map