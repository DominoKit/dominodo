/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$MarkerColor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor.$LambdaAdaptor$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');


/**
 * @interface
 * @template C_MarkerColor_T
 */
class MarkerColor {
  /**
   * @abstract
   * @param {CellInfo<C_MarkerColor_T>} tableCellInfo
   * @return {ColorScheme}
   * @public
   */
  m_getColorScheme__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(tableCellInfo) {
  }
  
  /**
   * @template C_MarkerColor_T
   * @param {?function(CellInfo<C_MarkerColor_T>):ColorScheme} fn
   * @return {MarkerColor<C_MarkerColor_T>}
   * @public
   */
  static $adapt(fn) {
    MarkerColor.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    MarkerColor.$clinit = (() =>{
    });
    MarkerColor.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(MarkerColor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$MarkerColor'));


MarkerColor.$markImplementor(/** @type {Function} */ (MarkerColor));


exports = MarkerColor; 
//# sourceMappingURL=RowMarkerPlugin$MarkerColor.js.map