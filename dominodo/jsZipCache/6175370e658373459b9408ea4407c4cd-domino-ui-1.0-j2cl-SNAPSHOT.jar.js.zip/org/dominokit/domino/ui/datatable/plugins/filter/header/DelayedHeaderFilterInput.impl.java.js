/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter$impl');

let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let SearchContext = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.SearchContext$impl');
let ValueBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.ValueBox$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let DelayedTextInput = goog.forwardDeclare('org.dominokit.domino.ui.utils.DelayedTextInput$impl');
let DelayedAction = goog.forwardDeclare('org.dominokit.domino.ui.utils.DelayedTextInput.DelayedAction$impl');


/**
 * @abstract
 * @template C_B, C_T
 * @implements {HeaderFilter<C_T>}
  */
class DelayedHeaderFilterInput extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {C_B} */
    this.f_input__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_;
    /** @public {DelayedTextInput} */
    this.f_delayedTextInput__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput__() {
    this.$ctor__java_lang_Object__();
    this.f_input__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_ = this.m_createValueBox__();
    /**@type {ValueBox} */ (this.f_input__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style */ style) =>{
      style.m_setMarginBottom__java_lang_String("0px");
    })));
    /**@type {ValueBox} */ (this.f_input__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_).m_setPlaceholder__java_lang_String("Search");
    /**@type {ValueBox} */ (this.f_input__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_).m_getLeftAddonContainer__().m_collapse__();
    /**@type {ValueBox} */ (this.f_input__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_).m_getRightAddonContainer__().m_collapse__();
    this.f_delayedTextInput__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_ = DelayedTextInput.m_create__elemental2_dom_HTMLInputElement__int(this.m_getInputElement__(), 200);
  }
  
  /**
   * @override
   * @param {SearchContext<C_T>} searchContext
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_ColumnConfig(searchContext, columnConfig) {
    this.f_delayedTextInput__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_.m_setDelayedAction__org_dominokit_domino_ui_utils_DelayedTextInput_DelayedAction(DelayedAction.$adapt((() =>{
      if (Objects.m_nonNull__java_lang_Object(searchContext) && Objects.m_nonNull__java_lang_Object(columnConfig)) {
        if (this.m_isEmpty__()) {
          searchContext.m_remove__java_lang_String__org_dominokit_domino_ui_datatable_model_Category(columnConfig.m_getName__(), Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category);
          searchContext.m_fireSearchEvent__();
        } else {
          searchContext.m_add__org_dominokit_domino_ui_datatable_model_Filter(Filter.m_create__java_lang_String__java_lang_String__org_dominokit_domino_ui_datatable_model_Category__org_dominokit_domino_ui_datatable_model_FilterTypes(columnConfig.m_getName__(), this.m_getValue__(), Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category, this.m_getType__()));
          searchContext.m_fireSearchEvent__();
        }
      }
    })));
  }
  
  /**
   * @abstract
   * @return {HTMLInputElement}
   * @public
   */
  m_getInputElement__() {
  }
  
  /**
   * @abstract
   * @return {C_B}
   * @public
   */
  m_createValueBox__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getValue__() {
  }
  
  /**
   * @abstract
   * @return {FilterTypes}
   * @public
   */
  m_getType__() {
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return /**@type {ValueBox} */ (this.f_input__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput_).m_asElement__();
  }
  
  /**
   * @abstract
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DelayedHeaderFilterInput.$clinit = (() =>{
    });
    DelayedHeaderFilterInput.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DelayedHeaderFilterInput;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DelayedHeaderFilterInput);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Objects = goog.module.get('java.util.Objects$impl');
    Category = goog.module.get('org.dominokit.domino.ui.datatable.model.Category$impl');
    Filter = goog.module.get('org.dominokit.domino.ui.datatable.model.Filter$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    DelayedTextInput = goog.module.get('org.dominokit.domino.ui.utils.DelayedTextInput$impl');
    DelayedAction = goog.module.get('org.dominokit.domino.ui.utils.DelayedTextInput.DelayedAction$impl');
  }
  
  
};

$Util.$setClassMetadata(DelayedHeaderFilterInput, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput'));


HeaderFilter.$markImplementor(DelayedHeaderFilterInput);


exports = DelayedHeaderFilterInput; 
//# sourceMappingURL=DelayedHeaderFilterInput.js.map