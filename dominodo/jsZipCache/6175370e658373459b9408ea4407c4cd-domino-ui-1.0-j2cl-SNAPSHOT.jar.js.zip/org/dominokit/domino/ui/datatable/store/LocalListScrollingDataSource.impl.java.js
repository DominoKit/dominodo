/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataStore = goog.require('org.dominokit.domino.ui.datatable.store.DataStore$impl');

let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let BodyScrollEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.BodyScrollEvent$impl');
let SearchEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
let SortEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SortEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let ScrollPosition = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.ScrollPosition$impl');
let DataChangedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');
let RecordsSorter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.RecordsSorter$impl');
let SearchFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.SearchFilter$impl');
let StoreDataChangeListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @template C_T
 * @implements {DataStore<C_T>}
  */
class LocalListScrollingDataSource extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<C_T>} */
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
    /** @public {List<C_T>} */
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
    /** @public {number} */
    this.f_pageSize__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = 0;
    /** @public {number} */
    this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = 0;
    /** @public {List<StoreDataChangeListener<C_T>>} */
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
    /** @public {SearchFilter<C_T>} */
    this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
    /** @public {RecordsSorter<C_T>} */
    this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
    /** @public {SortEvent<C_T>} */
    this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
  }
  
  /**
   * Factory method corresponding to constructor 'LocalListScrollingDataSource(int)'.
   * @template C_T
   * @param {number} pageSize
   * @return {!LocalListScrollingDataSource<C_T>}
   * @public
   */
  static $create__int(pageSize) {
    LocalListScrollingDataSource.$clinit();
    let $instance = new LocalListScrollingDataSource();
    $instance.$ctor__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource__int(pageSize);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LocalListScrollingDataSource(int)'.
   * @param {number} pageSize
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource__int(pageSize) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource();
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
    this.f_pageSize__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = pageSize;
  }
  
  /**
   * Factory method corresponding to constructor 'LocalListScrollingDataSource(List, int)'.
   * @template C_T
   * @param {List<C_T>} data
   * @param {number} pageSize
   * @return {!LocalListScrollingDataSource<C_T>}
   * @public
   */
  static $create__java_util_List__int(data, pageSize) {
    LocalListScrollingDataSource.$clinit();
    let $instance = new LocalListScrollingDataSource();
    $instance.$ctor__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource__java_util_List__int(data, pageSize);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'LocalListScrollingDataSource(List, int)'.
   * @param {List<C_T>} data
   * @param {number} pageSize
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource__java_util_List__int(data, pageSize) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource();
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = data;
    this.f_pageSize__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = pageSize;
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.addAll(data);
  }
  
  /**
   * @return {SearchFilter<C_T>}
   * @public
   */
  m_getSearchFilter__() {
    return this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
  }
  
  /**
   * @param {SearchFilter<C_T>} searchFilter
   * @return {LocalListScrollingDataSource<C_T>}
   * @public
   */
  m_setSearchFilter__org_dominokit_domino_ui_datatable_store_SearchFilter(searchFilter) {
    this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = searchFilter;
    return this;
  }
  
  /**
   * @return {RecordsSorter<C_T>}
   * @public
   */
  m_getRecordsSorter__() {
    return this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
  }
  
  /**
   * @param {RecordsSorter<C_T>} recordsSorter
   * @return {LocalListScrollingDataSource<C_T>}
   * @public
   */
  m_setRecordsSorter__org_dominokit_domino_ui_datatable_store_RecordsSorter(recordsSorter) {
    this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = recordsSorter;
    return this;
  }
  
  /**
   * @param {List<C_T>} data
   * @return {void}
   * @public
   */
  m_setData__java_util_List(data) {
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.clear();
    this.f_original__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.addAll(data);
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.clear();
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.addAll(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_);
  }
  
  /**
   * @override
   * @param {StoreDataChangeListener<C_T>} dataChangeListener
   * @return {void}
   * @public
   */
  m_onDataChanged__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener(dataChangeListener) {
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.add(dataChangeListener);
  }
  
  /**
   * @override
   * @param {StoreDataChangeListener<C_T>} dataChangeListener
   * @return {void}
   * @public
   */
  m_removeDataChangeListener__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener(dataChangeListener) {
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.remove(dataChangeListener);
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_load__() {
    this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = 0;
    this.m_fireUpdate__boolean_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(false);
  }
  
  /**
   * @param {boolean} append
   * @return {void}
   * @public
   */
  m_fireUpdate__boolean_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(append) {
    let fromIndex = this.f_pageSize__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ * this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
    let toIndex = Math.min(fromIndex + this.f_pageSize__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_, this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.size());
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** StoreDataChangeListener<*> */ dataChangeListener) =>{
      dataChangeListener.m_onDataChanged__org_dominokit_domino_ui_datatable_store_DataChangedEvent(/**@type {!DataChangedEvent<*>} */ (DataChangedEvent.$create__java_util_List__boolean__int(/**@type {!ArrayList<*>} */ (ArrayList.$create__java_util_Collection(this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.subList(fromIndex, toIndex))), append, this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.size())));
    })));
  }
  
  /**
   * @override
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
    switch ($InternalPreconditions.m_checkNotNull__java_lang_Object(event.m_getType__())) {
      case BodyScrollEvent.f_BODY_SCROLL__org_dominokit_domino_ui_datatable_events_BodyScrollEvent: 
        this.m_onBodyScroll__org_dominokit_domino_ui_datatable_events_BodyScrollEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(/**@type {BodyScrollEvent} */ ($Casts.$to(event, BodyScrollEvent)));
        break;
      case SortEvent.f_SORT_EVENT__org_dominokit_domino_ui_datatable_events_SortEvent: 
        this.m_onSort__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(/**@type {SortEvent<C_T>} */ ($Casts.$to(event, SortEvent)));
        break;
      case SearchEvent.f_SEARCH_EVENT__org_dominokit_domino_ui_datatable_events_SearchEvent: 
        this.m_onSearch__org_dominokit_domino_ui_datatable_events_SearchEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(/**@type {SearchEvent} */ ($Casts.$to(event, SearchEvent)));
        break;
    }
  }
  
  /**
   * @param {BodyScrollEvent} bodyScrollEvent
   * @return {void}
   * @public
   */
  m_onBodyScroll__org_dominokit_domino_ui_datatable_events_BodyScrollEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(bodyScrollEvent) {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(ScrollPosition.f_BOTTOM__org_dominokit_domino_ui_datatable_plugins_BodyScrollPlugin_ScrollPosition, bodyScrollEvent.m_getScrollPosition__())) {
      let nextIndex = this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ + 1;
      let fromIndex = nextIndex * this.f_pageSize__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_;
      if (fromIndex < this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.size()) {
        this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_++;
        this.m_fireUpdate__boolean_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(true);
      }
    }
  }
  
  /**
   * @param {SearchEvent} event
   * @return {void}
   * @public
   */
  m_onSearch__org_dominokit_domino_ui_datatable_events_SearchEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(event) {
    if (Objects.m_nonNull__java_lang_Object(this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_)) {
      this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = /**@type {List<C_T>} */ ($Casts.$to(this.f_original__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** * */ t) =>{
        return this.f_searchFilter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.m_filterRecord__org_dominokit_domino_ui_datatable_events_SearchEvent__java_lang_Object(event, t);
      }))).m_collect__java_util_stream_Collector(/**@type {Collector<C_T, ?, List<C_T>>} */ (Collectors.m_toList__())), List));
      if (Objects.m_nonNull__java_lang_Object(this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_)) {
        this.m_onSort__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_);
      } else {
        this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = 0;
        this.m_fireUpdate__boolean_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(false);
      }
    }
  }
  
  /**
   * @param {SortEvent<C_T>} event
   * @return {void}
   * @public
   */
  m_onSort__org_dominokit_domino_ui_datatable_events_SortEvent_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(event) {
    if (Objects.m_nonNull__java_lang_Object(this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_)) {
      this.f_lastSort__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = event;
      this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.m_sort__java_util_Comparator(this.f_recordsSorter__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_.m_onSortChange__java_lang_String__org_dominokit_domino_ui_datatable_plugins_SortDirection(event.m_getColumnConfig__().m_getName__(), event.m_getSortDirection__()));
      this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = 0;
      this.m_fireUpdate__boolean_$p_org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource(false);
    }
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource() {
    this.f_filtered__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
    this.f_pageIndex__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = 0;
    this.f_listeners__org_dominokit_domino_ui_datatable_store_LocalListScrollingDataSource_ = /**@type {!ArrayList<StoreDataChangeListener<C_T>>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    LocalListScrollingDataSource.$clinit = (() =>{
    });
    LocalListScrollingDataSource.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof LocalListScrollingDataSource;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, LocalListScrollingDataSource);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    List = goog.module.get('java.util.List$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    BodyScrollEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.BodyScrollEvent$impl');
    SearchEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
    SortEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SortEvent$impl');
    ScrollPosition = goog.module.get('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.ScrollPosition$impl');
    DataChangedEvent = goog.module.get('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(LocalListScrollingDataSource, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource'));


DataStore.$markImplementor(LocalListScrollingDataSource);


exports = LocalListScrollingDataSource; 
//# sourceMappingURL=LocalListScrollingDataSource.js.map