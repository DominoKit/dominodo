/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let TablePageChangeEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent$impl');
let PageChangedCallBack = goog.forwardDeclare('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack$impl');
let ScrollingPagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.ScrollingPagination$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class ScrollingPaginationPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {ScrollingPagination} */
    this.f_pagination__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin_;
  }
  
  /**
   * Factory method corresponding to constructor 'ScrollingPaginationPlugin()'.
   * @template C_T
   * @return {!ScrollingPaginationPlugin<C_T>}
   * @public
   */
  static $create__() {
    ScrollingPaginationPlugin.$clinit();
    let $instance = new ScrollingPaginationPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ScrollingPaginationPlugin()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__() {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__int(10);
  }
  
  /**
   * Factory method corresponding to constructor 'ScrollingPaginationPlugin(int)'.
   * @template C_T
   * @param {number} pageSize
   * @return {!ScrollingPaginationPlugin<C_T>}
   * @public
   */
  static $create__int(pageSize) {
    ScrollingPaginationPlugin.$clinit();
    let $instance = new ScrollingPaginationPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__int(pageSize);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ScrollingPaginationPlugin(int)'.
   * @param {number} pageSize
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__int(pageSize) {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__int__int(pageSize, 10);
  }
  
  /**
   * Factory method corresponding to constructor 'ScrollingPaginationPlugin(int, int)'.
   * @template C_T
   * @param {number} pageSize
   * @param {number} windowSize
   * @return {!ScrollingPaginationPlugin<C_T>}
   * @public
   */
  static $create__int__int(pageSize, windowSize) {
    ScrollingPaginationPlugin.$clinit();
    let $instance = new ScrollingPaginationPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__int__int(pageSize, windowSize);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'ScrollingPaginationPlugin(int, int)'.
   * @param {number} pageSize
   * @param {number} windowSize
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin__int__int(pageSize, windowSize) {
    this.$ctor__java_lang_Object__();
    this.f_pagination__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin_ = ScrollingPagination.m_create__int__int__int(0, pageSize, windowSize);
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    dataTable.m_asElement__().appendChild(this.f_pagination__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin_.m_asElement__());
    this.f_pagination__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin_.m_onPageChanged__org_dominokit_domino_ui_pagination_HasPagination_PageChangedCallBack(PageChangedCallBack.$adapt(((/** number */ pageNumber) =>{
      dataTable.m_fireTableEvent__org_dominokit_domino_ui_datatable_events_TableEvent(TablePageChangeEvent.$create__int__org_dominokit_domino_ui_pagination_HasPagination(pageNumber, this.f_pagination__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin_));
    })));
  }
  
  /**
   * @return {ScrollingPagination}
   * @public
   */
  m_getPagination__() {
    return this.f_pagination__org_dominokit_domino_ui_datatable_plugins_ScrollingPaginationPlugin_;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    DataTablePlugin.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ScrollingPaginationPlugin.$clinit = (() =>{
    });
    ScrollingPaginationPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ScrollingPaginationPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ScrollingPaginationPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    TablePageChangeEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent$impl');
    PageChangedCallBack = goog.module.get('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack$impl');
    ScrollingPagination = goog.module.get('org.dominokit.domino.ui.pagination.ScrollingPagination$impl');
  }
  
  
};

$Util.$setClassMetadata(ScrollingPaginationPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin'));


DataTablePlugin.$markImplementor(ScrollingPaginationPlugin);


exports = ScrollingPaginationPlugin; 
//# sourceMappingURL=ScrollingPaginationPlugin.js.map