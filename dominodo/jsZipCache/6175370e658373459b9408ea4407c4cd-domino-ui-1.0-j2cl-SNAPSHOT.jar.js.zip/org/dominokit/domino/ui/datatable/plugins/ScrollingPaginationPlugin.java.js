/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _TablePageChangeEvent = goog.require('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent');
const _PageChangedCallBack = goog.require('org.dominokit.domino.ui.pagination.HasPagination.PageChangedCallBack');
const _ScrollingPagination = goog.require('org.dominokit.domino.ui.pagination.ScrollingPagination');


// Re-exports the implementation.
var ScrollingPaginationPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.ScrollingPaginationPlugin$impl');
exports = ScrollingPaginationPlugin;
 