/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$MarkerColor$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const MarkerColor = goog.require('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor$impl');

let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');


/**
 * @template C_MarkerColor_T
 * @implements {MarkerColor<C_MarkerColor_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(CellInfo<C_MarkerColor_T>):ColorScheme} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(CellInfo<C_MarkerColor_T>):ColorScheme} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor_$LambdaAdaptor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor_$JsFunction(fn);
  }
  
  /**
   * @param {?function(CellInfo<C_MarkerColor_T>):ColorScheme} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor_$LambdaAdaptor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {CellInfo<C_MarkerColor_T>} arg0
   * @return {ColorScheme}
   * @public
   */
  m_getColorScheme__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(arg0) {
    let /** ?function(CellInfo<C_MarkerColor_T>):ColorScheme */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$MarkerColor$$LambdaAdaptor'));


MarkerColor.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=RowMarkerPlugin$MarkerColor$$LambdaAdaptor.js.map