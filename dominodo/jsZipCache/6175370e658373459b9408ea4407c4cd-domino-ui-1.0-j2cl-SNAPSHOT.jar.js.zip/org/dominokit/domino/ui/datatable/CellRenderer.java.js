/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.CellRenderer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.CellRenderer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.$LambdaAdaptor');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');


// Re-exports the implementation.
var CellRenderer = goog.require('org.dominokit.domino.ui.datatable.CellRenderer$impl');
exports = CellRenderer;
 