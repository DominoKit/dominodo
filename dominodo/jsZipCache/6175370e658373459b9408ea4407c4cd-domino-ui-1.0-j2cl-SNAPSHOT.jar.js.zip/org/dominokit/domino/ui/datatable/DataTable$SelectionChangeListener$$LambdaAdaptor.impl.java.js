/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable$SelectionChangeListener$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SelectionChangeListener = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @template C_SelectionChangeListener_T
 * @implements {SelectionChangeListener<C_SelectionChangeListener_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(List<TableRow<C_SelectionChangeListener_T>>, List<C_SelectionChangeListener_T>):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(List<TableRow<C_SelectionChangeListener_T>>, List<C_SelectionChangeListener_T>):void} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(List<TableRow<C_SelectionChangeListener_T>>, List<C_SelectionChangeListener_T>):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {List<TableRow<C_SelectionChangeListener_T>>} arg0
   * @param {List<C_SelectionChangeListener_T>} arg1
   * @return {void}
   * @public
   */
  m_onSelectionChanged__java_util_List__java_util_List(arg0, arg1) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener_$LambdaAdaptor;
      $function(arg0, arg1);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.DataTable$SelectionChangeListener$$LambdaAdaptor'));


SelectionChangeListener.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DataTable$SelectionChangeListener$$LambdaAdaptor.js.map