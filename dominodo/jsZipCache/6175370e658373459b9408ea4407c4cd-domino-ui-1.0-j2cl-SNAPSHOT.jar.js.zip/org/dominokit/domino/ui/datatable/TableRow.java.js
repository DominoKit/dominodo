/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.TableRow.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.TableRow');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Selectable = goog.require('org.dominokit.domino.ui.utils.Selectable');
const _$Overlay = goog.require('elemental2.dom.HTMLTableRowElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _HashMap = goog.require('java.util.HashMap');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _Consumer = goog.require('java.util.function.Consumer');
const _RowCell = goog.require('org.dominokit.domino.ui.datatable.RowCell');
const _RowListener = goog.require('org.dominokit.domino.ui.datatable.TableRow.RowListener');
const _RowMetaObject = goog.require('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.Selectable.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow$impl');
exports = TableRow;
 