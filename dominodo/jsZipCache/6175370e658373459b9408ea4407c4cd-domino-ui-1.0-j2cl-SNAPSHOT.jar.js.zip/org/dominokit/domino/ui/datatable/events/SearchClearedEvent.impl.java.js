/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.SearchClearedEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.SearchClearedEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent$impl');


/**
 * @implements {TableEvent}
  */
class SearchClearedEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!SearchClearedEvent}
   * @public
   */
  static $create__() {
    SearchClearedEvent.$clinit();
    let $instance = new SearchClearedEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_events_SearchClearedEvent__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_SearchClearedEvent__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getType__() {
    return SearchClearedEvent.f_SEARCH_EVENT_CLEARED__org_dominokit_domino_ui_datatable_events_SearchClearedEvent;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SearchClearedEvent.$clinit = (() =>{
    });
    SearchClearedEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SearchClearedEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SearchClearedEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(SearchClearedEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.SearchClearedEvent'));


/** @public {?string} @const */
SearchClearedEvent.f_SEARCH_EVENT_CLEARED__org_dominokit_domino_ui_datatable_events_SearchClearedEvent = "table-search-cleared";


TableEvent.$markImplementor(SearchClearedEvent);


exports = SearchClearedEvent; 
//# sourceMappingURL=SearchClearedEvent.js.map