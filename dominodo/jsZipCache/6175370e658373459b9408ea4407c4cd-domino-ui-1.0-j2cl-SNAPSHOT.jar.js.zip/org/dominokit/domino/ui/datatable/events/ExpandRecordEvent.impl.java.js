/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.ExpandRecordEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.ExpandRecordEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent$impl');

let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @template C_T
 * @implements {TableEvent}
  */
class ExpandRecordEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {TableRow<C_T>} */
    this.f_tableRow__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent_;
  }
  
  /**
   * @template C_T
   * @param {TableRow<C_T>} tableRow
   * @return {!ExpandRecordEvent<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_TableRow(tableRow) {
    ExpandRecordEvent.$clinit();
    let $instance = new ExpandRecordEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent__org_dominokit_domino_ui_datatable_TableRow(tableRow);
    return $instance;
  }
  
  /**
   * @param {TableRow<C_T>} tableRow
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent__org_dominokit_domino_ui_datatable_TableRow(tableRow) {
    this.$ctor__java_lang_Object__();
    this.f_tableRow__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent_ = tableRow;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getType__() {
    return ExpandRecordEvent.f_EXPAND_RECORD__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent;
  }
  
  /**
   * @return {TableRow<C_T>}
   * @public
   */
  m_getTableRow__() {
    return this.f_tableRow__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ExpandRecordEvent.$clinit = (() =>{
    });
    ExpandRecordEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ExpandRecordEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ExpandRecordEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(ExpandRecordEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.ExpandRecordEvent'));


/** @public {?string} @const */
ExpandRecordEvent.f_EXPAND_RECORD__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent = "expand-record";


TableEvent.$markImplementor(ExpandRecordEvent);


exports = ExpandRecordEvent; 
//# sourceMappingURL=ExpandRecordEvent.js.map