/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Enum = goog.require('java.lang.Enum');
const _j_l_String = goog.require('java.lang.String');
const _Arrays = goog.require('java.util.Arrays');
const _Consumer = goog.require('java.util.function.Consumer');
const _Stream = goog.require('java.util.stream.Stream');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _FilterTypes = goog.require('org.dominokit.domino.ui.datatable.model.FilterTypes');
const _SearchContext = goog.require('org.dominokit.domino.ui.datatable.model.SearchContext');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var EnumHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter$impl');
exports = EnumHeaderFilter;
 