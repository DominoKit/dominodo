/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$SearchTableAction$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Timer = goog.require('org.gwtproject.timer.client.Timer');
const _SearchTableAction = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction');


// Re-exports the implementation.
var $1 = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$1$impl');
exports = $1;
 