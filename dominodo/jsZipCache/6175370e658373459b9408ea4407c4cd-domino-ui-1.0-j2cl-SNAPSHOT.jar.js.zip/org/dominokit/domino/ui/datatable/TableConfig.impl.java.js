/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.TableConfig.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.TableConfig$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasMultiSelectionSupport = goog.require('org.dominokit.domino.ui.utils.HasMultiSelectionSupport$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLTableCellElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let HTMLTableSectionElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableSectionElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let RowCell = goog.forwardDeclare('org.dominokit.domino.ui.datatable.RowCell$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let DataTablePlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');
let Tooltip = goog.forwardDeclare('org.dominokit.domino.ui.popover.Tooltip$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {HasMultiSelectionSupport}
  */
class TableConfig extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<ColumnConfig<C_T>>} */
    this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_;
    /** @public {List<DataTablePlugin<C_T>>} */
    this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_;
    /** @public {DataTable<C_T>} */
    this.f_dataTable__org_dominokit_domino_ui_datatable_TableConfig_;
    /** @public {boolean} */
    this.f_fixed__org_dominokit_domino_ui_datatable_TableConfig_ = false;
    /** @public {?string} */
    this.f_fixedDefaultColumnWidth__org_dominokit_domino_ui_datatable_TableConfig_;
    /** @public {?string} */
    this.f_fixedBodyHeight__org_dominokit_domino_ui_datatable_TableConfig_;
    /** @public {boolean} */
    this.f_lazyLoad__org_dominokit_domino_ui_datatable_TableConfig_ = false;
    /** @public {boolean} */
    this.f_multiSelect__org_dominokit_domino_ui_datatable_TableConfig_ = false;
  }
  
  /**
   * @template C_T
   * @return {!TableConfig<C_T>}
   * @public
   */
  static $create__() {
    TableConfig.$clinit();
    let $instance = new TableConfig();
    $instance.$ctor__org_dominokit_domino_ui_datatable_TableConfig__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_TableConfig__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_TableConfig();
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @param {DominoElement<HTMLTableSectionElement>} thead
   * @return {void}
   * @public
   */
  m_drawHeaders__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_utils_DominoElement(dataTable, thead) {
    this.f_dataTable__org_dominokit_domino_ui_datatable_TableConfig_ = dataTable;
    let tr = Elements.m_tr__();
    thead.m_appendChild__elemental2_dom_Node(tr.m_asElement__());
    this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ColumnConfig<*> */ columnConfig) =>{
      let element = columnConfig.m_getHeaderElement__().m_asElement__java_lang_String(columnConfig.m_getTitle__());
      columnConfig.f_contextMenu__org_dominokit_domino_ui_datatable_ColumnConfig = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("width: 15px; display: none;"), HtmlContentBuilder)).m_asElement__(), $Overlay));
      let add = /**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("display: flex;"), HtmlContentBuilder)).m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_style__java_lang_String("width:100%"), HtmlContentBuilder)).m_add__elemental2_dom_Node(element), IsElement))), HtmlContentBuilder)).m_add__elemental2_dom_Node(columnConfig.f_contextMenu__org_dominokit_domino_ui_datatable_ColumnConfig), HtmlContentBuilder));
      let th = /**@type {HtmlContentBuilder<HTMLTableCellElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableCellElement>} */ ($Casts.$to(Elements.m_th__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["table-cm-header"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(add.m_asElement__()), HtmlContentBuilder));
      tr.m_add__org_jboss_gwt_elemento_core_IsElement(th);
      columnConfig.m_setHeadElement__elemental2_dom_HTMLTableCellElement(/**@type {HTMLTableCellElement} */ ($Casts.$to(th.m_asElement__(), HTMLTableCellElement_$Overlay)));
      if (dataTable.m_getTableConfig__().m_isFixed__() || columnConfig.m_isFixed__()) {
        this.m_fixElementWidth__org_dominokit_domino_ui_datatable_ColumnConfig__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_datatable_TableConfig(columnConfig, th.m_asElement__());
      }
      Tooltip.m_create__elemental2_dom_HTMLElement__elemental2_dom_Node(th.m_asElement__(), columnConfig.m_getTooltipNode__());
      columnConfig.m_applyHeaderStyle___$pp_org_dominokit_domino_ui_datatable();
      this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DataTablePlugin<*> */ plugin) =>{
        plugin.m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(dataTable, columnConfig);
      })));
    })));
    dataTable.m_tableElement__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(thead);
  }
  
  /**
   * @param {ColumnConfig<C_T>} column
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  m_fixElementWidth__org_dominokit_domino_ui_datatable_ColumnConfig__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_datatable_TableConfig(column, element) {
    let fixedWidth = this.m_bestFitWidth__org_dominokit_domino_ui_datatable_ColumnConfig_$pp_org_dominokit_domino_ui_datatable(column);
    /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element)).m_setWidth__java_lang_String(fixedWidth).m_setMinWidth__java_lang_String(fixedWidth).m_setMaxWidth__java_lang_String(fixedWidth).m_setProperty__java_lang_String__java_lang_String("overflow", "hidden").m_setProperty__java_lang_String__java_lang_String("text-overflow", "ellipsis").m_setProperty__java_lang_String__java_lang_String("white-space", "nowrap");
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @param {TableRow<C_T>} tableRow
   * @return {void}
   * @public
   */
  m_drawRecord__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(dataTable, tableRow) {
    this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ColumnConfig<*> */ columnConfig) =>{
      let /** HTMLTableCellElement */ cellElement;
      if (columnConfig.m_isHeader__()) {
        cellElement = /**@type {HTMLTableCellElement} */ ($Casts.$to(Elements.m_th__().m_asElement__(), HTMLTableCellElement_$Overlay));
      } else {
        cellElement = /**@type {HTMLTableCellElement} */ ($Casts.$to(Elements.m_td__().m_asElement__(), HTMLTableCellElement_$Overlay));
      }
      if (dataTable.m_getTableConfig__().m_isFixed__() || columnConfig.m_isFixed__()) {
        this.m_fixElementWidth__org_dominokit_domino_ui_datatable_ColumnConfig__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_datatable_TableConfig(columnConfig, cellElement);
      }
      let rowCell = /**@type {!RowCell<*>} */ (RowCell.$create__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {!CellInfo<*>} */ (CellInfo.$create__org_dominokit_domino_ui_datatable_TableRow__elemental2_dom_HTMLTableCellElement(tableRow, cellElement)), columnConfig));
      rowCell.m_updateCell__();
      tableRow.m_addCell__org_dominokit_domino_ui_datatable_RowCell(rowCell);
      tableRow.m_asElement__().appendChild(cellElement);
      columnConfig.m_applyCellStyle__elemental2_dom_HTMLTableCellElement_$pp_org_dominokit_domino_ui_datatable(cellElement);
    })));
    dataTable.m_bodyElement__().m_appendChild__elemental2_dom_Node(tableRow.m_asElement__());
    this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DataTablePlugin<*> */ plugin) =>{
      plugin.m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(dataTable, tableRow);
    })));
  }
  
  /**
   * @param {ColumnConfig<C_T>} column
   * @return {TableConfig<C_T>}
   * @public
   */
  m_addColumn__org_dominokit_domino_ui_datatable_ColumnConfig(column) {
    this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_.add(column);
    return this;
  }
  
  /**
   * @param {ColumnConfig<C_T>} column
   * @return {TableConfig<C_T>}
   * @public
   */
  m_insertColumnFirst__org_dominokit_domino_ui_datatable_ColumnConfig(column) {
    this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_.addAtIndex(0, column);
    return this;
  }
  
  /**
   * @param {ColumnConfig<C_T>} column
   * @return {TableConfig<C_T>}
   * @public
   */
  m_insertColumnLast__org_dominokit_domino_ui_datatable_ColumnConfig(column) {
    this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_.addAtIndex(this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_.size() - 1, column);
    return this;
  }
  
  /**
   * @param {DataTablePlugin<C_T>} plugin
   * @return {TableConfig<C_T>}
   * @public
   */
  m_addPlugin__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin(plugin) {
    this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_.add(plugin);
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isFixed__() {
    return this.f_fixed__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @param {boolean} fixed
   * @return {TableConfig<C_T>}
   * @public
   */
  m_setFixed__boolean(fixed) {
    this.f_fixed__org_dominokit_domino_ui_datatable_TableConfig_ = fixed;
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isLazyLoad__() {
    return this.f_lazyLoad__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @param {boolean} lazyLoad
   * @return {TableConfig<C_T>}
   * @public
   */
  m_setLazyLoad__boolean(lazyLoad) {
    this.f_lazyLoad__org_dominokit_domino_ui_datatable_TableConfig_ = lazyLoad;
    return this;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getFixedBodyHeight__() {
    return this.f_fixedBodyHeight__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @param {?string} fixedBodyHeight
   * @return {TableConfig<C_T>}
   * @public
   */
  m_setFixedBodyHeight__java_lang_String(fixedBodyHeight) {
    this.f_fixedBodyHeight__org_dominokit_domino_ui_datatable_TableConfig_ = fixedBodyHeight;
    return this;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getFixedDefaultColumnWidth__() {
    return this.f_fixedDefaultColumnWidth__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @param {?string} fixedDefaultColumnWidth
   * @return {TableConfig<C_T>}
   * @public
   */
  m_setFixedDefaultColumnWidth__java_lang_String(fixedDefaultColumnWidth) {
    this.f_fixedDefaultColumnWidth__org_dominokit_domino_ui_datatable_TableConfig_ = fixedDefaultColumnWidth;
    return this;
  }
  
  /**
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {?string}
   * @public
   */
  m_bestFitWidth__org_dominokit_domino_ui_datatable_ColumnConfig_$pp_org_dominokit_domino_ui_datatable(columnConfig) {
    if (Objects.m_nonNull__java_lang_Object(columnConfig.m_getWidth__()) && !j_l_String.m_isEmpty__java_lang_String(columnConfig.m_getWidth__())) {
      return columnConfig.m_getWidth__();
    } else if (Objects.m_nonNull__java_lang_Object(columnConfig.m_getMinWidth__()) && !j_l_String.m_isEmpty__java_lang_String(columnConfig.m_getMinWidth__())) {
      return columnConfig.m_getMinWidth__();
    } else if (Objects.m_nonNull__java_lang_Object(columnConfig.m_getMaxWidth__()) && !j_l_String.m_isEmpty__java_lang_String(columnConfig.m_getMaxWidth__())) {
      return columnConfig.m_getMaxWidth__();
    } else {
      return this.f_fixedDefaultColumnWidth__org_dominokit_domino_ui_datatable_TableConfig_;
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isMultiSelect__() {
    return this.f_multiSelect__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @override
   * @param {boolean} multiSelect
   * @return {void}
   * @public
   */
  m_setMultiSelect__boolean(multiSelect) {
    this.f_multiSelect__org_dominokit_domino_ui_datatable_TableConfig_ = multiSelect;
  }
  
  /**
   * @return {List<DataTablePlugin<C_T>>}
   * @public
   */
  m_getPlugins__() {
    return this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeHeaders__org_dominokit_domino_ui_datatable_DataTable_$pp_org_dominokit_domino_ui_datatable(dataTable) {
    this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DataTablePlugin<*> */ plugin) =>{
      plugin.m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable);
    })));
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onAfterHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DataTablePlugin<*> */ plugin) =>{
      plugin.m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable);
    })));
  }
  
  /**
   * @return {List<ColumnConfig<C_T>>}
   * @public
   */
  m_getColumns__() {
    return this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_getDataTable__() {
    return this.f_dataTable__org_dominokit_domino_ui_datatable_TableConfig_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_TableConfig() {
    this.f_columns__org_dominokit_domino_ui_datatable_TableConfig_ = /**@type {!LinkedList<ColumnConfig<C_T>>} */ (LinkedList.$create__());
    this.f_plugins__org_dominokit_domino_ui_datatable_TableConfig_ = /**@type {!LinkedList<DataTablePlugin<C_T>>} */ (LinkedList.$create__());
    this.f_fixed__org_dominokit_domino_ui_datatable_TableConfig_ = false;
    this.f_fixedDefaultColumnWidth__org_dominokit_domino_ui_datatable_TableConfig_ = "100px";
    this.f_fixedBodyHeight__org_dominokit_domino_ui_datatable_TableConfig_ = "400px";
    this.f_lazyLoad__org_dominokit_domino_ui_datatable_TableConfig_ = true;
    this.f_multiSelect__org_dominokit_domino_ui_datatable_TableConfig_ = true;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TableConfig.$clinit = (() =>{
    });
    TableConfig.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TableConfig;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TableConfig);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLTableCellElement_$Overlay = goog.module.get('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    CellInfo = goog.module.get('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
    RowCell = goog.module.get('org.dominokit.domino.ui.datatable.RowCell$impl');
    Tooltip = goog.module.get('org.dominokit.domino.ui.popover.Tooltip$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TableConfig, $Util.$makeClassName('org.dominokit.domino.ui.datatable.TableConfig'));


HasMultiSelectionSupport.$markImplementor(TableConfig);


exports = TableConfig; 
//# sourceMappingURL=TableConfig.js.map