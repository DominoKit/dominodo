/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.SortDirection.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<SortDirection>}
  */
class SortDirection extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!SortDirection}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new SortDirection();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_SortDirection__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_SortDirection__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!SortDirection}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    SortDirection.$clinit();
    if ($Equality.$same(SortDirection.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_, null)) {
      SortDirection.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_ = $Enums.createMapFromValues(SortDirection.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, SortDirection.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_);
  }
  
  /**
   * @return {!Array<!SortDirection>}
   * @public
   */
  static m_values__() {
    SortDirection.$clinit();
    return /**@type {!Array<SortDirection>} */ ($Arrays.$init([SortDirection.$f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection, SortDirection.$f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection], SortDirection));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {SortDirection} */ ($Casts.$to(arg0, SortDirection)));
  }
  
  /**
   * @return {!SortDirection}
   * @public
   */
  static get f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection() {
    return (SortDirection.$clinit(), SortDirection.$f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection);
  }
  
  /**
   * @param {!SortDirection} value
   * @return {void}
   * @public
   */
  static set f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection(value) {
    (SortDirection.$clinit(), SortDirection.$f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection = value);
  }
  
  /**
   * @return {!SortDirection}
   * @public
   */
  static get f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection() {
    return (SortDirection.$clinit(), SortDirection.$f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection);
  }
  
  /**
   * @param {!SortDirection} value
   * @return {void}
   * @public
   */
  static set f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection(value) {
    (SortDirection.$clinit(), SortDirection.$f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection = value);
  }
  
  /**
   * @return {Map<?string, !SortDirection>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_() {
    return (SortDirection.$clinit(), SortDirection.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_);
  }
  
  /**
   * @param {Map<?string, !SortDirection>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_(value) {
    (SortDirection.$clinit(), SortDirection.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SortDirection.$clinit = (() =>{
    });
    SortDirection.$loadModules();
    Enum.$clinit();
    SortDirection.$f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection = SortDirection.$create__java_lang_String__int($Util.$makeEnumName("ASC"), SortDirection.$ordinal$f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection);
    SortDirection.$f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection = SortDirection.$create__java_lang_String__int($Util.$makeEnumName("DESC"), SortDirection.$ordinal$f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection);
    SortDirection.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SortDirection;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SortDirection);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(SortDirection, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.SortDirection'));


/** @private {!SortDirection} */
SortDirection.$f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection;


/** @private {!SortDirection} */
SortDirection.$f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection;


/** @private {Map<?string, !SortDirection>} */
SortDirection.$f_namesToValuesMap__org_dominokit_domino_ui_datatable_plugins_SortDirection_;


/** @public {number} @const */
SortDirection.$ordinal$f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection = 0;


/** @public {number} @const */
SortDirection.$ordinal$f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection = 1;




exports = SortDirection; 
//# sourceMappingURL=SortDirection.js.map