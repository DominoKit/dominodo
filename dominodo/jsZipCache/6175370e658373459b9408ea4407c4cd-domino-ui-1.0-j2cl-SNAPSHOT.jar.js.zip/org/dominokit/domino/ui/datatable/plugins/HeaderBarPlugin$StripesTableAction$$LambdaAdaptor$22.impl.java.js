/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$StripesTableAction$$LambdaAdaptor$22.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.StripesTableAction.$LambdaAdaptor$22$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');


/**
 * @implements {EventListener}
  */
class $LambdaAdaptor$22 extends j_l_Object {
  /**
   * @param {?function(Event):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor$22.$clinit();
    super();
    /** @public {?function(Event):void} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_StripesTableAction_$LambdaAdaptor$22;
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_StripesTableAction_$LambdaAdaptor$22__elemental2_dom_EventListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(Event):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_StripesTableAction_$LambdaAdaptor$22__elemental2_dom_EventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_StripesTableAction_$LambdaAdaptor$22 = fn;
  }
  
  /**
   * @param {Event} arg0
   * @return {void}
   * @public
   */
  handleEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_StripesTableAction_$LambdaAdaptor$22;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor$22.$clinit = (() =>{
    });
    $LambdaAdaptor$22.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor$22;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor$22);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor$22, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$StripesTableAction$$LambdaAdaptor$22'));




exports = $LambdaAdaptor$22; 
//# sourceMappingURL=HeaderBarPlugin$StripesTableAction$$LambdaAdaptor$22.js.map