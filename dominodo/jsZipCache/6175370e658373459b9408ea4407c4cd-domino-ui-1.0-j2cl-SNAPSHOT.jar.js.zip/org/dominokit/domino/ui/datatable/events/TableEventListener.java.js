/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.TableEventListener.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.events.TableEventListener');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener.$LambdaAdaptor');


// Re-exports the implementation.
var TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener$impl');
exports = TableEventListener;
 