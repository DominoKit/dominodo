/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.SearchContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.model.SearchContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collection = goog.require('java.util.Collection');
const _List = goog.require('java.util.List');
const _Predicate = goog.require('java.util.function.Predicate');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _SearchClearedEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchClearedEvent');
const _SearchEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchEvent');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var SearchContext = goog.require('org.dominokit.domino.ui.datatable.model.SearchContext$impl');
exports = SearchContext;
 