/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.BodyScrollEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.BodyScrollEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent$impl');

let ScrollPosition = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.ScrollPosition$impl');


/**
 * @implements {TableEvent}
  */
class BodyScrollEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {ScrollPosition} */
    this.f_scrollPosition__org_dominokit_domino_ui_datatable_events_BodyScrollEvent_;
  }
  
  /**
   * @param {ScrollPosition} scrollPosition
   * @return {!BodyScrollEvent}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_plugins_BodyScrollPlugin_ScrollPosition(scrollPosition) {
    BodyScrollEvent.$clinit();
    let $instance = new BodyScrollEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_events_BodyScrollEvent__org_dominokit_domino_ui_datatable_plugins_BodyScrollPlugin_ScrollPosition(scrollPosition);
    return $instance;
  }
  
  /**
   * @param {ScrollPosition} scrollPosition
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_BodyScrollEvent__org_dominokit_domino_ui_datatable_plugins_BodyScrollPlugin_ScrollPosition(scrollPosition) {
    this.$ctor__java_lang_Object__();
    this.f_scrollPosition__org_dominokit_domino_ui_datatable_events_BodyScrollEvent_ = scrollPosition;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getType__() {
    return BodyScrollEvent.f_BODY_SCROLL__org_dominokit_domino_ui_datatable_events_BodyScrollEvent;
  }
  
  /**
   * @return {ScrollPosition}
   * @public
   */
  m_getScrollPosition__() {
    return this.f_scrollPosition__org_dominokit_domino_ui_datatable_events_BodyScrollEvent_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    BodyScrollEvent.$clinit = (() =>{
    });
    BodyScrollEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BodyScrollEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BodyScrollEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(BodyScrollEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.BodyScrollEvent'));


/** @public {?string} @const */
BodyScrollEvent.f_BODY_SCROLL__org_dominokit_domino_ui_datatable_events_BodyScrollEvent = "data-table-body-scroll";


TableEvent.$markImplementor(BodyScrollEvent);


exports = BodyScrollEvent; 
//# sourceMappingURL=BodyScrollEvent.js.map