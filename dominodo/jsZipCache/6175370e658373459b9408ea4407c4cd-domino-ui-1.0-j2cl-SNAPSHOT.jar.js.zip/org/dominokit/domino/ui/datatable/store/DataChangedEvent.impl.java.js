/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.DataChangedEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');


/**
 * @template C_T
  */
class DataChangedEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<C_T>} */
    this.f_newData__org_dominokit_domino_ui_datatable_store_DataChangedEvent_;
    /** @public {boolean} */
    this.f_append__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = false;
    /** @public {number} */
    this.f_totalCount__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = 0;
  }
  
  /**
   * Factory method corresponding to constructor 'DataChangedEvent(List, int)'.
   * @template C_T
   * @param {List<C_T>} newData
   * @param {number} totalCount
   * @return {!DataChangedEvent<C_T>}
   * @public
   */
  static $create__java_util_List__int(newData, totalCount) {
    DataChangedEvent.$clinit();
    let $instance = new DataChangedEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_store_DataChangedEvent__java_util_List__int(newData, totalCount);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DataChangedEvent(List, int)'.
   * @param {List<C_T>} newData
   * @param {number} totalCount
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_DataChangedEvent__java_util_List__int(newData, totalCount) {
    this.$ctor__java_lang_Object__();
    this.f_newData__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = newData;
    this.f_totalCount__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = totalCount;
    this.f_append__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'DataChangedEvent(List, boolean, int)'.
   * @template C_T
   * @param {List<C_T>} newData
   * @param {boolean} append
   * @param {number} totalCount
   * @return {!DataChangedEvent<C_T>}
   * @public
   */
  static $create__java_util_List__boolean__int(newData, append, totalCount) {
    DataChangedEvent.$clinit();
    let $instance = new DataChangedEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_store_DataChangedEvent__java_util_List__boolean__int(newData, append, totalCount);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DataChangedEvent(List, boolean, int)'.
   * @param {List<C_T>} newData
   * @param {boolean} append
   * @param {number} totalCount
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_DataChangedEvent__java_util_List__boolean__int(newData, append, totalCount) {
    this.$ctor__java_lang_Object__();
    this.f_newData__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = newData;
    this.f_append__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = append;
    this.f_totalCount__org_dominokit_domino_ui_datatable_store_DataChangedEvent_ = totalCount;
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_getNewData__() {
    return this.f_newData__org_dominokit_domino_ui_datatable_store_DataChangedEvent_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isAppend__() {
    return this.f_append__org_dominokit_domino_ui_datatable_store_DataChangedEvent_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getTotalCount__() {
    return this.f_totalCount__org_dominokit_domino_ui_datatable_store_DataChangedEvent_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DataChangedEvent.$clinit = (() =>{
    });
    DataChangedEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DataChangedEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DataChangedEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(DataChangedEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.DataChangedEvent'));




exports = DataChangedEvent; 
//# sourceMappingURL=DataChangedEvent.js.map