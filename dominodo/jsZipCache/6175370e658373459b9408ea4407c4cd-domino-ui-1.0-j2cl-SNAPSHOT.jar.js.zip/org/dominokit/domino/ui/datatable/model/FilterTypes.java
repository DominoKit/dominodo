package org.dominokit.domino.ui.datatable.model;

public enum FilterTypes {
    STRING, INTEGER, LONG, DOUBLE, SHORT, FLOAT, DECIMAL, BOOLEAN, DATE, ENUM
}
