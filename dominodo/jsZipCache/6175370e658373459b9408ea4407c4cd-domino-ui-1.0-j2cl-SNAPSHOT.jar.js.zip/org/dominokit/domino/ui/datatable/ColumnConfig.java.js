/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.ColumnConfig.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.ColumnConfig');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLTableCellElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _CellRenderer = goog.require('org.dominokit.domino.ui.datatable.CellRenderer');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _CellStyler = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler');
const _HeaderElement = goog.require('org.dominokit.domino.ui.datatable.HeaderElement');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _TextNode = goog.require('org.dominokit.domino.ui.utils.TextNode');


// Re-exports the implementation.
var ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
exports = ColumnConfig;
 