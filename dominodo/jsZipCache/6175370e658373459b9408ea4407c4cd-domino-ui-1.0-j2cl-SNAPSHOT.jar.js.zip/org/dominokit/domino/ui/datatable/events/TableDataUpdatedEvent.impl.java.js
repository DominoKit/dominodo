/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent$impl');

let List = goog.forwardDeclare('java.util.List$impl');


/**
 * @template C_T
 * @implements {TableEvent}
  */
class TableDataUpdatedEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<C_T>} */
    this.f_data__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent_;
    /** @public {number} */
    this.f_totalCount__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent_ = 0;
  }
  
  /**
   * @template C_T
   * @param {List<C_T>} data
   * @param {number} totalCount
   * @return {!TableDataUpdatedEvent<C_T>}
   * @public
   */
  static $create__java_util_List__int(data, totalCount) {
    TableDataUpdatedEvent.$clinit();
    let $instance = new TableDataUpdatedEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent__java_util_List__int(data, totalCount);
    return $instance;
  }
  
  /**
   * @param {List<C_T>} data
   * @param {number} totalCount
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent__java_util_List__int(data, totalCount) {
    this.$ctor__java_lang_Object__();
    this.f_data__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent_ = data;
    this.f_totalCount__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent_ = totalCount;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getType__() {
    return TableDataUpdatedEvent.f_DATA_UPDATED__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent;
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_getData__() {
    return this.f_data__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent_;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getTotalCount__() {
    return this.f_totalCount__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TableDataUpdatedEvent.$clinit = (() =>{
    });
    TableDataUpdatedEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TableDataUpdatedEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TableDataUpdatedEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(TableDataUpdatedEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent'));


/** @public {?string} @const */
TableDataUpdatedEvent.f_DATA_UPDATED__org_dominokit_domino_ui_datatable_events_TableDataUpdatedEvent = "table-data-updated";


TableEvent.$markImplementor(TableDataUpdatedEvent);


exports = TableDataUpdatedEvent; 
//# sourceMappingURL=TableDataUpdatedEvent.js.map