/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin$ScrollPosition.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.ScrollPosition');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Enum = goog.require('java.lang.Enum');
const _$Util = goog.require('nativebootstrap.Util');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Enums = goog.require('vmbootstrap.Enums');


// Re-exports the implementation.
var ScrollPosition = goog.require('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.ScrollPosition$impl');
exports = ScrollPosition;
 