/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$DetailsButtonElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RowMetaObject = goog.require('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let RecordDetailsPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$impl');
let $LambdaAdaptor$30 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement.$LambdaAdaptor$30$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_DetailsButtonElement_T
 * @implements {IsElement<HTMLElement>}
 * @implements {RowMetaObject}
  */
class DetailsButtonElement extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Button} */
    this.f_button__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_;
    /** @public {CellInfo<C_DetailsButtonElement_T>} */
    this.f_cellInfo__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_;
    /** @public {BaseIcon<?>} */
    this.f_expandIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_;
    /** @public {BaseIcon<?>} */
    this.f_collapseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_;
    /** @public {RecordDetailsPlugin<?>} */
    this.f_recordDetailsPlugin__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_;
    /** @public {boolean} */
    this.f_expanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = false;
  }
  
  /**
   * @template C_DetailsButtonElement_T
   * @param {BaseIcon<?>} expandIcon
   * @param {BaseIcon<?>} collapseIcon
   * @param {RecordDetailsPlugin<?>} recordDetailsPlugin
   * @param {CellInfo<C_DetailsButtonElement_T>} cellInfo
   * @return {!DetailsButtonElement<C_DetailsButtonElement_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(expandIcon, collapseIcon, recordDetailsPlugin, cellInfo) {
    DetailsButtonElement.$clinit();
    let $instance = new DetailsButtonElement();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(expandIcon, collapseIcon, recordDetailsPlugin, cellInfo);
    return $instance;
  }
  
  /**
   * @param {BaseIcon<?>} expandIcon
   * @param {BaseIcon<?>} collapseIcon
   * @param {RecordDetailsPlugin<?>} recordDetailsPlugin
   * @param {CellInfo<C_DetailsButtonElement_T>} cellInfo
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(expandIcon, collapseIcon, recordDetailsPlugin, cellInfo) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement();
    this.f_expandIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = expandIcon;
    this.f_collapseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = collapseIcon;
    this.f_recordDetailsPlugin__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = recordDetailsPlugin;
    this.f_cellInfo__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = cellInfo;
    this.f_button__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = /**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(expandIcon.m_copy__()).m_linkify__(), Button));
    this.f_button__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_style__().m_setProperty__java_lang_String__java_lang_String("padding", "0px").m_setHeight__java_lang_String("27px").m_setPaddingLeft__java_lang_String("2px").m_setPaddingRight__java_lang_String("2px");
    this.f_button__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$30(((/** Event */ evt) =>{
      if (this.f_expanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_) {
        this.m_collapse__();
      } else {
        this.m_expand__();
      }
    })));
  }
  
  /**
   * @return {CellInfo<C_DetailsButtonElement_T>}
   * @public
   */
  m_getCellInfo__() {
    return this.f_cellInfo__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_expand__() {
    this.f_button__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(this.f_collapseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_copy__());
    this.f_expanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = true;
    this.f_recordDetailsPlugin__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_setExpanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin(this);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_collapse__() {
    this.f_button__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(this.f_expandIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_copy__());
    this.f_expanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = false;
    this.f_recordDetailsPlugin__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_clear___$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin();
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_button__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_.m_asElement__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getKey__() {
    return RecordDetailsPlugin.f_RECORD_DETAILS_BUTTON__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement() {
    this.f_expanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DetailsButtonElement.$clinit = (() =>{
    });
    DetailsButtonElement.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DetailsButtonElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DetailsButtonElement);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    RecordDetailsPlugin = goog.module.get('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$impl');
    $LambdaAdaptor$30 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement.$LambdaAdaptor$30$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(DetailsButtonElement, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$DetailsButtonElement'));


IsElement.$markImplementor(DetailsButtonElement);
RowMetaObject.$markImplementor(DetailsButtonElement);


exports = DetailsButtonElement; 
//# sourceMappingURL=RecordDetailsPlugin$DetailsButtonElement.js.map