/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.Operator.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.model.Operator$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Operator extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_name__org_dominokit_domino_ui_datatable_model_Operator_;
  }
  
  /**
   * @param {?string} name
   * @return {!Operator}
   * @public
   */
  static $create__java_lang_String(name) {
    Operator.$clinit();
    let $instance = new Operator();
    $instance.$ctor__org_dominokit_domino_ui_datatable_model_Operator__java_lang_String(name);
    return $instance;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_model_Operator__java_lang_String(name) {
    this.$ctor__java_lang_Object__();
    this.f_name__org_dominokit_domino_ui_datatable_model_Operator_ = name;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_ui_datatable_model_Operator_;
  }
  
  /**
   * @override
   * @param {*} o
   * @return {boolean}
   * @public
   */
  equals(o) {
    if ($Equality.$same(this, o)) {
      return true;
    }
    if (!Operator.$isInstance(o)) {
      return false;
    }
    let operator = /**@type {Operator} */ ($Casts.$to(o, Operator));
    return Objects.m_equals__java_lang_String__java_lang_String(this.m_getName__(), operator.m_getName__());
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return Objects.m_hash__arrayOf_java_lang_Object([this.m_getName__()]);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_isEqualTo__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_isEqualTo__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_isEqualTo__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_isEqualTo__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_notEquals__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_notEquals__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_notEquals__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_notEquals__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_startsWith__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_startsWith__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_startsWith__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_startsWith__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_endsWith__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_endsWith__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_endsWith__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_endsWith__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_lessThan__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_lessThan__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_lessThan__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_lessThan__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_lessThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_lessThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_lessThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_lessThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_greaterThan__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_greaterThan__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_greaterThan__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_greaterThan__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_greaterThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_greaterThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_greaterThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_greaterThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_between__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_between__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_between__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_between__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_is_Null__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_is_Null__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_is_Null__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_is_Null__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_isNotNull__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_isNotNull__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_isNotNull__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_isNotNull__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_isRankedFirst__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_isRankedFirst__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_isRankedFirst__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_isRankedFirst__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_isRankedLast__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_isRankedLast__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_isRankedLast__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_isRankedLast__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_isInTop__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_isInTop__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_isInTop__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_isInTop__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_isInBottom__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_isInBottom__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_isInBottom__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_isInBottom__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_isContains__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_isContains__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_isContains__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_isContains__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_containsAll__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_containsAll__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_containsAll__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_containsAll__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_notContains__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_notContains__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_notContains__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_notContains__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_containsAny__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_containsAny__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_containsAny__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_containsAny__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_like__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_like__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_like__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_like__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {Operator}
   * @public
   */
  static get f_notLike__org_dominokit_domino_ui_datatable_model_Operator() {
    return (Operator.$clinit(), Operator.$f_notLike__org_dominokit_domino_ui_datatable_model_Operator);
  }
  
  /**
   * @param {Operator} value
   * @return {void}
   * @public
   */
  static set f_notLike__org_dominokit_domino_ui_datatable_model_Operator(value) {
    (Operator.$clinit(), Operator.$f_notLike__org_dominokit_domino_ui_datatable_model_Operator = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Operator.$clinit = (() =>{
    });
    Operator.$loadModules();
    j_l_Object.$clinit();
    Operator.$f_isEqualTo__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("equals");
    Operator.$f_notEquals__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("notEquals");
    Operator.$f_startsWith__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("startsWith");
    Operator.$f_endsWith__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("endsWith");
    Operator.$f_lessThan__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("lessThan");
    Operator.$f_lessThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("lessThanOrEquals");
    Operator.$f_greaterThan__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("greaterThan");
    Operator.$f_greaterThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("greaterThanOrEquals");
    Operator.$f_between__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("between");
    Operator.$f_is_Null__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("isNull");
    Operator.$f_isNotNull__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("isNotNull");
    Operator.$f_isRankedFirst__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("isRankedFirst");
    Operator.$f_isRankedLast__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("isRankedLast");
    Operator.$f_isInTop__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("isInTop");
    Operator.$f_isInBottom__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("isInBottom");
    Operator.$f_isContains__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("contains");
    Operator.$f_containsAll__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("containsAll");
    Operator.$f_notContains__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("notContains");
    Operator.$f_containsAny__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("containsAny");
    Operator.$f_like__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("like");
    Operator.$f_notLike__org_dominokit_domino_ui_datatable_model_Operator = Operator.$create__java_lang_String("notLike");
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Operator;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Operator);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Objects = goog.module.get('java.util.Objects$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Operator, $Util.$makeClassName('org.dominokit.domino.ui.datatable.model.Operator'));


/** @private {Operator} */
Operator.$f_isEqualTo__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_notEquals__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_startsWith__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_endsWith__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_lessThan__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_lessThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_greaterThan__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_greaterThanOrEquals__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_between__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_is_Null__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_isNotNull__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_isRankedFirst__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_isRankedLast__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_isInTop__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_isInBottom__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_isContains__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_containsAll__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_notContains__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_containsAny__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_like__org_dominokit_domino_ui_datatable_model_Operator;


/** @private {Operator} */
Operator.$f_notLike__org_dominokit_domino_ui_datatable_model_Operator;




exports = Operator; 
//# sourceMappingURL=Operator.js.map