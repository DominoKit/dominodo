/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$MarkerColor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor.$LambdaAdaptor');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');


// Re-exports the implementation.
var MarkerColor = goog.require('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor$impl');
exports = MarkerColor;
 