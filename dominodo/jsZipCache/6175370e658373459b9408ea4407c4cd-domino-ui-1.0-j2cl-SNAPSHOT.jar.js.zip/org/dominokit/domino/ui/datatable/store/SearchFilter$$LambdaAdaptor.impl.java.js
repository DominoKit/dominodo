/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.SearchFilter$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.SearchFilter.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SearchFilter = goog.require('org.dominokit.domino.ui.datatable.store.SearchFilter$impl');

let SearchEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');


/**
 * @template C_T
 * @implements {SearchFilter<C_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(SearchEvent, C_T):boolean} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(SearchEvent, C_T):boolean} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_store_SearchFilter_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_store_SearchFilter_$LambdaAdaptor__org_dominokit_domino_ui_datatable_store_SearchFilter_$JsFunction(fn);
  }
  
  /**
   * @param {?function(SearchEvent, C_T):boolean} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_store_SearchFilter_$LambdaAdaptor__org_dominokit_domino_ui_datatable_store_SearchFilter_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_store_SearchFilter_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {SearchEvent} arg0
   * @param {C_T} arg1
   * @return {boolean}
   * @public
   */
  m_filterRecord__org_dominokit_domino_ui_datatable_events_SearchEvent__java_lang_Object(arg0, arg1) {
    let /** ?function(SearchEvent, C_T):boolean */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_datatable_store_SearchFilter_$LambdaAdaptor, $function(arg0, arg1));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.SearchFilter$$LambdaAdaptor'));


SearchFilter.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=SearchFilter$$LambdaAdaptor.js.map