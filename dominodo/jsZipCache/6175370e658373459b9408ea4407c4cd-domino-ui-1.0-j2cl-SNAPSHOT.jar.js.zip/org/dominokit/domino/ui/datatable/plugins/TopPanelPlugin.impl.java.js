/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');


/**
 * @abstract
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
 * @implements {IsElement<HTMLElement>}
  */
class TopPanelPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_TopPanelPlugin__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    if (Objects.m_nonNull__java_lang_Object(this.m_asElement__())) {
      dataTable.m_asElement__().appendChild(this.m_asElement__());
    }
  }
  
  /**
   * @abstract
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
  }
  
  /**
   * @abstract
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TopPanelPlugin.$clinit = (() =>{
    });
    TopPanelPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TopPanelPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TopPanelPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Objects = goog.module.get('java.util.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(TopPanelPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin'));


DataTablePlugin.$markImplementor(TopPanelPlugin);
IsElement.$markImplementor(TopPanelPlugin);


exports = TopPanelPlugin; 
//# sourceMappingURL=TopPanelPlugin.js.map