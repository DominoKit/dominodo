/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.TableEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.TableEvent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent.$LambdaAdaptor$impl');


/**
 * @interface
 */
class TableEvent {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getType__() {
  }
  
  /**
   * @param {?function():?string} fn
   * @return {TableEvent}
   * @public
   */
  static $adapt(fn) {
    TableEvent.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TableEvent.$clinit = (() =>{
    });
    TableEvent.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_events_TableEvent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_events_TableEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_events_TableEvent;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.events.TableEvent.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(TableEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.TableEvent'));


TableEvent.$markImplementor(/** @type {Function} */ (TableEvent));


exports = TableEvent; 
//# sourceMappingURL=TableEvent.js.map