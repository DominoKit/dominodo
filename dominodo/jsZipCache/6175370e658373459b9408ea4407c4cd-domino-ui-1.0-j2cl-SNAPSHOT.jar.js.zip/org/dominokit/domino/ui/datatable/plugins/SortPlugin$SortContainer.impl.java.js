/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.SortPlugin$SortContainer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.SortPlugin.SortContainer$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let SortDirection = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');
let SortPlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortPlugin$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @template C_T
  */
class SortContainer extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {SortPlugin<C_T>} */
    this.f_$outer_this__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer;
    /** @public {?string} */
    this.f_columnName__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_;
    /** @public {SortDirection} */
    this.f_sortDirection__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_;
    /** @public {HTMLElement} */
    this.f_directionElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_;
    /** @public {HTMLElement} */
    this.f_sortElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_;
  }
  
  /**
   * @template C_T
   * @param {SortPlugin<C_T>} $outer_this
   * @param {?string} columnName
   * @return {!SortContainer<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_plugins_SortPlugin__java_lang_String($outer_this, columnName) {
    SortContainer.$clinit();
    let $instance = new SortContainer();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin__java_lang_String($outer_this, columnName);
    return $instance;
  }
  
  /**
   * @param {SortPlugin<C_T>} $outer_this
   * @param {?string} columnName
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin__java_lang_String($outer_this, columnName) {
    this.f_$outer_this__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer = $outer_this;
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer();
    this.f_columnName__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_ = columnName;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_directionElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_.textContent = "import_export";
  }
  
  /**
   * @param {boolean} flip
   * @return {void}
   * @public
   */
  m_update__boolean(flip) {
    if (flip) {
      if ($Objects.m_equals__java_lang_Object__java_lang_Object(SortDirection.f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection, this.f_sortDirection__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_)) {
        this.f_sortDirection__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_ = SortDirection.f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection;
      } else {
        this.f_sortDirection__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_ = SortDirection.f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection;
      }
    }
    this.m_clear__();
    this.f_directionElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_.textContent = this.m_getSortArrow__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getSortArrow__() {
    if ($Objects.m_equals__java_lang_Object__java_lang_Object(SortDirection.f_ASC__org_dominokit_domino_ui_datatable_plugins_SortDirection, this.f_sortDirection__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_)) {
      return Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_arrow_upward__().m_getName__();
    } else {
      return Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_arrow_downward__().m_getName__();
    }
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer() {
    this.f_sortDirection__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_ = SortDirection.f_DESC__org_dominokit_domino_ui_datatable_plugins_SortDirection;
    this.f_directionElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_ = /**@type {Style<HTMLElement, HtmlContentBuilder<HTMLElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ (ElementUtil.m_contentBuilder__elemental2_dom_HTMLElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_arrow_upward__().m_asElement__())).m_textContent__java_lang_String("import_export"), HtmlContentBuilder)))).m_add__java_lang_String(Styles.f_font_15__org_dominokit_domino_ui_style_Styles).m_asElement__();
    this.f_sortElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_pull_right__org_dominokit_domino_ui_style_Styles], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_directionElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_), HtmlContentBuilder)).m_style__java_lang_String("min-width: 15px;"), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SortContainer.$clinit = (() =>{
    });
    SortContainer.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SortContainer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SortContainer);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    SortDirection = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(SortContainer, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.SortPlugin$SortContainer'));




exports = SortContainer; 
//# sourceMappingURL=SortPlugin$SortContainer.js.map