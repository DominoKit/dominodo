/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');


// Re-exports the implementation.
var TopPanelPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.TopPanelPlugin$impl');
exports = TopPanelPlugin;
 