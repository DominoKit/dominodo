/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable$SelectionChangeListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener.$LambdaAdaptor$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @interface
 * @template C_SelectionChangeListener_T
 */
class SelectionChangeListener {
  /**
   * @abstract
   * @param {List<TableRow<C_SelectionChangeListener_T>>} selectedTableRows
   * @param {List<C_SelectionChangeListener_T>} selectedRecords
   * @return {void}
   * @public
   */
  m_onSelectionChanged__java_util_List__java_util_List(selectedTableRows, selectedRecords) {
  }
  
  /**
   * @template C_SelectionChangeListener_T
   * @param {?function(List<TableRow<C_SelectionChangeListener_T>>, List<C_SelectionChangeListener_T>):void} fn
   * @return {SelectionChangeListener<C_SelectionChangeListener_T>}
   * @public
   */
  static $adapt(fn) {
    SelectionChangeListener.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SelectionChangeListener.$clinit = (() =>{
    });
    SelectionChangeListener.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SelectionChangeListener, $Util.$makeClassName('org.dominokit.domino.ui.datatable.DataTable$SelectionChangeListener'));


SelectionChangeListener.$markImplementor(/** @type {Function} */ (SelectionChangeListener));


exports = SelectionChangeListener; 
//# sourceMappingURL=DataTable$SelectionChangeListener.js.map