/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.StoreDataChangeListener.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DataChangedEvent = goog.require('org.dominokit.domino.ui.datatable.store.DataChangedEvent');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener.$LambdaAdaptor');


// Re-exports the implementation.
var StoreDataChangeListener = goog.require('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');
exports = StoreDataChangeListener;
 