/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.SearchEvent.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.events.SearchEvent');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _List = goog.require('java.util.List');
const _Predicate = goog.require('java.util.function.Predicate');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var SearchEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
exports = SearchEvent;
 