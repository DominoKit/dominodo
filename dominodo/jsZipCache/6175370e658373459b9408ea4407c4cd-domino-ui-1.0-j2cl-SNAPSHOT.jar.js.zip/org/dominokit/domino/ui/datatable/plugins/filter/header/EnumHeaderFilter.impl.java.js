/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Enum = goog.forwardDeclare('java.lang.Enum$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let SearchContext = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.SearchContext$impl');
let Select = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
let SelectOption = goog.forwardDeclare('org.dominokit.domino.ui.forms.SelectOption$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T, C_E
 * @implements {HeaderFilter<C_T>}
  */
class EnumHeaderFilter extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Select<?string>} */
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter_;
  }
  
  /**
   * @template M_T, M_E
   * @param {Array<M_E>} values
   * @return {EnumHeaderFilter<M_T, M_E>}
   * @public
   */
  static m_create__arrayOf_java_lang_Enum(values) {
    EnumHeaderFilter.$clinit();
    return /**@type {!EnumHeaderFilter<*, Enum>} */ (EnumHeaderFilter.$create__arrayOf_java_lang_Enum__java_lang_String(values, "ALL"));
  }
  
  /**
   * @template M_T, M_E
   * @param {Array<M_E>} values
   * @param {?string} allLabel
   * @return {EnumHeaderFilter<M_T, M_E>}
   * @public
   */
  static m_create__arrayOf_java_lang_Enum__java_lang_String(values, allLabel) {
    EnumHeaderFilter.$clinit();
    return /**@type {!EnumHeaderFilter<*, Enum>} */ (EnumHeaderFilter.$create__arrayOf_java_lang_Enum__java_lang_String(values, allLabel));
  }
  
  /**
   * @template C_T, C_E
   * @param {Array<C_E>} values
   * @param {?string} allLabel
   * @return {!EnumHeaderFilter<C_T, C_E>}
   * @public
   */
  static $create__arrayOf_java_lang_Enum__java_lang_String(values, allLabel) {
    EnumHeaderFilter.$clinit();
    let $instance = new EnumHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter__arrayOf_java_lang_Enum__java_lang_String(values, allLabel);
    return $instance;
  }
  
  /**
   * @param {Array<C_E>} values
   * @param {?string} allLabel
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter__arrayOf_java_lang_Enum__java_lang_String(values, allLabel) {
    this.$ctor__java_lang_Object__();
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter_ = /**@type {Select<?string>} */ ($Casts.$to(/**@type {Select<?string>} */ (Select.m_create__()).m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String("", allLabel))).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Select<?string> */ element) =>{
      /**@type {Stream<Enum>} */ (Arrays.m_stream__arrayOf_java_lang_Object(values)).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** Enum */ value) =>{
        element.m_appendChild__org_dominokit_domino_ui_forms_SelectOption(/**@type {SelectOption<?string>} */ (SelectOption.m_create__java_lang_Object__java_lang_String(/**@type {Enum} */ (value).toString(), /**@type {Enum} */ (value).toString())));
      })));
    }))), Select)).m_selectAt__int(0);
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter_.m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, Select<?string>> */ style) =>{
      style.m_setMarginBottom__java_lang_String("0px");
    })));
  }
  
  /**
   * @override
   * @param {SearchContext<C_T>} searchContext
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_ColumnConfig(searchContext, columnConfig) {
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter_.m_addSelectionHandler__org_dominokit_domino_ui_forms_Select_SelectionHandler(SelectionHandler.$adapt(((/** SelectOption<?string> */ option) =>{
      if (this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter_.m_getSelectedIndex__() > 0) {
        searchContext.m_add__org_dominokit_domino_ui_datatable_model_Filter(Filter.m_create__java_lang_String__java_lang_String__org_dominokit_domino_ui_datatable_model_Category__org_dominokit_domino_ui_datatable_model_FilterTypes(columnConfig.m_getName__(), /**@type {?string} */ ($Casts.$to(option.m_getValue__(), j_l_String)), Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category, FilterTypes.f_ENUM__org_dominokit_domino_ui_datatable_model_FilterTypes));
        searchContext.m_fireSearchEvent__();
      } else {
        searchContext.m_remove__java_lang_String__org_dominokit_domino_ui_datatable_model_Category(columnConfig.m_getName__(), Category.f_HEADER_FILTER__org_dominokit_domino_ui_datatable_model_Category);
        searchContext.m_fireSearchEvent__();
      }
    })));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter_.m_selectAt__int__boolean(0, true);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_select__org_dominokit_domino_ui_datatable_plugins_filter_header_EnumHeaderFilter_.m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EnumHeaderFilter.$clinit = (() =>{
    });
    EnumHeaderFilter.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof EnumHeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, EnumHeaderFilter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    Arrays = goog.module.get('java.util.Arrays$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Category = goog.module.get('org.dominokit.domino.ui.datatable.model.Category$impl');
    Filter = goog.module.get('org.dominokit.domino.ui.datatable.model.Filter$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    Select = goog.module.get('org.dominokit.domino.ui.forms.Select$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.forms.Select.SelectionHandler$impl');
    SelectOption = goog.module.get('org.dominokit.domino.ui.forms.SelectOption$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(EnumHeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.EnumHeaderFilter'));


HeaderFilter.$markImplementor(EnumHeaderFilter);


exports = EnumHeaderFilter; 
//# sourceMappingURL=EnumHeaderFilter.js.map