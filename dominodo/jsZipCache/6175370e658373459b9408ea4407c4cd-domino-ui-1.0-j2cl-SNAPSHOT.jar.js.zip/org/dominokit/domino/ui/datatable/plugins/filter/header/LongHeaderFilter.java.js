/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.LongHeaderFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.LongHeaderFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DelayedHeaderFilterInput = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput');
const _$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _FilterTypes = goog.require('org.dominokit.domino.ui.datatable.model.FilterTypes');
const _LongBox = goog.require('org.dominokit.domino.ui.forms.LongBox');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var LongHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.LongHeaderFilter$impl');
exports = LongHeaderFilter;
 