/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.TemplateUtil$SelectorFunction$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SelectorFunction = goog.require('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 