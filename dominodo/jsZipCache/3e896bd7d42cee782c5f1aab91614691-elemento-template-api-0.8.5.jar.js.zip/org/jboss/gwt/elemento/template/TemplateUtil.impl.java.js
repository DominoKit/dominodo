/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.TemplateUtil.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.template.TemplateUtil$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let NodeFilter_$Overlay = goog.forwardDeclare('elemental2.dom.NodeFilter.$Overlay$impl');
let NullPointerException = goog.forwardDeclare('java.lang.NullPointerException$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let SafeHtml = goog.forwardDeclare('org.gwtproject.safehtml.shared.SafeHtml$impl');
let SafeHtmlUtils = goog.forwardDeclare('org.gwtproject.safehtml.shared.SafeHtmlUtils$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let SelectorFunction = goog.forwardDeclare('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Exceptions = goog.forwardDeclare('vmbootstrap.Exceptions$impl');


class TemplateUtil extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @param {HTMLElement} context
   * @param {?string} identifier
   * @return {HTMLElement}
   * @public
   */
  static m_resolveElement__elemental2_dom_HTMLElement__java_lang_String(context, identifier) {
    TemplateUtil.$clinit();
    let element = TemplateUtil.$f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_.m_select__elemental2_dom_HTMLElement__java_lang_String(context, identifier);
    let htmlElement = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(element), $Overlay));
    return htmlElement;
  }
  
  /**
   * @template M_E
   * @param {HTMLElement} context
   * @param {?string} identifier
   * @return {M_E}
   * @public
   */
  static m_resolveElementAs__elemental2_dom_HTMLElement__java_lang_String(context, identifier) {
    TemplateUtil.$clinit();
    let element = TemplateUtil.$f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_.m_select__elemental2_dom_HTMLElement__java_lang_String(context, identifier);
    let htmlElement = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(element), $Overlay));
    return htmlElement;
  }
  
  /**
   * @param {HTMLElement} context
   * @param {?string} identifier
   * @param {HTMLElement} newElement
   * @return {void}
   * @public
   */
  static m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(context, identifier, newElement) {
    TemplateUtil.$clinit();
    if ($Equality.$same(newElement, null)) {
      throw $Exceptions.toJs(NullPointerException.$create__java_lang_String("New element must not be null in TemplateUtils.replaceElement()"));
    }
    let oldElement = TemplateUtil.m_resolveElement__elemental2_dom_HTMLElement__java_lang_String(context, identifier);
    if (!$Equality.$same(oldElement, null) && !$Equality.$same(oldElement.parentNode, null)) {
      oldElement.parentNode.replaceChild(newElement, oldElement);
    }
  }
  
  /**
   * @param {HTMLElement} context
   * @param {?string} identifier
   * @param {IsElement} newElement
   * @return {void}
   * @public
   */
  static m_replaceIsElement__elemental2_dom_HTMLElement__java_lang_String__org_jboss_gwt_elemento_core_IsElement(context, identifier, newElement) {
    TemplateUtil.$clinit();
    TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(context, identifier, newElement.m_asElement__());
  }
  
  /**
   * @template M_E
   * @param {HTMLElement} context
   * @param {?string} identifier
   * @return {M_E}
   * @public
   */
  static m_resolveCustomElement__elemental2_dom_HTMLElement__java_lang_String(context, identifier) {
    TemplateUtil.$clinit();
    let element = TemplateUtil.$f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_.m_select__elemental2_dom_HTMLElement__java_lang_String(context, identifier);
    let customElement = Js.m_cast__java_lang_Object(element);
    return customElement;
  }
  
  /**
   * @template M_E
   * @param {HTMLElement} context
   * @param {?string} identifier
   * @param {M_E} customElement
   * @return {void}
   * @public
   */
  static m_replaceCustomElement__elemental2_dom_HTMLElement__java_lang_String__java_lang_Object(context, identifier, customElement) {
    TemplateUtil.$clinit();
    let element = /**@type {HTMLElement} */ ($Casts.$to(Js.m_cast__java_lang_Object(customElement), $Overlay));
    TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(context, identifier, element);
  }
  
  /**
   * @param {HTMLElement} context
   * @param {?string} expression
   * @param {*} value
   * @return {void}
   * @public
   */
  static m_replaceExpression__elemental2_dom_HTMLElement__java_lang_String__java_lang_Object(context, expression, value) {
    TemplateUtil.$clinit();
    let /** SafeHtml */ safeValue;
    if (SafeHtml.$isInstance(value)) {
      safeValue = /**@type {SafeHtml} */ ($Casts.$to(value, SafeHtml));
    } else {
      safeValue = SafeHtmlUtils.m_fromString__java_lang_String(j_l_String.m_valueOf__java_lang_Object(value));
    }
    TemplateUtil.m_replaceNestedExpressionInText__elemental2_dom_HTMLElement__java_lang_String__java_lang_String_$p_org_jboss_gwt_elemento_template_TemplateUtil(context, expression, j_l_String.m_valueOf__java_lang_Object(value));
    TemplateUtil.m_replaceNestedExpressionInAttributes__elemental2_dom_HTMLElement__java_lang_String__java_lang_String_$p_org_jboss_gwt_elemento_template_TemplateUtil(context, expression, safeValue.m_asString__());
    TemplateUtil.m_replaceExpressionInAttributes__elemental2_dom_HTMLElement__java_lang_String__java_lang_String_$p_org_jboss_gwt_elemento_template_TemplateUtil(context, expression, safeValue.m_asString__());
  }
  
  /**
   * @param {HTMLElement} context
   * @param {?string} expression
   * @param {?string} value
   * @return {void}
   * @public
   */
  static m_replaceNestedExpressionInText__elemental2_dom_HTMLElement__java_lang_String__java_lang_String_$p_org_jboss_gwt_elemento_template_TemplateUtil(context, expression, value) {
    TemplateUtil.$clinit();
    let treeWalker = DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.createTreeWalker(context, NodeFilter_$Overlay.f_SHOW_TEXT__elemental2_dom_NodeFilter_$Overlay, null, false);
    while (!$Equality.$same(treeWalker.nextNode(), null)) {
      if (!$Equality.$same(treeWalker.currentNode.nodeValue, null) && j_l_String.m_contains__java_lang_String__java_lang_CharSequence(treeWalker.currentNode.nodeValue, expression)) {
        treeWalker.currentNode.nodeValue = j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(treeWalker.currentNode.nodeValue, expression, value);
      }
    }
  }
  
  /**
   * @param {HTMLElement} context
   * @param {?string} expression
   * @param {?string} value
   * @return {void}
   * @public
   */
  static m_replaceNestedExpressionInAttributes__elemental2_dom_HTMLElement__java_lang_String__java_lang_String_$p_org_jboss_gwt_elemento_template_TemplateUtil(context, expression, value) {
    TemplateUtil.$clinit();
    let treeWalker = DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.createTreeWalker(context, NodeFilter_$Overlay.f_SHOW_ELEMENT__elemental2_dom_NodeFilter_$Overlay, null, false);
    while (!$Equality.$same(treeWalker.nextNode(), null)) {
      if ($Overlay.$isInstance(treeWalker.currentNode)) {
        TemplateUtil.m_replaceExpressionInAttributes__elemental2_dom_HTMLElement__java_lang_String__java_lang_String_$p_org_jboss_gwt_elemento_template_TemplateUtil(/**@type {HTMLElement} */ ($Casts.$to(treeWalker.currentNode, $Overlay)), expression, value);
      }
    }
  }
  
  /**
   * @param {HTMLElement} context
   * @param {?string} expression
   * @param {?string} value
   * @return {void}
   * @public
   */
  static m_replaceExpressionInAttributes__elemental2_dom_HTMLElement__java_lang_String__java_lang_String_$p_org_jboss_gwt_elemento_template_TemplateUtil(context, expression, value) {
    TemplateUtil.$clinit();
    let attributes = context.attributes;
    for (let i = 0; i < JsArrayLike_$Overlay.m_getLength__jsinterop_base_JsArrayLike(attributes); i++) {
      let attribute = attributes.item(i);
      let currentValue = attribute.nodeValue;
      if (!$Equality.$same(currentValue, null) && j_l_String.m_contains__java_lang_String__java_lang_CharSequence(currentValue, expression)) {
        attribute.nodeValue = j_l_String.m_replace__java_lang_String__java_lang_CharSequence__java_lang_CharSequence(currentValue, expression, value);
      }
    }
  }
  
  /**
   * @return {!TemplateUtil}
   * @public
   */
  static $create__() {
    TemplateUtil.$clinit();
    let $instance = new TemplateUtil();
    $instance.$ctor__org_jboss_gwt_elemento_template_TemplateUtil__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_template_TemplateUtil__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {SelectorFunction}
   * @public
   */
  static get f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_() {
    return (TemplateUtil.$clinit(), TemplateUtil.$f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_);
  }
  
  /**
   * @param {SelectorFunction} value
   * @return {void}
   * @public
   */
  static set f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_(value) {
    (TemplateUtil.$clinit(), TemplateUtil.$f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TemplateUtil.$clinit = (() =>{
    });
    TemplateUtil.$loadModules();
    j_l_Object.$clinit();
    TemplateUtil.$f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_ = SelectorFunction.$adapt(((/** HTMLElement */ context, /** ?string */ identifier) =>{
      return context.querySelector("[data-element=" + j_l_String.m_valueOf__java_lang_Object(identifier) + "]");
    }));
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TemplateUtil;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TemplateUtil);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    NodeFilter_$Overlay = goog.module.get('elemental2.dom.NodeFilter.$Overlay$impl');
    NullPointerException = goog.module.get('java.lang.NullPointerException$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    JsArrayLike_$Overlay = goog.module.get('jsinterop.base.JsArrayLike.$Overlay$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    SafeHtml = goog.module.get('org.gwtproject.safehtml.shared.SafeHtml$impl');
    SafeHtmlUtils = goog.module.get('org.gwtproject.safehtml.shared.SafeHtmlUtils$impl');
    SelectorFunction = goog.module.get('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Exceptions = goog.module.get('vmbootstrap.Exceptions$impl');
  }
  
  
};

$Util.$setClassMetadata(TemplateUtil, $Util.$makeClassName('org.jboss.gwt.elemento.template.TemplateUtil'));


/** @private {SelectorFunction} */
TemplateUtil.$f_DATA_ELEMENT__org_jboss_gwt_elemento_template_TemplateUtil_;




exports = TemplateUtil; 
//# sourceMappingURL=TemplateUtil.js.map