/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.Templated$Injectable.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.template.Templated.Injectable');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Enum = goog.require('java.lang.Enum');
const _$Util = goog.require('nativebootstrap.Util');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Enums = goog.require('vmbootstrap.Enums');


// Re-exports the implementation.
var Injectable = goog.require('org.jboss.gwt.elemento.template.Templated.Injectable$impl');
exports = Injectable;
 