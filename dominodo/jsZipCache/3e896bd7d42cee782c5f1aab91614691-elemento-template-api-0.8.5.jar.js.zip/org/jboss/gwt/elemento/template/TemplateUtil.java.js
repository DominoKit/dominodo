/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.TemplateUtil.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.template.TemplateUtil');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _NodeFilter_$Overlay = goog.require('elemental2.dom.NodeFilter.$Overlay');
const _NullPointerException = goog.require('java.lang.NullPointerException');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$Equality = goog.require('nativebootstrap.Equality');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');
const _SafeHtmlUtils = goog.require('org.gwtproject.safehtml.shared.SafeHtmlUtils');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _SelectorFunction = goog.require('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var TemplateUtil = goog.require('org.jboss.gwt.elemento.template.TemplateUtil$impl');
exports = TemplateUtil;
 