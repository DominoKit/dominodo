/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.DataElement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.template.DataElement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var DataElement = goog.require('org.jboss.gwt.elemento.template.DataElement$impl');
exports = DataElement;
 