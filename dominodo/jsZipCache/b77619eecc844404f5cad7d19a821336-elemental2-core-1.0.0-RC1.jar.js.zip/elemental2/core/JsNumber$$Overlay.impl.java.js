/**
 * @fileoverview transpiled from elemental2.core.JsNumber$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsNumber.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsNumber.ToLocaleStringLocalesUnionType.$Overlay$impl');
let ToStringRadixUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsNumber.ToStringRadixUnionType.$Overlay$impl');
let JsObject_$Overlay = goog.forwardDeclare('elemental2.core.JsObject.$Overlay$impl');
let Integer = goog.forwardDeclare('java.lang.Integer$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class JsNumber_$Overlay {
  /**
   * @param {Number} $thisArg
   * @param {?string} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsNumber__java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsNumber_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Number} $thisArg
   * @param {Array<?string>} locales
   * @param {Object} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsNumber__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, options) {
    JsNumber_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)), options);
  }
  
  /**
   * @param {Number} $thisArg
   * @param {?string} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsNumber__java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsNumber_$Overlay.$clinit();
    return JsNumber_$Overlay.m_toLocaleString__elemental2_core_JsNumber__java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Number} $thisArg
   * @param {Array<?string>} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsNumber__arrayOf_java_lang_String__java_lang_Object($thisArg, locales, options) {
    JsNumber_$Overlay.$clinit();
    return JsNumber_$Overlay.m_toLocaleString__elemental2_core_JsNumber__arrayOf_java_lang_String__elemental2_core_JsObject($thisArg, locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Number} $thisArg
   * @param {?string} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsNumber__java_lang_String($thisArg, locales) {
    JsNumber_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Number} $thisArg
   * @param {Array<?string>} locales
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsNumber__arrayOf_java_lang_String($thisArg, locales) {
    JsNumber_$Overlay.$clinit();
    return $thisArg.toLocaleString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(locales)));
  }
  
  /**
   * @param {Number} $thisArg
   * @param {?} locales
   * @param {*} options
   * @return {?string}
   * @public
   */
  static m_toLocaleString__elemental2_core_JsNumber__elemental2_core_JsNumber_ToLocaleStringLocalesUnionType__java_lang_Object($thisArg, locales, options) {
    JsNumber_$Overlay.$clinit();
    return $thisArg.toLocaleString(locales, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(options)));
  }
  
  /**
   * @param {Number} $thisArg
   * @param {Number} radix
   * @return {?string}
   * @public
   */
  static m_toString__elemental2_core_JsNumber__elemental2_core_JsNumber($thisArg, radix) {
    JsNumber_$Overlay.$clinit();
    return $thisArg.toString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(radix)));
  }
  
  /**
   * @param {Number} $thisArg
   * @param {number} radix
   * @return {?string}
   * @public
   */
  static m_toString__elemental2_core_JsNumber__int($thisArg, radix) {
    JsNumber_$Overlay.$clinit();
    return $thisArg.toString(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(Integer.m_valueOf__int(radix))));
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_EPSILON__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_EPSILON__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_EPSILON__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_EPSILON__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_MAX_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MAX_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_MAX_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MAX_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_MAX_VALUE__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MAX_VALUE__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_MAX_VALUE__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MAX_VALUE__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_MIN_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MIN_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_MIN_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MIN_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_MIN_VALUE__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MIN_VALUE__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_MIN_VALUE__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_MIN_VALUE__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_NEGATIVE_INFINITY__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_NEGATIVE_INFINITY__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_NEGATIVE_INFINITY__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_NEGATIVE_INFINITY__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_NaN__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_NaN__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_NaN__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_NaN__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_POSITIVE_INFINITY__elemental2_core_JsNumber_$Overlay() {
    return (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_POSITIVE_INFINITY__elemental2_core_JsNumber_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_POSITIVE_INFINITY__elemental2_core_JsNumber_$Overlay(value) {
    (JsNumber_$Overlay.$clinit(), JsNumber_$Overlay.$f_POSITIVE_INFINITY__elemental2_core_JsNumber_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    JsNumber_$Overlay.$clinit = (() =>{
    });
    JsNumber_$Overlay.$loadModules();
    JsNumber_$Overlay.$f_EPSILON__elemental2_core_JsNumber_$Overlay = Number.EPSILON;
    JsNumber_$Overlay.$f_MAX_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay = Number.MAX_SAFE_INTEGER;
    JsNumber_$Overlay.$f_MAX_VALUE__elemental2_core_JsNumber_$Overlay = Number.MAX_VALUE;
    JsNumber_$Overlay.$f_MIN_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay = Number.MIN_SAFE_INTEGER;
    JsNumber_$Overlay.$f_MIN_VALUE__elemental2_core_JsNumber_$Overlay = Number.MIN_VALUE;
    JsNumber_$Overlay.$f_NEGATIVE_INFINITY__elemental2_core_JsNumber_$Overlay = Number.NEGATIVE_INFINITY;
    JsNumber_$Overlay.$f_NaN__elemental2_core_JsNumber_$Overlay = Number.NaN;
    JsNumber_$Overlay.$f_POSITIVE_INFINITY__elemental2_core_JsNumber_$Overlay = Number.POSITIVE_INFINITY;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Number;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Integer = goog.module.get('java.lang.Integer$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(JsNumber_$Overlay, $Util.$makeClassName('Number'));


/** @private {number} */
JsNumber_$Overlay.$f_EPSILON__elemental2_core_JsNumber_$Overlay = 0.0;


/** @private {number} */
JsNumber_$Overlay.$f_MAX_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay = 0.0;


/** @private {number} */
JsNumber_$Overlay.$f_MAX_VALUE__elemental2_core_JsNumber_$Overlay = 0.0;


/** @private {number} */
JsNumber_$Overlay.$f_MIN_SAFE_INTEGER__elemental2_core_JsNumber_$Overlay = 0.0;


/** @private {number} */
JsNumber_$Overlay.$f_MIN_VALUE__elemental2_core_JsNumber_$Overlay = 0.0;


/** @private {number} */
JsNumber_$Overlay.$f_NEGATIVE_INFINITY__elemental2_core_JsNumber_$Overlay = 0.0;


/** @private {number} */
JsNumber_$Overlay.$f_NaN__elemental2_core_JsNumber_$Overlay = 0.0;


/** @private {number} */
JsNumber_$Overlay.$f_POSITIVE_INFINITY__elemental2_core_JsNumber_$Overlay = 0.0;


exports = JsNumber_$Overlay; 
//# sourceMappingURL=JsNumber$$Overlay.js.map