/**
 * @fileoverview transpiled from elemental2.core.JsArray$FromArrayLikeUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.JsArray.FromArrayLikeUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsIterable_$Overlay = goog.require('elemental2.core.JsIterable.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _j_l_String = goog.require('java.lang.String');
const _Js = goog.require('jsinterop.base.Js');
const _$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var FromArrayLikeUnionType_$Overlay = goog.require('elemental2.core.JsArray.FromArrayLikeUnionType.$Overlay$impl');
exports = FromArrayLikeUnionType_$Overlay;
 