/**
 * @fileoverview transpiled from elemental2.core.JsNumber$ToStringRadixUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsNumber.ToStringRadixUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsNumber.$Overlay$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ToStringRadixUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ToStringRadixUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ToStringRadixUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {number}
   * @public
   */
  static m_asInt__elemental2_core_JsNumber_ToStringRadixUnionType($thisArg) {
    ToStringRadixUnionType_$Overlay.$clinit();
    return Js.m_asInt__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {Number}
   * @public
   */
  static m_asJsNumber__elemental2_core_JsNumber_ToStringRadixUnionType($thisArg) {
    ToStringRadixUnionType_$Overlay.$clinit();
    return /**@type {Number} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isInt__elemental2_core_JsNumber_ToStringRadixUnionType($thisArg) {
    ToStringRadixUnionType_$Overlay.$clinit();
    return Double.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isJsNumber__elemental2_core_JsNumber_ToStringRadixUnionType($thisArg) {
    ToStringRadixUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ToStringRadixUnionType_$Overlay.$clinit = (() =>{
    });
    ToStringRadixUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.core.JsNumber.$Overlay$impl');
    Double = goog.module.get('java.lang.Double$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = ToStringRadixUnionType_$Overlay; 
//# sourceMappingURL=JsNumber$ToStringRadixUnionType$$Overlay.js.map