/**
 * @fileoverview transpiled from elemental2.core.JsWeakMap$ConstructorIterableUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsWeakMap.ConstructorIterableUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsIterable.$Overlay$impl');
let ConstructorIterableJsIterableTypeParameterArrayUnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsWeakMap.ConstructorIterableJsIterableTypeParameterArrayUnionType.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class ConstructorIterableUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ConstructorIterableUnionType_$Overlay));
  }
  
  /**
   * @template C_ConstructorIterableUnionType_KEY, C_ConstructorIterableUnionType_VALUE
   * @param {?} $thisArg
   * @return {Array<Array<?>>}
   * @public
   */
  static m_asConstructorIterableArrayArrayUnionTypeArrayArray__elemental2_core_JsWeakMap_ConstructorIterableUnionType($thisArg) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return /**@type {Array<Array<?>>} */ ($Arrays.$castToNative(Js.m_cast__java_lang_Object($thisArg)));
  }
  
  /**
   * @template C_ConstructorIterableUnionType_KEY, C_ConstructorIterableUnionType_VALUE
   * @param {?} $thisArg
   * @return {Iterable<Array<?>>}
   * @public
   */
  static m_asJsIterable__elemental2_core_JsWeakMap_ConstructorIterableUnionType($thisArg) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return /**@type {Iterable<Array<?>>} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @template C_ConstructorIterableUnionType_KEY, C_ConstructorIterableUnionType_VALUE
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isConstructorIterableArrayArrayUnionTypeArrayArray__elemental2_core_JsWeakMap_ConstructorIterableUnionType($thisArg) {
    ConstructorIterableUnionType_$Overlay.$clinit();
    return $Arrays.$instanceIsOfType(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)), j_l_Object, 1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ConstructorIterableUnionType_$Overlay.$clinit = (() =>{
    });
    ConstructorIterableUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.core.JsIterable.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = ConstructorIterableUnionType_$Overlay; 
//# sourceMappingURL=JsWeakMap$ConstructorIterableUnionType$$Overlay.js.map