/**
 * @fileoverview transpiled from elemental2.core.Float64Array$ConstructorLengthUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Float64Array.ConstructorLengthUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.ArrayBuffer.$Overlay$impl');
let ArrayBufferView_$Overlay = goog.forwardDeclare('elemental2.core.ArrayBufferView.$Overlay$impl');
let SharedArrayBuffer_$Overlay = goog.forwardDeclare('elemental2.core.SharedArrayBuffer.$Overlay$impl');
let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $int = goog.forwardDeclare('vmbootstrap.primitives.$int$impl');


class ConstructorLengthUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), ConstructorLengthUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {ArrayBuffer}
   * @public
   */
  static m_asArrayBuffer__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return /**@type {ArrayBuffer} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {ArrayBufferView}
   * @public
   */
  static m_asArrayBufferView__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return /**@type {ArrayBufferView} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), ArrayBufferView_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {number}
   * @public
   */
  static m_asInt__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return Js.m_asInt__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {Array<number>}
   * @public
   */
  static m_asIntArray__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return /**@type {Array<number>} */ ($Arrays.$castTo(Js.m_cast__java_lang_Object($thisArg), $int, 1));
  }
  
  /**
   * @param {?} $thisArg
   * @return {SharedArrayBuffer}
   * @public
   */
  static m_asSharedArrayBuffer__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return /**@type {SharedArrayBuffer} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), SharedArrayBuffer_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isArrayBuffer__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isArrayBufferView__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return ArrayBufferView_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isInt__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return Double.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isIntArray__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return $Arrays.$instanceIsOfType(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)), j_l_Object, 1);
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isSharedArrayBuffer__elemental2_core_Float64Array_ConstructorLengthUnionType($thisArg) {
    ConstructorLengthUnionType_$Overlay.$clinit();
    return SharedArrayBuffer_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ConstructorLengthUnionType_$Overlay.$clinit = (() =>{
    });
    ConstructorLengthUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.core.ArrayBuffer.$Overlay$impl');
    ArrayBufferView_$Overlay = goog.module.get('elemental2.core.ArrayBufferView.$Overlay$impl');
    SharedArrayBuffer_$Overlay = goog.module.get('elemental2.core.SharedArrayBuffer.$Overlay$impl');
    Double = goog.module.get('java.lang.Double$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $int = goog.module.get('vmbootstrap.primitives.$int$impl');
  }
  
  
};



exports = ConstructorLengthUnionType_$Overlay; 
//# sourceMappingURL=Float64Array$ConstructorLengthUnionType$$Overlay.js.map