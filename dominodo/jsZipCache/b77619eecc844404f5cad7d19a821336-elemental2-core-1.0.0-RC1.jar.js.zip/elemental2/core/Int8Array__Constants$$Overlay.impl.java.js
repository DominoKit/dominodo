/**
 * @fileoverview transpiled from elemental2.core.Int8Array__Constants$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Int8Array__Constants.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Int8Array;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('Int8Array'));


exports = $Overlay; 
//# sourceMappingURL=Int8Array__Constants$$Overlay.js.map