/**
 * @fileoverview transpiled from elemental2.core.JSONType$StringifyReplacerUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JSONType.StringifyReplacerUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $JavaScriptFunction = goog.forwardDeclare('vmbootstrap.JavaScriptFunction$impl');


class $Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    $Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Array<?string>}
   * @public
   */
  static m_asStringArray__elemental2_core_JSONType_StringifyReplacerUnionType($thisArg) {
    $Overlay.$clinit();
    return /**@type {Array<?string>} */ ($Arrays.$castTo(Js.m_cast__java_lang_Object($thisArg), j_l_String, 1));
  }
  
  /**
   * @param {?} $thisArg
   * @return {?function(?string, *):*}
   * @public
   */
  static m_asStringifyReplacerFn__elemental2_core_JSONType_StringifyReplacerUnionType($thisArg) {
    $Overlay.$clinit();
    return /**@type {?function(?string, *):*} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $JavaScriptFunction));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isStringArray__elemental2_core_JSONType_StringifyReplacerUnionType($thisArg) {
    $Overlay.$clinit();
    return $Arrays.$instanceIsOfType(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)), j_l_Object, 1);
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isStringifyReplacerFn__elemental2_core_JSONType_StringifyReplacerUnionType($thisArg) {
    $Overlay.$clinit();
    return $JavaScriptFunction.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_Object = goog.module.get('java.lang.Object$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $JavaScriptFunction = goog.module.get('vmbootstrap.JavaScriptFunction$impl');
  }
  
  
};



exports = $Overlay; 
//# sourceMappingURL=JSONType$StringifyReplacerUnionType$$Overlay.js.map