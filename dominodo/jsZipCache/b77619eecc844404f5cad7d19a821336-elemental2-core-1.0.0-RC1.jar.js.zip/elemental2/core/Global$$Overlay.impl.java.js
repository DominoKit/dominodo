/**
 * @fileoverview transpiled from elemental2.core.Global$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Global.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_Infinity__elemental2_core_Global_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_Infinity__elemental2_core_Global_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_Infinity__elemental2_core_Global_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_Infinity__elemental2_core_Global_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_NaN__elemental2_core_Global_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_NaN__elemental2_core_Global_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_NaN__elemental2_core_Global_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_NaN__elemental2_core_Global_$Overlay = value);
  }
  
  /**
   * @return {*}
   * @public
   */
  static get f_undefined__elemental2_core_Global_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_undefined__elemental2_core_Global_$Overlay);
  }
  
  /**
   * @param {*} value
   * @return {void}
   * @public
   */
  static set f_undefined__elemental2_core_Global_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_undefined__elemental2_core_Global_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_Infinity__elemental2_core_Global_$Overlay = window.Infinity;
    $Overlay.$f_NaN__elemental2_core_Global_$Overlay = window.NaN;
    $Overlay.$f_undefined__elemental2_core_Global_$Overlay = window.undefined;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof window;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('window'));


/** @private {number} */
$Overlay.$f_Infinity__elemental2_core_Global_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_NaN__elemental2_core_Global_$Overlay = 0.0;


/** @private {*} */
$Overlay.$f_undefined__elemental2_core_Global_$Overlay;


exports = $Overlay; 
//# sourceMappingURL=Global$$Overlay.js.map