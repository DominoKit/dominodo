/**
 * @fileoverview transpiled from elemental2.core.Int16Array$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Int16Array.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_BYTES_PER_ELEMENT__elemental2_core_Int16Array_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Int16Array_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_BYTES_PER_ELEMENT__elemental2_core_Int16Array_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Int16Array_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Int16Array_$Overlay = Int16Array.BYTES_PER_ELEMENT;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Int16Array;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('Int16Array'));


/** @private {number} */
$Overlay.$f_BYTES_PER_ELEMENT__elemental2_core_Int16Array_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=Int16Array$$Overlay.js.map