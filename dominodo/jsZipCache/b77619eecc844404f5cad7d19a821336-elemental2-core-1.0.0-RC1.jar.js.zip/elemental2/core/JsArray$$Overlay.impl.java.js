/**
 * @fileoverview transpiled from elemental2.core.JsArray$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsArray.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsArray.FromArrayLikeUnionType.$Overlay$impl');
let FromMapFn_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.FromMapFn.$Overlay$impl');
let P0UnionType_$Overlay = goog.forwardDeclare('elemental2.core.JsArray.FromMapFn.P0UnionType.$Overlay$impl');
let JsIterable_$Overlay = goog.forwardDeclare('elemental2.core.JsIterable.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');


class JsArray_$Overlay {
  /**
   * @template M_T, M_R
   * @param {IArrayLike<M_T>} arrayLike
   * @param {?function(?, number):?} mapFn
   * @param {*} this_
   * @return {Array<M_R>}
   * @public
   */
  static m_from__jsinterop_base_JsArrayLike__elemental2_core_JsArray_FromMapFn__java_lang_Object(arrayLike, mapFn, this_) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn, this_);
  }
  
  /**
   * @template M_T, M_R
   * @param {IArrayLike<M_T>} arrayLike
   * @param {?function(?, number):?} mapFn
   * @return {Array<M_R>}
   * @public
   */
  static m_from__jsinterop_base_JsArrayLike__elemental2_core_JsArray_FromMapFn(arrayLike, mapFn) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn);
  }
  
  /**
   * @template M_T, M_R
   * @param {IArrayLike<M_T>} arrayLike
   * @return {Array<M_R>}
   * @public
   */
  static m_from__jsinterop_base_JsArrayLike(arrayLike) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)));
  }
  
  /**
   * @template M_T, M_R
   * @param {Iterable<M_T>} arrayLike
   * @param {?function(?, number):?} mapFn
   * @param {*} this_
   * @return {Array<M_R>}
   * @public
   */
  static m_from__elemental2_core_JsIterable__elemental2_core_JsArray_FromMapFn__java_lang_Object(arrayLike, mapFn, this_) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn, this_);
  }
  
  /**
   * @template M_T, M_R
   * @param {Iterable<M_T>} arrayLike
   * @param {?function(?, number):?} mapFn
   * @return {Array<M_R>}
   * @public
   */
  static m_from__elemental2_core_JsIterable__elemental2_core_JsArray_FromMapFn(arrayLike, mapFn) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn);
  }
  
  /**
   * @template M_T, M_R
   * @param {Iterable<M_T>} arrayLike
   * @return {Array<M_R>}
   * @public
   */
  static m_from__elemental2_core_JsIterable(arrayLike) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)));
  }
  
  /**
   * @template M_T, M_R
   * @param {?string} arrayLike
   * @param {?function(?, number):?} mapFn
   * @param {*} this_
   * @return {Array<M_R>}
   * @public
   */
  static m_from__java_lang_String__elemental2_core_JsArray_FromMapFn__java_lang_Object(arrayLike, mapFn, this_) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn, this_);
  }
  
  /**
   * @template M_T, M_R
   * @param {?string} arrayLike
   * @param {?function(?, number):?} mapFn
   * @return {Array<M_R>}
   * @public
   */
  static m_from__java_lang_String__elemental2_core_JsArray_FromMapFn(arrayLike, mapFn) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn);
  }
  
  /**
   * @template M_T, M_R
   * @param {?string} arrayLike
   * @return {Array<M_R>}
   * @public
   */
  static m_from__java_lang_String(arrayLike) {
    JsArray_$Overlay.$clinit();
    return Array.from(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)));
  }
  
  /**
   * @template M_T, M_R
   * @param {Array<M_T>} arrayLike
   * @param {?function(?, number):?} mapFn
   * @param {*} this_
   * @return {Array<M_R>}
   * @public
   */
  static m_from__arrayOf_java_lang_Object__elemental2_core_JsArray_FromMapFn__java_lang_Object(arrayLike, mapFn, this_) {
    JsArray_$Overlay.$clinit();
    return JsArray_$Overlay.m_from__jsinterop_base_JsArrayLike__elemental2_core_JsArray_FromMapFn__java_lang_Object(/**@type {IArrayLike<*>} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn, this_);
  }
  
  /**
   * @template M_T, M_R
   * @param {Array<M_T>} arrayLike
   * @param {?function(?, number):?} mapFn
   * @return {Array<M_R>}
   * @public
   */
  static m_from__arrayOf_java_lang_Object__elemental2_core_JsArray_FromMapFn(arrayLike, mapFn) {
    JsArray_$Overlay.$clinit();
    return JsArray_$Overlay.m_from__jsinterop_base_JsArrayLike__elemental2_core_JsArray_FromMapFn(/**@type {IArrayLike<*>} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)), mapFn);
  }
  
  /**
   * @template M_T, M_R
   * @param {Array<M_T>} arrayLike
   * @return {Array<M_R>}
   * @public
   */
  static m_from__arrayOf_java_lang_Object(arrayLike) {
    JsArray_$Overlay.$clinit();
    return JsArray_$Overlay.m_from__jsinterop_base_JsArrayLike(/**@type {IArrayLike<*>} */ (Js.m_uncheckedCast__java_lang_Object(arrayLike)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    JsArray_$Overlay.$clinit = (() =>{
    });
    JsArray_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Array;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(JsArray_$Overlay, $Util.$makeClassName('Array'));


exports = JsArray_$Overlay; 
//# sourceMappingURL=JsArray$$Overlay.js.map