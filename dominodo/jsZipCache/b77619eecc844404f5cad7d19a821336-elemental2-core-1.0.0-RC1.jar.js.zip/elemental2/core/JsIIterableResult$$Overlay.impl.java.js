/**
 * @fileoverview transpiled from elemental2.core.JsIIterableResult$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsIIterableResult.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class JsIIterableResult_$Overlay {
  /**
   * @return {IIterableResult}
   * @public
   */
  static m_create__() {
    JsIIterableResult_$Overlay.$clinit();
    return /**@type {IIterableResult} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    JsIIterableResult_$Overlay.$clinit = (() =>{
    });
    JsIIterableResult_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};



exports = JsIIterableResult_$Overlay; 
//# sourceMappingURL=JsIIterableResult$$Overlay.js.map