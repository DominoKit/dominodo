/**
 * @fileoverview transpiled from elemental2.core.JsArray$FromMapFn$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsArray.FromMapFn.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsArray.FromMapFn.P0UnionType.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class FromMapFn_$Overlay {
  /**
   * @template C_FromMapFn_T, C_FromMapFn_R
   * @param {?function(?, number):C_FromMapFn_R} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @return {C_FromMapFn_R}
   * @public
   */
  static m_onInvoke__elemental2_core_JsArray_FromMapFn__java_lang_String__double($thisArg, p0, p1) {
    FromMapFn_$Overlay.$clinit();
    return $thisArg(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1);
  }
  
  /**
   * @template C_FromMapFn_T, C_FromMapFn_R
   * @param {?function(?, number):C_FromMapFn_R} $thisArg
   * @param {C_FromMapFn_T} p0
   * @param {number} p1
   * @return {C_FromMapFn_R}
   * @public
   */
  static m_onInvoke__elemental2_core_JsArray_FromMapFn__java_lang_Object__double($thisArg, p0, p1) {
    FromMapFn_$Overlay.$clinit();
    return $thisArg(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    FromMapFn_$Overlay.$clinit = (() =>{
    });
    FromMapFn_$Overlay.$loadModules();
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};



exports = FromMapFn_$Overlay; 
//# sourceMappingURL=JsArray$FromMapFn$$Overlay.js.map