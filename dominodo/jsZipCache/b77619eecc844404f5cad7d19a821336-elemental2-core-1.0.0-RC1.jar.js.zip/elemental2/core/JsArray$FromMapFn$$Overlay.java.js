/**
 * @fileoverview transpiled from elemental2.core.JsArray$FromMapFn$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.JsArray.FromMapFn.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.JsArray.FromMapFn.P0UnionType.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var FromMapFn_$Overlay = goog.require('elemental2.core.JsArray.FromMapFn.$Overlay$impl');
exports = FromMapFn_$Overlay;
 