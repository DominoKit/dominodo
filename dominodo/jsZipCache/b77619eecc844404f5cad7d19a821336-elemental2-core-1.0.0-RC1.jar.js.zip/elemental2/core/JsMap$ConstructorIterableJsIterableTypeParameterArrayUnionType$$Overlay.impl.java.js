/**
 * @fileoverview transpiled from elemental2.core.JsMap$ConstructorIterableJsIterableTypeParameterArrayUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsMap.ConstructorIterableJsIterableTypeParameterArrayUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class $Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    $Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), $Overlay));
  }
  
  /**
   * @template C_ConstructorIterableJsIterableTypeParameterArrayUnionType_KEY, C_ConstructorIterableJsIterableTypeParameterArrayUnionType_VALUE
   * @param {?} $thisArg
   * @return {C_ConstructorIterableJsIterableTypeParameterArrayUnionType_KEY}
   * @public
   */
  static m_asKEY__elemental2_core_JsMap_ConstructorIterableJsIterableTypeParameterArrayUnionType($thisArg) {
    $Overlay.$clinit();
    return Js.m_cast__java_lang_Object($thisArg);
  }
  
  /**
   * @template C_ConstructorIterableJsIterableTypeParameterArrayUnionType_KEY, C_ConstructorIterableJsIterableTypeParameterArrayUnionType_VALUE
   * @param {?} $thisArg
   * @return {C_ConstructorIterableJsIterableTypeParameterArrayUnionType_VALUE}
   * @public
   */
  static m_asVALUE__elemental2_core_JsMap_ConstructorIterableJsIterableTypeParameterArrayUnionType($thisArg) {
    $Overlay.$clinit();
    return Js.m_cast__java_lang_Object($thisArg);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = $Overlay; 
//# sourceMappingURL=JsMap$ConstructorIterableJsIterableTypeParameterArrayUnionType$$Overlay.js.map