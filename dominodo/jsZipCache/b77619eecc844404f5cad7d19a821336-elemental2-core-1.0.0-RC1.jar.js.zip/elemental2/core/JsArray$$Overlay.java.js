/**
 * @fileoverview transpiled from elemental2.core.JsArray$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.JsArray.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.JsArray.FromArrayLikeUnionType.$Overlay');
const _FromMapFn_$Overlay = goog.require('elemental2.core.JsArray.FromMapFn.$Overlay');
const _P0UnionType_$Overlay = goog.require('elemental2.core.JsArray.FromMapFn.P0UnionType.$Overlay');
const _JsIterable_$Overlay = goog.require('elemental2.core.JsIterable.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');


// Re-exports the implementation.
var JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay$impl');
exports = JsArray_$Overlay;
 