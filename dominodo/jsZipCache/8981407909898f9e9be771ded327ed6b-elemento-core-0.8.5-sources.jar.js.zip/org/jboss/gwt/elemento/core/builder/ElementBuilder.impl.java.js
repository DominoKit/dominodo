/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.ElementBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.ElementBuilder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');
const TypedBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TypedBuilder$impl');

let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventTarget_$Overlay = goog.forwardDeclare('elemental2.dom.EventTarget.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Arrays = goog.forwardDeclare('java.util.Arrays$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let JsPropertyMap_$Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_E, C_B
 * @implements {TypedBuilder<C_E, C_B>}
 * @implements {IsElement<C_E>}
  */
class ElementBuilder extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {C_E} */
    this.f_element__org_jboss_gwt_elemento_core_builder_ElementBuilder;
  }
  
  /**
   * @param {C_E} element
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_builder_ElementBuilder__elemental2_dom_HTMLElement(element) {
    this.$ctor__java_lang_Object__();
    this.f_element__org_jboss_gwt_elemento_core_builder_ElementBuilder = /**@type {C_E} */ ($Casts.$to(Objects.m_requireNonNull__java_lang_Object__java_lang_String(element, "element required"), $Overlay));
  }
  
  /**
   * @override
   * @return {C_E}
   * @public
   */
  m_get__() {
    return this.f_element__org_jboss_gwt_elemento_core_builder_ElementBuilder;
  }
  
  /**
   * @override
   * @return {C_E}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_jboss_gwt_elemento_core_builder_ElementBuilder;
  }
  
  /**
   * @param {?string} id
   * @return {C_B}
   * @public
   */
  m_id__java_lang_String(id) {
    /**@type {HTMLElement} */ (this.m_get__()).id = id;
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @return {C_B}
   * @public
   */
  m_id__() {
    this.m_id__java_lang_String(Elements.m_createDocumentUniqueId__());
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @param {?string} title
   * @return {C_B}
   * @public
   */
  m_title__java_lang_String(title) {
    /**@type {HTMLElement} */ (this.m_get__()).title = title;
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @param {Array<?string>} classes
   * @return {C_B}
   * @public
   */
  m_css__arrayOf_java_lang_String(classes) {
    if (!$Equality.$same(classes, null)) {
      let failSafeClasses = /**@type {!ArrayList<?string>} */ (ArrayList.$create__());
      for (let $array = classes, $index = 0; $index < $array.length; $index++) {
        let c = $array[$index];
        if (!$Equality.$same(c, null)) {
          if (j_l_String.m_contains__java_lang_String__java_lang_CharSequence(c, " ")) {
            failSafeClasses.addAll(/**@type {List<?string>} */ (Arrays.m_asList__arrayOf_java_lang_Object(j_l_String.m_split__java_lang_String__java_lang_String(c, " "))));
          } else {
            failSafeClasses.add(c);
          }
        }
      }
      for (let $iterator = failSafeClasses.m_iterator__(); $iterator.m_hasNext__(); ) {
        let failSafeClass = /**@type {?string} */ ($Casts.$to($iterator.m_next__(), j_l_String));
        /**@type {HTMLElement} */ (this.m_get__()).classList.add(failSafeClass);
      }
    }
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @param {?string} className
   * @param {boolean} force
   * @return {C_B}
   * @public
   */
  m_css__java_lang_String__boolean(className, force) {
    /**@type {HTMLElement} */ (this.m_get__()).classList.toggle(className, force);
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @param {?string} style
   * @return {C_B}
   * @public
   */
  m_style__java_lang_String(style) {
    /**@type {HTMLElement} */ (this.m_get__()).style.cssText = style;
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @return {C_B}
   * @public
   */
  m_attr__java_lang_String__java_lang_String(name, value) {
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.m_get__(), name, value);
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @return {C_B}
   * @public
   */
  m_data__java_lang_String__java_lang_String(name, value) {
    JsPropertyMap_$Overlay.m_set__jsinterop_base_JsPropertyMap__java_lang_String__java_lang_Object(/**@type {HTMLElement} */ (this.m_get__()).dataset, j_l_String.m_replaceFirst__java_lang_String__java_lang_String__java_lang_String(name, "^data-", ""), value);
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @param {?string} name
   * @param {?string} value
   * @return {C_B}
   * @public
   */
  m_aria__java_lang_String__java_lang_String(name, value) {
    let safeName = j_l_String.m_startsWith__java_lang_String__java_lang_String(name, "aria-") ? name : "aria-" + j_l_String.m_valueOf__java_lang_Object(name);
    return this.m_attr__java_lang_String__java_lang_String(safeName, value);
  }
  
  /**
   * @param {Consumer<C_E>} consumer
   * @return {C_B}
   * @public
   */
  m_apply__java_util_function_Consumer(consumer) {
    consumer.m_accept__java_lang_Object(this.m_get__());
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @template M_V
   * @param {EventType<M_V, ?>} type
   * @param {?function(M_V):void} callback
   * @return {C_B}
   * @public
   */
  m_on__org_jboss_gwt_elemento_core_EventType__org_jboss_gwt_elemento_core_EventCallbackFn(type, callback) {
    EventType.m_bind__elemental2_dom_EventTarget__org_jboss_gwt_elemento_core_EventType__org_jboss_gwt_elemento_core_EventCallbackFn(this.m_get__(), type, callback);
    return /**@type {C_B} */ ($Casts.$to(this.m_that__(), ElementBuilder));
  }
  
  /**
   * @abstract
   * @override
   * @return {C_B}
   * @public
   */
  m_that__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ElementBuilder.$clinit = (() =>{
    });
    ElementBuilder.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ElementBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ElementBuilder);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Arrays = goog.module.get('java.util.Arrays$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    JsPropertyMap_$Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ElementBuilder, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.ElementBuilder'));


TypedBuilder.$markImplementor(ElementBuilder);
IsElement.$markImplementor(ElementBuilder);


exports = ElementBuilder; 
//# sourceMappingURL=ElementBuilder.js.map