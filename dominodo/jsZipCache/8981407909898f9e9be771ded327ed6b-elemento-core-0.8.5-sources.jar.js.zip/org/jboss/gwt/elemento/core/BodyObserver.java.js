/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.BodyObserver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.BodyObserver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DomGlobal_$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _MutationObserver_$Overlay = goog.require('elemental2.dom.MutationObserver.$Overlay');
const _$Overlay = goog.require('elemental2.dom.MutationObserverInit.$Overlay');
const _MutationRecord_$Overlay = goog.require('elemental2.dom.MutationRecord.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$1 = goog.require('org.jboss.gwt.elemento.core.BodyObserver.$1');
const _ElementObserver = goog.require('org.jboss.gwt.elemento.core.BodyObserver.ElementObserver');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _ObserverCallback = goog.require('org.jboss.gwt.elemento.core.ObserverCallback');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BodyObserver = goog.require('org.jboss.gwt.elemento.core.BodyObserver$impl');
exports = BodyObserver;
 