/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.TextContentBuilder.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.builder.TextContentBuilder');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ElementBuilder = goog.require('org.jboss.gwt.elemento.core.builder.ElementBuilder');
const _TextContent = goog.require('org.jboss.gwt.elemento.core.builder.TextContent');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TextContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.TextContentBuilder$impl');
exports = TextContentBuilder;
 