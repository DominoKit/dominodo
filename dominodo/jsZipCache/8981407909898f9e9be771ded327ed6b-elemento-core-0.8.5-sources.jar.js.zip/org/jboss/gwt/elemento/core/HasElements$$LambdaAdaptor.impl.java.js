/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.HasElements$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.HasElements.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasElements = goog.require('org.jboss.gwt.elemento.core.HasElements$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');


/**
 * @implements {HasElements}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function():Iterable<HTMLElement>} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():Iterable<HTMLElement>} */
    this.f_$$fn__org_jboss_gwt_elemento_core_HasElements_$LambdaAdaptor;
    this.$ctor__org_jboss_gwt_elemento_core_HasElements_$LambdaAdaptor__org_jboss_gwt_elemento_core_HasElements_$JsFunction(fn);
  }
  
  /**
   * @param {?function():Iterable<HTMLElement>} fn
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_HasElements_$LambdaAdaptor__org_jboss_gwt_elemento_core_HasElements_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_jboss_gwt_elemento_core_HasElements_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {Iterable<HTMLElement>}
   * @public
   */
  m_asElements__() {
    let /** ?function():Iterable<HTMLElement> */ $function;
    return ($function = this.f_$$fn__org_jboss_gwt_elemento_core_HasElements_$LambdaAdaptor, $function());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.jboss.gwt.elemento.core.HasElements$$LambdaAdaptor'));


HasElements.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=HasElements$$LambdaAdaptor.js.map