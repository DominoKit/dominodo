/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.HtmlContent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.HtmlContent$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const TextContent = goog.require('org.jboss.gwt.elemento.core.builder.TextContent$impl');

let Document_$Overlay = goog.forwardDeclare('elemental2.dom.Document.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let SafeHtml = goog.forwardDeclare('org.gwtproject.safehtml.shared.SafeHtml$impl');
let HasElements = goog.forwardDeclare('org.jboss.gwt.elemento.core.HasElements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let TypedBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.TypedBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @interface
 * @template C_E, C_B
 * @extends {TextContent<C_E, C_B>}
 */
class HtmlContent {
  /**
   * @abstract
   * @param {SafeHtml} html
   * @return {C_B}
   * @public
   */
  m_innerHtml__org_gwtproject_safehtml_shared_SafeHtml(html) {
  }
  
  /**
   * @abstract
   * @param {IsElement} element
   * @return {C_B}
   * @public
   */
  m_add__org_jboss_gwt_elemento_core_IsElement(element) {
  }
  
  /**
   * @abstract
   * @param {?string} text
   * @return {C_B}
   * @public
   */
  m_add__java_lang_String(text) {
  }
  
  /**
   * @abstract
   * @param {Node} element
   * @return {C_B}
   * @public
   */
  m_add__elemental2_dom_Node(element) {
  }
  
  /**
   * @abstract
   * @param {HasElements} elements
   * @return {C_B}
   * @public
   */
  m_addAll__org_jboss_gwt_elemento_core_HasElements(elements) {
  }
  
  /**
   * @abstract
   * @param {Array<HTMLElement>} elements
   * @return {C_B}
   * @public
   */
  m_addAll__arrayOf_elemental2_dom_HTMLElement(elements) {
  }
  
  /**
   * @abstract
   * @param {Iterable<?>} elements
   * @return {C_B}
   * @public
   */
  m_addAll__java_lang_Iterable(elements) {
  }
  
  /**
   * @abstract
   * @param {Array<IsElement>} elements
   * @return {C_B}
   * @public
   */
  m_addAll__arrayOf_org_jboss_gwt_elemento_core_IsElement(elements) {
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {SafeHtml} html
   * @return {C_B}
   * @public
   */
  static m_innerHtml__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__org_gwtproject_safehtml_shared_SafeHtml($thisArg, html) {
    HtmlContent.$clinit();
    /**@type {HTMLElement} */ ($Casts.$to($thisArg.m_get__(), $Overlay)).innerHTML = html.m_asString__();
    return $thisArg.m_that__();
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {IsElement} element
   * @return {C_B}
   * @public
   */
  static m_add__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__org_jboss_gwt_elemento_core_IsElement($thisArg, element) {
    HtmlContent.$clinit();
    return $thisArg.m_add__elemental2_dom_Node(element.m_asElement__());
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {?string} text
   * @return {C_B}
   * @public
   */
  static m_add__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__java_lang_String($thisArg, text) {
    HtmlContent.$clinit();
    return $thisArg.m_add__elemental2_dom_Node(Document_$Overlay.m_createTextNode__elemental2_dom_Document__java_lang_String(/**@type {HTMLElement} */ ($Casts.$to($thisArg.m_get__(), $Overlay)).ownerDocument, text));
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {Node} element
   * @return {C_B}
   * @public
   */
  static m_add__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__elemental2_dom_Node($thisArg, element) {
    HtmlContent.$clinit();
    /**@type {HTMLElement} */ ($Casts.$to($thisArg.m_get__(), $Overlay)).appendChild(element);
    return $thisArg.m_that__();
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {HasElements} elements
   * @return {C_B}
   * @public
   */
  static m_addAll__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__org_jboss_gwt_elemento_core_HasElements($thisArg, elements) {
    HtmlContent.$clinit();
    return $thisArg.m_addAll__java_lang_Iterable(elements.m_asElements__());
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {Array<HTMLElement>} elements
   * @return {C_B}
   * @public
   */
  static m_addAll__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__arrayOf_elemental2_dom_HTMLElement($thisArg, elements) {
    HtmlContent.$clinit();
    for (let $array = elements, $index = 0; $index < $array.length; $index++) {
      let element = $array[$index];
      $thisArg.m_add__elemental2_dom_Node(element);
    }
    return $thisArg.m_that__();
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {Iterable<?>} elements
   * @return {C_B}
   * @public
   */
  static m_addAll__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__java_lang_Iterable($thisArg, elements) {
    HtmlContent.$clinit();
    for (let $iterator = elements.m_iterator__(); $iterator.m_hasNext__(); ) {
      let element = /**@type {Node} */ ($Casts.$to($iterator.m_next__(), Node_$Overlay));
      $thisArg.m_add__elemental2_dom_Node(element);
    }
    return $thisArg.m_that__();
  }
  
  /**
   * @template C_E, C_B
   * @param {HtmlContent<C_E, C_B>} $thisArg
   * @param {Array<IsElement>} elements
   * @return {C_B}
   * @public
   */
  static m_addAll__$default__org_jboss_gwt_elemento_core_builder_HtmlContent__arrayOf_org_jboss_gwt_elemento_core_IsElement($thisArg, elements) {
    HtmlContent.$clinit();
    for (let $array = elements, $index = 0; $index < $array.length; $index++) {
      let element = $array[$index];
      $thisArg.m_add__org_jboss_gwt_elemento_core_IsElement(element);
    }
    return $thisArg.m_that__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HtmlContent.$clinit = (() =>{
    });
    HtmlContent.$loadModules();
    TextContent.$clinit();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    TextContent.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_HtmlContent = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_builder_HtmlContent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_builder_HtmlContent;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Document_$Overlay = goog.module.get('elemental2.dom.Document.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    Node_$Overlay = goog.module.get('elemental2.dom.Node.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HtmlContent, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.HtmlContent'));


HtmlContent.$markImplementor(/** @type {Function} */ (HtmlContent));


exports = HtmlContent; 
//# sourceMappingURL=HtmlContent.js.map