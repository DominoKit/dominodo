/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements$FilterHTMLElements.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.Elements.FilterHTMLElements$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const Predicate = goog.require('java.util.function.Predicate$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_FilterHTMLElements_T
 * @implements {Predicate<C_FilterHTMLElements_T>}
  */
class FilterHTMLElements extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @template C_FilterHTMLElements_T
   * @return {!FilterHTMLElements<C_FilterHTMLElements_T>}
   * @public
   */
  static $create__() {
    FilterHTMLElements.$clinit();
    let $instance = new FilterHTMLElements();
    $instance.$ctor__org_jboss_gwt_elemento_core_Elements_FilterHTMLElements__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_Elements_FilterHTMLElements__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {C_FilterHTMLElements_T} t
   * @return {boolean}
   * @public
   */
  m_test__elemental2_dom_Node(t) {
    return $Overlay.$isInstance(t);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {Predicate<?>} arg0
   * @return {Predicate<C_FilterHTMLElements_T>}
   * @public
   */
  m_and__java_util_function_Predicate(arg0) {
    return /**@type {Predicate<C_FilterHTMLElements_T>} */ (Predicate.m_and__$default__java_util_function_Predicate__java_util_function_Predicate(this, arg0));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @return {Predicate<C_FilterHTMLElements_T>}
   * @public
   */
  m_negate__() {
    return /**@type {Predicate<C_FilterHTMLElements_T>} */ (Predicate.m_negate__$default__java_util_function_Predicate(this));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {Predicate<?>} arg0
   * @return {Predicate<C_FilterHTMLElements_T>}
   * @public
   */
  m_or__java_util_function_Predicate(arg0) {
    return /**@type {Predicate<C_FilterHTMLElements_T>} */ (Predicate.m_or__$default__java_util_function_Predicate__java_util_function_Predicate(this, arg0));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {boolean}
   * @public
   */
  m_test__java_lang_Object(arg0) {
    return this.m_test__elemental2_dom_Node(/**@type {C_FilterHTMLElements_T} */ ($Casts.$to(arg0, Node_$Overlay)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    FilterHTMLElements.$clinit = (() =>{
    });
    FilterHTMLElements.$loadModules();
    j_l_Object.$clinit();
    Predicate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FilterHTMLElements;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FilterHTMLElements);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    Node_$Overlay = goog.module.get('elemental2.dom.Node.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(FilterHTMLElements, $Util.$makeClassName('org.jboss.gwt.elemento.core.Elements$FilterHTMLElements'));


Predicate.$markImplementor(FilterHTMLElements);


exports = FilterHTMLElements; 
//# sourceMappingURL=Elements$FilterHTMLElements.js.map