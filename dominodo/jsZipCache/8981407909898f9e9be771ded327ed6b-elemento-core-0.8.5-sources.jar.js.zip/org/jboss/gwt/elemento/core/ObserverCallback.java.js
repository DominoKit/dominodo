/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.ObserverCallback.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.ObserverCallback');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.MutationRecord.$Overlay');
const _$LambdaAdaptor = goog.require('org.jboss.gwt.elemento.core.ObserverCallback.$LambdaAdaptor');


// Re-exports the implementation.
var ObserverCallback = goog.require('org.jboss.gwt.elemento.core.ObserverCallback$impl');
exports = ObserverCallback;
 