/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.Elements$JsArrayElementIterator.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.Elements.JsArrayElementIterator');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _Iterator = goog.require('java.util.Iterator');
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _IllegalStateException = goog.require('java.lang.IllegalStateException');
const _NoSuchElementException = goog.require('java.util.NoSuchElementException');
const _Consumer = goog.require('java.util.function.Consumer');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var JsArrayElementIterator = goog.require('org.jboss.gwt.elemento.core.Elements.JsArrayElementIterator$impl');
exports = JsArrayElementIterator;
 